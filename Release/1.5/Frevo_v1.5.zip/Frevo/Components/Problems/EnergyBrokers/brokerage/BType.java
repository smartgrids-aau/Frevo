package brokerage;

public enum BType {
	pessimistic,
	optimistic,
	ANN_A,
	ANN_B,
	ANN_C,
	ANN_D,
	ANN_E
}