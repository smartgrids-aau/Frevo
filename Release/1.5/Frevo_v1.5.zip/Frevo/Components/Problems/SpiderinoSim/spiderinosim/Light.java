package spiderinosim;

/**
 * Represents a light in the World.
 */
public class Light extends WObject {

	public Light(double x, double y, double radius) {
		super(x, y, radius);
	}
}
