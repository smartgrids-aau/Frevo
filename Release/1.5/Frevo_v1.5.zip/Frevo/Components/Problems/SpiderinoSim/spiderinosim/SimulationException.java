package spiderinosim;

public class SimulationException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1792514958829066208L;

	public SimulationException(String message) {
		super(message);
	}
}
