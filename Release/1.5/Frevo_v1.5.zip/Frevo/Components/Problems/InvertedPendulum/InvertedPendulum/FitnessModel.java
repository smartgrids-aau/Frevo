package InvertedPendulum;

public enum FitnessModel {
    ANGLE_POW_2,
    ANGLE_POW_2_PLUS_USED_WAY,
    ANGLE_PLUS_DIST_ORIGIN,
    ANGLE_PLUS_DIST_ORIGIN_POW_2,
    ANGLE_PLUS_ABS_DIST_ORIGIN
}
