package fehervari.evopco;

public enum RadioModel {
	/** Gaussian model */
	GAUSSIAN_RADIO_MODEL,
	/** Rayleight model */
	RAYLEIGH_RADIO_MODEL
}
