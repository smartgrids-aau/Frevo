package fehervari.evopco;

public enum JumpingPolicy {
	// original firefly algorithm
	FIREFLY_POLICY,
	// Mixed inhibitory-excitatory
	IE_POICY,
	// evolved policy
	EVOLVED_POLICY
}
