package cipi;

public enum PayoffFunction {
	Multiply_by_three,
	Quadratic
}
