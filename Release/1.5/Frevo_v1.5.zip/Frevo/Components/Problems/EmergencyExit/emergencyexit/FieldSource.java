package emergencyexit;

public enum FieldSource {
	FIELD_FROM_FILE,
	RANDOM_FIELD
}
