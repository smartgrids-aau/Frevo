package feedForwardNetwork;

enum ActivationFunction {
	LINEAR,
	SIGMOID,
	RELU
}
