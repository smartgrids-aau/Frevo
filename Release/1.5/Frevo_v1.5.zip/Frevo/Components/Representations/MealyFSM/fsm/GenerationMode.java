package fsm;

public enum GenerationMode {
	RANDOM,
	SIMAO
}
