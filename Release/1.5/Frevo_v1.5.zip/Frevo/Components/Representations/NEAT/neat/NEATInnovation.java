package neat;

public interface NEATInnovation {
	public void setInnovationId(int id);
	public int innovationId();
	public int type();
}
