package neat;

public class Pair {
	
	int first;
	int second;

	public Pair (int first, int second) {
		this.first = first;
		this.second = second;
	}
}
