package fullyMeshedNet;

enum ActivationFunction {
	LINEAR,
	SIGMOID,
	RELU
}
