package XOR;


import java.util.ArrayList;

import core.AbstractRepresentation;
import core.AbstractSingleProblem;

/** A simple XOR problem to test evolutionary algorithms if they work properly. Fitness is determined by mean square error. */
public class XOR extends AbstractSingleProblem {

	@Override
	protected double evaluateCandidate(AbstractRepresentation candidate) {
		//test all 4 cases and return negative mean square error
		AbstractRepresentation net = candidate;
		
		double sumerror = 0;
		
		ArrayList<Float> input = new ArrayList<Float>();
		ArrayList<Float> output = new ArrayList<Float>();
		// 0 - 0 : 0
		input.add(0f);
		input.add(0f);
		output = net.getOutput(input);
		
		float out = output.get(0);
		
		sumerror += Math.abs(out-0);
		
		// 0 - 1 : 1
		input.clear();
		output.clear();
		net.reset();
		
		input.add(0f);
		input.add(1f);
		output = net.getOutput(input);
		
		out = output.get(0);
		
		sumerror += Math.abs(out-1);
		
		// 1 - 0 : 1
		input.clear();
		output.clear();
		net.reset();
				
		input.add(1f);
		input.add(0f);
		output = net.getOutput(input);
				
		out = output.get(0);
				
		sumerror += Math.abs(out-1);
		
		// 1 - 1 : 0
		input.clear();
		output.clear();
		net.reset();
						
		input.add(1f);
		input.add(1f);
		output = net.getOutput(input);
						
		out = output.get(0);
						
		sumerror += Math.abs(out-0);			
		
		//return the sum
		return 1.0-(sumerror/4.0);
	}

	@Override
	public void replayWithVisualization(AbstractRepresentation candidate) {
		double res = evaluateCandidate(candidate);
		System.out.println ("Sum of MSE: "+res);

	}
	
	@Override
	public double getMaximumFitness() {
		return Double.MAX_VALUE;
	}

}
