package fehervari.evopco;

import graphics.JChart2DComponent;

import java.awt.Dimension;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;

import net.tinyos.prowler.CrystalOscillatorModel;
import net.tinyos.prowler.Event;
import net.tinyos.prowler.GaussianRadioModel;
import net.tinyos.prowler.Mica2Node;
import net.tinyos.prowler.Node;
import net.tinyos.prowler.RadioModel;
import net.tinyos.prowler.RayleighRadioModel;
import net.tinyos.prowler.Simulator;

import utils.StatKeeper;
import core.AbstractRepresentation;
import core.AbstractSingleProblem;
import core.XMLFieldEntry;

public class EvoPCO extends AbstractSingleProblem {

	/** Number of simulation runs */
	private int NUMBER_OF_SIMULATION_RUNS = 1;

	/** Type of radio model in the simulation */
	private fehervari.evopco.RadioModel RADIO_MODEL = fehervari.evopco.RadioModel.RAYLEIGH_RADIO_MODEL;

	/** Network topology */
	private NetworkTopology NETWORK_TOPOLOGY = NetworkTopology.REGULAR_GRID_TOPOLOGY;

	/** Number of nodes in the simulation */
	private int NUMBER_OF_NODES;

	/**
	 * Defines the standard synchronization-interval in milliseconds.<br>
	 * (default value = 1000 ms)
	 */
	public static long SYNC_INTERVAL_ms = 1000;

	/** Length of the simulation in seconds */
	public static int SIMULATION_LENGTH = 100;

	/**
	 * Initial clock drift for all clocks in ppm. The real clock drift is a
	 * random value between 0 and INITIAL_CLOCK_DRIFT_PPM Default value: 100000
	 * (with rate correction) Default value: 1000 (without rate correction) =
	 * \rho=0.001 Normal good clocks have about 100ppm 0 = no drift
	 */
	private static long INITIAL_CLOCK_DRIFT_PPM = 0;//100;

	/**
	 * If true, then the clock drift additionally depends on the actual
	 * temperature
	 */
	private static final boolean TEMPERATURE_DEPENDENT = false;

	// keep track of nodes
	java.util.List<Node> nodes = new ArrayList<Node>();

	boolean[] firingState;

	private Simulator simulator;

	/** true for visualizing */
	private boolean isGraphics = false;

	/** Chart to display time-series */
	private JChart2DComponent jChart;

	long[][] lastFirings;

	@Override
	public double evaluateCandidate(AbstractRepresentation candidate) {
		// load parameters
		loadParameters();

		// construct new simulator
		simulator = new Simulator();
		
		// set random object for repeatability
		Simulator.random = generator;

		if (isGraphics) {
			// run only once
			NUMBER_OF_SIMULATION_RUNS = 1;

			// initialize chart
			jChart = new JChart2DComponent(NUMBER_OF_NODES);

			// create statkeepers
			for (int i = 0; i < NUMBER_OF_NODES; i++) {
				StatKeeper sk = new StatKeeper(true, "time", "clock (ms)",
						false);
				jChart.addstatkeeper(sk);
			}
		}
		
		double fitness = 0;

		// for each simulation run
		for (int sim_run = 0; sim_run < NUMBER_OF_SIMULATION_RUNS; sim_run++) {

			// reset simulator
			simulator.clear();

			// remove nodes
			nodes.clear();

			// reset last firing data
			lastFirings = new long[NUMBER_OF_NODES][5];

			firingState = new boolean[NUMBER_OF_NODES];

			// creating the desired radio model
			RadioModel radioModel = null;

			switch (RADIO_MODEL) {
			/*
			 * case PERFECT_COMMUNICATION: // only bidirectional links
			 * radioModel = new IdealizedGaussianRadioModel(simulator); break;
			 */
			case GAUSSIAN_RADIO_MODEL:
				radioModel = new GaussianRadioModel(simulator);
				break;
			case RAYLEIGH_RADIO_MODEL:
				radioModel = new RayleighRadioModel(simulator);
				break;
			}

			// Configure network topology

			switch (NETWORK_TOPOLOGY) {
			case RANDOM_TOPOLOGY:
				// TODO implement random topology
				System.err.println("Random topology is not yet supported!");
				// simulator.createNodes(...);
				return 0;
			case REGULAR_GRID_TOPOLOGY:
				// calculate the number of nodes on each side
				int gridsize = (int) Math.ceil(Math.sqrt(NUMBER_OF_NODES));
				int x = 0;
				int y = 0;
				// node ID counter
				int id = 0;
				// TODO spacing should come from area
				int spacing = 10;

				// allocate nodes in a square array
				for (int n = 0; n < NUMBER_OF_NODES; n++) {
					try {
						Node node = simulator.createNode(Mica2Node.class,
								radioModel, id++, (float) x, (float) y, 0);

						// add to node list
						nodes.add(node);
					} catch (Exception e) {
						e.printStackTrace();
					}
					x += spacing;

					if (x == (spacing * gridsize)) {
						x = 0;
						y += spacing;
					}
				}

				break;
			}// end switch

			// creating all nodes
			Node tempNode = simulator.firstNode;
			while (tempNode != null) {
				// assign controller to each node
				new PCOApplication(
						tempNode,
						generator
								.nextInt((int) convertMillisecToTicks(SYNC_INTERVAL_ms)),
						this);

				// create random clock drift
				double clock_drift_ppm = (long) (generator.nextDouble() * 2
						* INITIAL_CLOCK_DRIFT_PPM - INITIAL_CLOCK_DRIFT_PPM);

				CrystalOscillatorModel crystalModel = new CrystalOscillatorModel(
						CrystalOscillatorModel.CRYSTAL_USER_DEFINED);
				// best temperature-drift approximation of atmega1281 internal
				// calibrated RC-oscillator (fabrication accuracy at 8MHZ =
				// +-10%)
				crystalModel.setInitialClockDriftPPM(clock_drift_ppm);
				crystalModel.setInflectionTemperatureCelsius(-25);
				crystalModel.setTemperatureCoefficients(600, -2, 0);
				tempNode.applyCrystalOscillatorModel(crystalModel);
				tempNode.setTemperatureDependence(TEMPERATURE_DEPENDENT);

				// step to next
				tempNode = tempNode.nextNode;
			}

			// this call is a must after configuring all nodes
			radioModel.updateNeighborhoods();

			// schedule timer event to record display data
			if (isGraphics) {
				class TimerEvent extends Event {

					public TimerEvent(long time) {
						super(time);
					}

					public void execute() {
						// record node data to chart
						for (int i = 0; i < nodes.size(); i++) {
							// Node node = nodes.get(i);
							StatKeeper sk = jChart.getStatKeeper(i);

							sk.add(firingState[i] ? (1000 - 10*nodes.get(i).getId()) : 0);
							// reset firing state
							firingState[i] = false;

						}

						// reschedule itself
						Event tEvent = new TimerEvent(
								simulator.getSimulationTime()
										+ (Simulator.ONE_SECOND / 10));
						simulator.addEvent(tEvent);
					}
				}

				// schedule timer event
				Event tEvent = new TimerEvent(simulator.getSimulationTime());
				simulator.addEvent(tEvent);
			}

			// run simulation
			simulator.run(SIMULATION_LENGTH);

			// calculate fitness

			// fitness is based on the last 5 firing periods to measure
			// deviation

			// initial mean is the 3rd firing from the 1st node
			long mean = lastFirings[0][2];

			List<Long> list = new ArrayList<Long>(NUMBER_OF_NODES);

			// add closest firings to list w.r.t. mean
			for (int n = 0; n < NUMBER_OF_NODES; n++) {
				// get closest
				long dist = Long.MAX_VALUE;
				int closest = 0;

				// find closest firing time
				for (int i = 1; i < 5; i++) {
					long d = Math.abs(mean - lastFirings[n][i]);
					if (d < dist) {
						dist = d;
						closest = i;
					}
				}

				list.add(lastFirings[n][closest]);
			}

			// iterate until the group does not change
			while (true) {
				// recalculate mean based on new list
				mean = 0;
				for (Long ft : list) {
					mean += ft;
				}
				mean = mean / list.size();
				
				// update list
				List<Long> temp_list = new ArrayList<Long>(NUMBER_OF_NODES);
				
				// add closest firings to list w.r.t. mean
				for (int n = 0; n < NUMBER_OF_NODES; n++) {
					// get closest
					long dist = Long.MAX_VALUE;
					int closest = 0;

					// find closest firing time
					for (int i = 1; i < 5; i++) {
						long d = Math.abs(mean - lastFirings[n][i]);
						if (d < dist) {
							dist = d;
							closest = i;
						}
					}

					temp_list.add(lastFirings[n][closest]);
				}
				
				// check exit condition
				if (temp_list.equals(list)) {
					break;
				} else {
					list = temp_list;
				}

			}
			
			// calculate the standard deviation of the data
			long std_dev = 0;
			
			for (Long l : list) {
				std_dev += (Math.abs(l-mean)*Math.abs(l-mean));
			}
			
			std_dev /= list.size();
			
			std_dev = (long)Math.sqrt(std_dev);
			
			fitness += (SYNC_INTERVAL_ms-std_dev);

		}

		return fitness / NUMBER_OF_SIMULATION_RUNS;
	}

	public void replayWithVisualization(AbstractRepresentation candidate) {
		// turn on graphics
		isGraphics = true;

		// run simulation
		double fitness = evaluateCandidate(candidate);

		// display chart
		JFrame resultsframe = new JFrame("Synch Results");

		resultsframe.add(jChart);
		jChart.updateChart();
		resultsframe.setLocationRelativeTo(null);
		resultsframe.setMinimumSize(new Dimension(500, 300));
		resultsframe.setVisible(true);

		// print fitness to standard out
		System.out.println("Fitness : " + fitness);
	}

	/** Loads parameters from the property set */
	private void loadParameters() {
		// read number of simulation runs
		XMLFieldEntry numberOfRuns = getProperties().get(
				"number_of_evaluations");
		if (numberOfRuns != null)
			NUMBER_OF_SIMULATION_RUNS = Integer.parseInt(numberOfRuns
					.getValue());

		// load radio model
		XMLFieldEntry radioModel = getProperties().get("radio_model");
		if (radioModel != null)
			RADIO_MODEL = fehervari.evopco.RadioModel.valueOf(radioModel
					.getValue());

		// load network topology
		XMLFieldEntry topology = getProperties().get("network_topology");
		if (topology != null)
			NETWORK_TOPOLOGY = NetworkTopology.valueOf(topology.getValue());

		// load number of nodes
		XMLFieldEntry nodenumber = getProperties().get("number_of_nodes");
		if (nodenumber != null)
			NUMBER_OF_NODES = Integer.parseInt(nodenumber.getValue());
		
		// load simulation length
		XMLFieldEntry simulationLength = getProperties().get(
				"simulation_length_s");
		if (simulationLength != null)
			SIMULATION_LENGTH = Integer.parseInt(simulationLength.getValue());
		
		//load clock drift
		XMLFieldEntry clockdrift = getProperties().get(
				"clock_drift");
		if (clockdrift != null)
			INITIAL_CLOCK_DRIFT_PPM = Integer.parseInt(clockdrift.getValue());

	}

	/**
	 * Returns the achievable maximum fitness of this problem. A representations
	 * with this fitness value cannot be improved any further.
	 */
	public double getMaximumFitness() {
		return Double.MAX_VALUE;
	}

	/**
	 * Converts a time in milliseconds to the number of simulator-ticks
	 * 
	 * @param time_ms
	 *            time in ms
	 * @return the corresponding number of simulator-ticks
	 */
	static long convertMillisecToTicks(double time_ms) {
		return Math.round(time_ms * Simulator.ONE_SECOND / 1000);
	}

	/**
	 * Converts a number of simulator-ticks to a time-representation in
	 * milliseconds
	 * 
	 * @param ticks
	 *            number of simulator-ticks
	 * @return the corresponding time in ms
	 */
	static long convertTicksToMillisec(long ticks) {
		return Math.round(((double) ticks) * 1000 / Simulator.ONE_SECOND);
	}

	/** Cancels the given event */
	public void cancelEvent(Event event) {
		this.simulator.eventQueue.removeEvent(event);
	}

	/** Returns the current simulation time in ms */
	long getTime() {
		return simulator.getSimulationTimeInMillisec();
	}

}
