package fsm;

/**
 * Represents an input with min and max values.
 * The min..max interval is divided into nUnit parts.
 * 
 * @author Agnes Pinter-Bartha
 *
 */
public class IntegerInput{
	int min;
	int max;
	int nUnit;		
	
	public IntegerInput(int min, int max, int nUnit){
		this.min = min;
		this.max = max;
		this.nUnit = nUnit;		
	}
	
	public IntegerInput clone(){
		IntegerInput clone = new IntegerInput(this.min, this.max, this.nUnit);
		return clone;
	}
	
	public int getNumberOfInputValues(){
		return nUnit + 1;
	}
	
	public int getMin(){
		return this.min;
	}
	
	public int getMax(){
		return this.max;
	}
	
	public int getUnits(){
		return this.nUnit;
	}
	
	/**
	 * Returns position of value in sorted input values.
	 * @param value Input value
	 * @return number of units
	 */
	public int getPosition(int value){
		if (max == min)
			return 0;
		return (int)((value - min) * nUnit * 1.0f / (max - min));
	}
}