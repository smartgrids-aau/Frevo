package fsm;

import java.util.Hashtable;
import core.XMLFieldEntry;

/**
 * Class collects parameters read from properties and default values for these
 * parameters.
 */
public class EvolutionParams {
	// constants
	final static int DEFAULT_NUMBER_OF_STATES = 6;

	final static float DEFAULT_MUTATE_ADD_STATE_PROB = 0.1f;
	final static float DEFAULT_MUTATE_MOD_TR_NEXTSTATE_PROB = 0.1f;
	final static float DEFAULT_MUTATE_MOD_TR_OUTPUT_PROB = 0.1f;
	final static float DEFAULT_MUTATE_DEL_STATE_PROB = 0.1f;
	final static float DEFAULT_MUTATE_DEL_TR_PROB = 0.1f;
	final static float DEFAULT_MUTATE_THRESHOLD_PROB = 0.1f;
	final static float DEFAULT_MUTATE_MOD_INIT_STATE_PROB = 0.1f;

	final static int DEFAULT_THRESHOLD_UNITS = 100;
	final static int DEFAULT_OUTPUT_UNITS = 100;

	final static boolean DEFAULT_STATE_NUM_CHANGE_ALLOWED = true;
	final static GenerationMode DEFAULT_GENERATION_MODE = GenerationMode.RANDOM;
	final static DistanceCalc DEFAULT_DISTANCE_CALC = DistanceCalc.HAMMING_DISTANCE;
	final static int DEFAULT_VALUE_COUNT_ABOVE_TO_THRESHOLD = 4;

	// parameters
	public boolean state_num_change_allowed = DEFAULT_STATE_NUM_CHANGE_ALLOWED;
	public GenerationMode generation_mode = DEFAULT_GENERATION_MODE;
	public DistanceCalc distance_calc_method = DEFAULT_DISTANCE_CALC;

	public int threshold_units = DEFAULT_THRESHOLD_UNITS;
	public int output_units = DEFAULT_OUTPUT_UNITS;
	public int value_count_above_to_threshold = DEFAULT_VALUE_COUNT_ABOVE_TO_THRESHOLD;

	public short nInput;
	public short nOutput;
	public int nState = DEFAULT_NUMBER_OF_STATES;

	public float mutate_add_state_prob = DEFAULT_MUTATE_ADD_STATE_PROB;
	public float mutate_mod_tr_nextstate_prob = DEFAULT_MUTATE_MOD_TR_NEXTSTATE_PROB;
	public float mutate_mod_tr_output_prob = DEFAULT_MUTATE_MOD_TR_OUTPUT_PROB;
	public float mutate_del_state_prob = DEFAULT_MUTATE_DEL_STATE_PROB;
	public float mutate_mod_init_state_prob = DEFAULT_MUTATE_MOD_INIT_STATE_PROB;
	public float mutate_del_tr_prob = DEFAULT_MUTATE_DEL_TR_PROB;
	public float mutate_threshold_prob = DEFAULT_MUTATE_THRESHOLD_PROB;

	public EvolutionParams(short inputnumber, short outputnumber,
			Hashtable<String, XMLFieldEntry> properties) {

		this.nInput = inputnumber;
		this.nOutput = outputnumber;

		try {
			this.nState = getIntProperty(properties, "num_of_states");

			this.state_num_change_allowed = getBooleanProperty(properties,
					"state_num_change_allowed");
			this.generation_mode = getGenerationModeFromProperty(properties,
					"generation_mode");
			this.distance_calc_method = getDistanceCalcMethodFromProperty(
					properties, "distance_calc_method");
			this.value_count_above_to_threshold = getIntProperty(properties,
					"value_count_above_to_threshold");

			this.mutate_add_state_prob = getFloatProperty(properties,
					"mutate_add_state_prob");
			this.mutate_mod_tr_nextstate_prob = getFloatProperty(properties,
					"mutate_mod_tr_nextstate_prob");
			this.mutate_mod_tr_output_prob = getFloatProperty(properties,
					"mutate_mod_tr_output_prob");
			this.mutate_mod_init_state_prob = getFloatProperty(properties,
					"mutate_mod_init_state_prob");
			this.mutate_del_state_prob = getFloatProperty(properties,
					"mutate_del_state_prob");
			this.mutate_del_tr_prob = getFloatProperty(properties,
					"mutate_del_tr_prob");
			this.mutate_threshold_prob = getFloatProperty(properties,
					"mutate_threshold_prob");

			this.threshold_units = getIntProperty(properties, "threshold_units");
			this.output_units = getIntProperty(properties, "output_units");
		} catch (Exception e) {
			System.err.println("Couldn't load evo properties, using defaults.");
		}

	}

	public boolean isFixedStateFSM() {
		return !this.state_num_change_allowed;
	}

	public int getNumOfStates() {
		return this.nState;
	}

	/**
	 * Returns generation mode of MealyFSM.
	 * 
	 * @see GenerationMode
	 */
	public GenerationMode getGenerationMode() {
		return this.generation_mode;
	}

	/**
	 * Returns distance calculation method.
	 * 
	 * @see DistanceCalc
	 */
	public DistanceCalc getDistanceCalcMethod() {
		return this.distance_calc_method;
	}

	/**
	 * Returns count of values above which threshold should be used. By setting
	 * this, input values which can have many values, can automatically be
	 * thresholded and transformed into e.g. a binary input value.
	 * 
	 * @see InputMapper
	 */
	public int getValueCountAboveToThreshold() {
		return value_count_above_to_threshold;
	}

	// STATIC functions that extract different type of values from properties
	// loaded into memory.

	/**
	 * Returns a boolean property from properties.
	 * 
	 * @param properties
	 *            properties loaded into memory as a hashtable
	 * @param property
	 *            name of the property
	 */
	private static boolean getBooleanProperty(
			Hashtable<String, XMLFieldEntry> properties, String property)
			throws Exception {
		XMLFieldEntry entry = properties.get(property);
		String value = entry.getValue();

		if (value.toLowerCase().equals("true"))
			return true;
		else if (value.toLowerCase().equals("false"))
			return false;
		else
			throw new Exception("Value should be true or false!");
	}

	/**
	 * Returns the generation mode of MealyFSM from properties.
	 * @param properties
	 *            properties loaded into memory as a hashtable
	 * @param property
	 *            name of the property
	 */
	private static GenerationMode getGenerationModeFromProperty(
			Hashtable<String, XMLFieldEntry> properties, String property)
			throws Exception {
		XMLFieldEntry entry = properties.get(property);
		String value = entry.getValue();

		return GenerationMode.valueOf(value.toUpperCase());
	}

	/**
	 * Returns the distance calculation method of MealyFSM from properties.
	 * @param properties
	 *            properties loaded into memory as a hashtable
	 * @param property
	 *            name of the property
	 */
	private static DistanceCalc getDistanceCalcMethodFromProperty(
			Hashtable<String, XMLFieldEntry> properties, String property)
			throws Exception {
		XMLFieldEntry entry = properties.get(property);
		String value = entry.getValue();

		return DistanceCalc.valueOf(value.toUpperCase());
	}

	/**
	 * Returns a Float property from properties.
	 * @param properties
	 *            properties loaded into memory as a hashtable
	 * @param property
	 *            name of the property
	 */
	private static Float getFloatProperty(
			Hashtable<String, XMLFieldEntry> properties, String property) {
		XMLFieldEntry entry = properties.get(property);
		return Float.parseFloat(entry.getValue());
	}

	/**
	 * Returns an Integer property from properties.
	 * @param properties
	 *            properties loaded into memory as a hashtable
	 * @param property
	 *            name of the property
	 */
	private static Integer getIntProperty(
			Hashtable<String, XMLFieldEntry> properties, String property) {
		XMLFieldEntry ns = properties.get(property);
		return Integer.parseInt(ns.getValue());
	}
}
