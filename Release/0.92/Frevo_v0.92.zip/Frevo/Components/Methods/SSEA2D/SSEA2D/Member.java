package SSEA2D;

import java.util.ArrayList;

import core.AbstractRepresentation;
import core.ComponentXMLData;


public class Member {
	static long nextid = 0;
	long id;
	double diff;
	AbstractRepresentation rep;
	public ArrayList<Member> neighbors;
	private SSEA2D parent;

	/**
	 * Create a new member with a new unique ID
	 * 
	 * @param representation
	 *            ComponentXMLdata which is used to create the Members.
	 * @param tde
	 *            Instance of TwoDimensionalEvolution which holds the properties
	 *            for each member.
	 */
	public Member(ComponentXMLData representation, SSEA2D tde, int inputnumber, int outputnumber) {
		id = nextid;
		nextid++;
		parent = tde;
		neighbors = new ArrayList<Member>();
		try {
			rep = representation
					.getNewRepresentationInstance(inputnumber, outputnumber,
							parent.getRandom());
		} catch (InstantiationException e) {
			e.printStackTrace();
		}
	}
}
