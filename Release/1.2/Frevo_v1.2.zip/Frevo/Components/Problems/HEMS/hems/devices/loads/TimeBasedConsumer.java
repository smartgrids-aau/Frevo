package hems.devices.loads;


import hems.devices.mainGrid.capabilityModel.CapabilityModel;
import hems.market.priceModel.PriceModel;

import java.util.Calendar;

public class TimeBasedConsumer extends OperationModel {

private CapabilityModel capability;
private int allocatedPower;
private boolean enabledToRun;
private boolean previousStatus;

	public TimeBasedConsumer(PriceModel priceSensitivity, CapabilityModel capability){
		super(priceSensitivity);
		
		this.capability = capability;
		this.allocatedPower = 0;
	}
	
	public void updateStatus(Calendar currentTime) {
		
		
		
	}

	public int getDelaySensitivity() {
		return 0;
		// When used by the gridAgent this is not considered anyway
	}


	@Override
	public void allowToRun(int amount, Calendar simulationTime) {
		// save the current state as previous state
		this.previousStatus = this.enabledToRun;
		
		// set the new status for the next time instant
		this.enabledToRun = amount > 0 ? true : false;
		
		// keep track of allocated power
		this.allocatedPower = amount;
		
		// TODO: do we need to reward allocated power?
	}
	
	@Override
	public boolean isRunning() {
		return this.enabledToRun;
	}

	/**
	 * Returns the demand for the given allocation time
	 */
	@Override
	public int getFutureDemand(Calendar simulationTime, Calendar allocationTime) {
		return capability.getCapability(allocationTime);
	}

	@Override
	public OperationModel clone() {
		return new TimeBasedConsumer(this.priceSensitivity, this.capability);
	}

	@Override
	public int getPowerDemand() {
		int demand = 0;
		
		if(this.enabledToRun) demand = this.allocatedPower;
		
		return demand;
	}

	@Override
	public double getAverageInterruptionTime() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double getAverageRelativeInterruptionTime() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double getAverageRelativeWaitedTimeToStartIntermediateStates() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double getAverageWaitedTimeToStartIntermediateStates() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double getAverageRelativeTimeToStartDevice() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double getAverageWaitedTimeToStartDevice() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isWithinHardDeadline(Calendar simulationTime) {
		return true;
	}

	@Override
	public double getCumulativeReward() {
		return 0;
	}
}
