package hems.market.priceModel;

import java.util.Calendar;

public interface PriceModel {

	public double getPrice(Calendar time);
}
