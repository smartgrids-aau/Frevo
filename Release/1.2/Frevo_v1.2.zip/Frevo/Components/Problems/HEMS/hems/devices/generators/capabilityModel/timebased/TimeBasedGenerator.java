package hems.devices.generators.capabilityModel.timebased;

import hems.devices.generators.Generator;
import hems.devices.generators.weather.IntervalBasedWeather;
import hems.devices.generators.weather.Weather;
import hems.devices.mainGrid.capabilityModel.CapabilityModel;

import java.util.Calendar;
import java.util.List;

public class TimeBasedGenerator implements Generator{

	private CapabilityModel availability;
	
	public TimeBasedGenerator(CapabilityModel availability){
		this.availability = availability;
	}

	@Override
	public double getCurrentProduction(Calendar date, Weather weather) {	
		return availability.getCapability(date);
	}
	
}
