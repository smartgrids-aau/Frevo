package hems.display.networkStatus;

import hems.Market;
import hems.devices.Agent;
import hems.devices.mainGrid.GridAgent;
import hems.market.Transaction;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Paint;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Ellipse2D;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import org.apache.commons.collections15.Transformer;

import edu.uci.ics.jung.algorithms.layout.Layout;
import edu.uci.ics.jung.algorithms.layout.SpringLayout;
import edu.uci.ics.jung.graph.DirectedSparseMultigraph;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.visualization.VisualizationViewer;
import edu.uci.ics.jung.visualization.control.DefaultModalGraphMouse;
import edu.uci.ics.jung.visualization.control.ModalGraphMouse;
import edu.uci.ics.jung.visualization.decorators.ToStringLabeller;
import edu.uci.ics.jung.visualization.renderers.Renderer.VertexLabel.Position;

public class TradersView extends JPanel{
	
	public Graph<Node, Link> g;
	private Layout<Node, Link> layout;
	public VisualizationViewer<Node, Link> graphView;
	
	private HashMap <String, Node> nodes;
	
	public TradersView(){		
		this.setPreferredSize(new Dimension(700,199));
		this.setLayout(new BorderLayout());
		
		g = new DirectedSparseMultigraph<Node, Link>();
		nodes = new HashMap<String, Node>();
		
		layout = new SpringLayout<Node, Link>(g);
		layout.setSize(new Dimension(630,190));
		layout.initialize();
		
		graphView  = new VisualizationViewer<Node, Link>(layout);
		graphView.setPreferredSize(new Dimension(670,195));
		//graphView.getRenderContext().setVertexStrokeTransformer(new ConstantTransformer(new BasicStroke(1.0f)));
		
		graphView.getRenderContext().setVertexStrokeTransformer(new VertexStrokeDesigner());
		graphView.getRenderContext().setVertexShapeTransformer(new VertexShapeDesigner());
		graphView.getRenderContext().setVertexFillPaintTransformer(new VertexDesigner(g));
		graphView.getRenderContext().setVertexLabelTransformer(new ToStringLabeller());
		graphView.getRenderContext().setEdgeLabelTransformer(new ToStringLabeller());
		graphView.getRenderer().getVertexLabelRenderer().setPosition(Position.CNTR);
		
		DefaultModalGraphMouse gm = new DefaultModalGraphMouse();
		gm.setMode(ModalGraphMouse.Mode.TRANSFORMING);
		graphView.setGraphMouse(gm);
		this.add(graphView, BorderLayout.CENTER);
	}
	
	
	public void update(ArrayList<Agent> prosumers, ArrayList<GridAgent> gridConnections){
		
		graphView.getModel().getRelaxer().pause();
		
		for(Agent p : prosumers){
			boolean type = false;
			if(p.isLoad()){
				type = true;
			}
			if(!nodes.containsKey(p.getName())){
				Node n = new Node(p.getName(), type, p.isRunningItsController());
				nodes.put(p.getName(), n);
				g.addVertex(n);
			}
		}
		
		for(Agent c : gridConnections){
			boolean type = false;
			if(!nodes.containsKey(c.getName())){
				Node n = new Node(c.getName(), type, c.isRunningItsController());
				nodes.put(c.getName(), n);
				g.addVertex(n);
			}
		}
		
		graphView.getModel().getRelaxer().resume();
	}
	
	/**
	 * Updates the edges on the graph according to the given transactions
	 * @param transactions
	 */
	public void update(ArrayList<Agent> prosumers, ArrayList<GridAgent> gridConnections, ArrayList<Transaction> transactions){
		/*
		graphView.getModel().getRelaxer().pause();
		
		// remove all current transactions
		Collection<Link> edges = new LinkedList<Link>(g.getEdges());
		for(Link l : edges) g.removeEdge(l);
		
		for(Transaction t : transactions){
			if(!nodes.containsKey(t.buyer.getName())){
				nodes.put(t.buyer.getName(), new Node(t.buyer.getName(), true));
			}
			if(!nodes.containsKey(t.seller.getName())){
				nodes.put(t.seller.getName(), new Node(t.seller.getName(), true));
			}
			// add the edge to the graph
			g.addEdge(new Link(t.amount), nodes.get(t.seller.getName()), nodes.get(t.buyer.getName()));
		}
		
		graphView.getModel().getRelaxer().resume();
		*/
		
		class Updater implements Runnable{
			private ArrayList<Transaction> transactions;
			private ArrayList<Agent> prosumers;
			private ArrayList<GridAgent> gridConnections;
			
			public Updater(ArrayList<Agent> prosumers, ArrayList<GridAgent> gridConnections, ArrayList<Transaction> transactions){
				this.prosumers = prosumers;
				this.gridConnections = gridConnections;
				this.transactions = transactions;
			}
			
			@Override
			public void run() {
				graphView.getModel().getRelaxer().pause();
				Collection<Link> edges = new LinkedList<Link>(g.getEdges());
				for(Link l : edges) g.removeEdge(l);
				
				// draw all nodes
				for(Agent a : gridConnections){
					if(!nodes.containsKey(a.getName())){
						nodes.put(a.getName(), new Node(a.getName(), true, a.isRunningItsController()));
					}else{
						Node n = nodes.get(a.getName());
						n.poweredController = a.isRunningItsController();
					}
					
				}
				for(Agent a : prosumers){
					if(!nodes.containsKey(a.getName())){
						nodes.put(a.getName(), new Node(a.getName(), true, a.isRunningItsController()));
					}else{
						Node n = nodes.get(a.getName());
						n.poweredController = a.isRunningItsController();
					}
				}
				
				for(Transaction t : transactions){
					// add the edge to the graph
					g.addEdge(new Link(t.amount, t.price), nodes.get(t.seller.getName()), nodes.get(t.buyer.getName()));
				}
				
				layout.initialize(); 
				
				graphView.getModel().getRelaxer().resume();
			}
		}
		SwingUtilities.invokeLater(new Updater(prosumers, gridConnections, transactions));
	}
	
	
	public void clearEdges(){
		
		Collection<Link> edges = new LinkedList<Link>(g.getEdges());
		for(Link l : edges) g.removeEdge(l);
		
	}
	
	public void clear(){
		// create a copy onto which we can iterate
		Collection<Link> edges = new LinkedList<Link>(g.getEdges());
		for(Link l : edges) g.removeEdge(l);
		Collection<Node> nodes = new LinkedList<Node>(g.getVertices());
		for(Node n: nodes){
			g.removeVertex(n);
		}
	}

    
    public class Node{
    	private String name;
    	private boolean type;
    	private boolean poweredController;
    	
    	public Node(String name, boolean type, boolean poweredController) {
    		this.name = name;
    		this.type = type;
    		this.poweredController = poweredController;
    	}
    	
    	@Override
		public String toString() {
    		return name;
    	}

    	public String getName(){
    		return name;
    	}
    	
    	@Override
		public boolean equals(Object object){
    		if(object instanceof Node && ((Node)object).getName().equals(this.name)){
    		    return true;
    		} else {
    		    return false;
    		}
    	}
    }
    
    
    public class Link {
    	private int amount;
    	private double unitPrice;
    	
    	public Link(int amount, double unitPrice) {
    		this.amount = amount;
    		this.unitPrice = unitPrice;
    	}
    	
    	@Override
		public String toString() {
    		return "("+amount+"W"+", "+unitPrice+Market.moneySymbol+")";
    	}
    }
    
    public class VertexStrokeDesigner implements Transformer<Node,Stroke>{

    	private final Stroke[] styles = {
    		new BasicStroke(1.0f),
    		new BasicStroke(
    			      1f, 
    			      BasicStroke.CAP_ROUND, 
    			      BasicStroke.JOIN_ROUND, 
    			      1f, 
    			      new float[] {2f}, 
    			      0f)
    	};
    	
		@Override
		public Stroke transform(Node node) {
			if(node.poweredController){
				return styles[0];
			}else{
				return styles[1];
			}
		}
    	
    }
    
    // TRANSFORMERS: define the aspect of the nodes and edges
    public class VertexShapeDesigner implements Transformer<Node,Shape>{

    	private final Shape[] styles = {
	            new Rectangle(-20, -10, 40, 20),
	            new Ellipse2D.Double(-25, -10, 50, 20) };
    	
		@Override
		public Shape transform(Node node) {
			if(node.type){
				return styles[1];
			}else{
				return styles[0];
			}
		}
    }
    	    
    public class VertexDesigner implements Transformer<Node,Paint>{

    	private Graph<Node, Link> g;
    	
    	public VertexDesigner(Graph<Node, Link> g){
    		this.g = g;
    	}
    	
    	@Override
    	public Paint transform(Node n) {
    	
    		if(g.getNeighborCount(n) > 0){
    			return Color.RED;
    		}else{
    			return Color.GREEN;
    		}
        }
    }

	
	public static void main(String[] args) throws InterruptedException, InvocationTargetException {
		final TradersView view = new TradersView();
		
		JFrame frame = new JFrame("Simple Graph View");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().add(view.graphView);
		
		frame.pack();
		frame.setVisible(true);
		
		Thread.sleep(3000);
		try{
			for(int i =0; i<40; i++){
			/*
				SwingUtilities.invokeAndWait(new Runnable() {
					public void run() {*/
						//view.graphView.getModel().getRelaxer().pause();
						view.clear();
						//view.g = new DirectedSparseMultigraph<Node, Link>();
						//view.layout.setGraph(view.g);
						//view.graphView.setGraphLayout(view.layout);
						
						/*
						SwingUtilities.invokeLater(new Runnable() {
							public void run() {
								view.clear();
							}
						});
						*/
						
						// Add some vertices. From above we defined these to be type Integer.
				        Node grid = view.new Node("Grid", false, true);
				        Node a = view.new Node("A", true, true);
				        Node b = view.new Node("B", true, true);
				        Node c = view.new Node("C", true, true);
				        view.g.addVertex(grid);
				        view.g.addVertex(a);
				        view.g.addVertex(b);
				        view.g.addVertex(c);
				        // g.addVertex((Integer)1);  // note if you add the same object again nothing changes
				        // Add some edges. From above we defined these to be of type String
				        // Note that the default is for undirected edges.
				        view.g.addEdge(view.new Link(2, 0.5), grid, a); 
				        view.g.addEdge(view.new Link(2, 0.5), a, b);
				        
				        //view.graphView.getModel().getRelaxer().resume();
				/*
					}
				});*/
		        //view.repaint();
		        Thread.sleep(4);
			}
		}catch(Exception e){
			System.out.println(e.getCause());
		}
	}
}
