package hems.devices.storage;

public class HighBatteryCurrentException extends Exception {
	
	public HighBatteryCurrentException(String message){
		super(message);
	}

	public HighBatteryCurrentException(){
		
	}
}
