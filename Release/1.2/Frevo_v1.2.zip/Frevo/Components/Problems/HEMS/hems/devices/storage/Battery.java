package hems.devices.storage;

import java.io.FileWriter;
import java.io.IOException;

public class Battery {
	
	protected double nominalVoltage;					// operation voltage for the battery
	protected double storageCapacity;
	
	protected boolean exponentialBatteryCurve;
	
	protected double chargingRate;
	protected double chargingEfficiency;
	protected double dischargingRate;
	protected double dischargingEfficiency;
	
	protected double stateOfCharge;
	
	protected double internalCapacitor;

	protected double selfdischargingResistance;
	
	/* http://www.pa.msu.edu/courses/1997spring/phy232/lectures/kirchoff/rc.html
	 * In a flat faces capacitor we have:
	 * 
	 *  Discharging ---
	 *  V(t) = Vo e^(-t/RC)
	 *  I(t) = Io e^(-t/RC)
	 *  Q(t) = Qo e^(-t/RC)
	 *  
	 *  Charging ---
	 *  V(t) = Vfull (1 - e^(-t/RC))
	 *  I(t) = Io e^(-t/RC)
	 *  Q(t) = Qfull (1 - e^(-t/RC)) 
	 */
	
	public Battery(	double nominalVoltage,			// V
					double storageCapacity,			// Ah
					double initialStateOfCharge,	// %
					double chargingRate,			// capacity %
					double chargingEfficiency,		// %
					double dischargingRate,			// capacity %
					double dischargingEfficiency){	// %
		this.chargingRate = chargingRate;
		this.chargingEfficiency = chargingEfficiency;
		this.dischargingRate = dischargingRate;
		this.dischargingEfficiency = dischargingEfficiency;
		
		this.stateOfCharge = initialStateOfCharge;
		
		this.storageCapacity = storageCapacity;
	
		// Given that 1Ah is equal to 3600 As, which is 3600 C
		// Given that for a flat surface capacitor we have that Vc = Q / C -> C = Q / Vc
		this.internalCapacitor = (storageCapacity * 3600.0) / nominalVoltage;
		// the problem with a regular capacitor is that the voltage also drops exponentially
		// when drawing a steady current of let's say storageCapacity A for 1 h.
		
		this.exponentialBatteryCurve = false;
	}
		
	public void setSelfDischarging(double selfdischargingResistance){
		this.selfdischargingResistance = selfdischargingResistance;
	}	
	
	public void setBatteryCurve(boolean exponential){
		this.exponentialBatteryCurve = exponential;
	}
	
	public double getEquivalentCapacitance(){
		return this.internalCapacitor;
	}
	
	public double getBatteryMaxCharge(){
		return this.storageCapacity * 3600;
	}
	
	public double getBatteryCapacity(){
		return this.storageCapacity;
	}
	
	/**
	 * Returns the state of charge of the battery
	 * meaning the percentage of charge
	 * @return
	 */
	public double getStateOfCharge(){
		return this.stateOfCharge;
	}
	
	/**
	 * Returns the state of discharge of the battery
	 * meaning the percentage of discharge
	 * @return
	 */
	public double getStateOfDischarge(){
		return 1.0 - this.stateOfCharge;
	}
	
	/**
	 * Returns the amount of Ah available to be discharged
	 * @return
	 */
	public double getAvailableAmount(){
		return this.stateOfCharge * this.storageCapacity;
	}
	
	public double getAvailableCharge(){
		return getAvailableAmount() * 3600.0;
	}
	
	/**
	 * Returns the amount in Ah available to be charged
	 * @return
	 */
	public double getDischargeAmountToFill(){
		return this.getStateOfDischarge() * this.storageCapacity;
	}
	
	public double estimateChargingTimeInHoursAtGivenCurrent(double current){
		return this.getDischargeAmountToFill() / current;
	}
	
	public double estimateChargingTimeInSecondsAtGivenCurrent(double current){
		return this.estimateChargingTimeInHoursAtGivenCurrent(current) * 3600.0;
	}
	
	/**
	 * The way the voltage drops at the terminals is different for each battery type
	 * @return
	 */
	public double getVoltageAtTerminals(){
		// return V = Q / C
		return (this.getAvailableAmount() * 3600.0) / this.internalCapacitor;
	}
	
	/**
	 * Updates the SOC based on the self-discharge resistance
	 * No load is currently connected at the battery
	 */
	public void updateStateOfChargeWhileDisconnected(){
		if(this.selfdischargingResistance > 0){
			// current is flowing through the selfdischarging resistance
			double current = this.getVoltageAtTerminals() / this.selfdischargingResistance;
			// current in Amperes equals C/1sec which we can subtract from the available charge
			double decrement = current /
								(this.getAvailableAmount() * 3600.0);
			// compute percentage of charge lost for the decrement
			this.stateOfCharge -= decrement / this.storageCapacity;
		}
		// the case in which the resistance is 0 would be a short circuit, which we do not model
		// as it makes no sense for this
	}
	
	/**
	 * Increases the state of charge based on the current (ingoing) flowing current
	 * @param current
	 * @throws HighBatteryCurrentException 
	 */
	public double charge(double current, double chargingResistance) throws HighBatteryCurrentException{
		
		if(current > this.storageCapacity * this.chargingRate)
			throw new HighBatteryCurrentException("Charging current is too high and might destroy the storage element");
		
		double increment = 0;
		if(exponentialBatteryCurve){
			// esponential model: Q(t) = Qmax (1 - e^(-t/RC))
			
			// the idea of this model is that given a fixed charging resistance and a voltage we have a progressive reduction of charging current
			// and a progressive increase of the voltage at the terminal, given the more presence of charges in the capacitor
			// Nevertheless, theoretically we might be able to change the current over time, such as when having a current generator
			// rather than a voltage generator.
			
			// compute relationship between charging time at the current provided current
			double chargedTimes = (this.getAvailableCharge() / current); 		// seconds taken to charge the battery at the given charge and provided current
			System.out.print("t0:"+chargedTimes);
			// compute current charge based on the existing one inside
			increment = getBatteryMaxCharge() * 
							(1.0 - Math.exp(- (chargedTimes+1) / (chargingResistance*this.internalCapacitor) ));
			
			// consider the charging efficiency to waste part of the charge
			increment *= this.chargingEfficiency;
			
			// compute the percentage of increment for the state of charge
			this.stateOfCharge = increment / getBatteryMaxCharge();
			
			// ----
			chargedTimes = (this.getAvailableCharge() / current); System.out.print("t0:"+chargedTimes+", ");
		}else{
			// linear model
			// consider the charging efficiency to waste part of the charge
			increment = (current * this.chargingEfficiency) / getBatteryMaxCharge();
			
			// compute the percentage of increment for the state of charge
			this.stateOfCharge += increment;	
		}
		
		return increment;
	}
	
	/**
	 * Decreases the state of charge based on the current (outgoing) flowing current
	 * When discharging we assume that the voltage remains constant
	 * while the drawn current depends on the connected load and the discharging efficiency
	 * 
	 * @param current
	 * @throws HighBatteryCurrentException 
	 */
	public double discharge(double current, double dischargingResistance) throws HighBatteryCurrentException{
		
		if(current > this.storageCapacity * this.dischargingRate)
			throw new HighBatteryCurrentException("Discharging current is too high and might destroy the storage element");
		
		double decrement = 0;
		if(exponentialBatteryCurve){
			// esponential model: Q(t) = Qo e^(-t/RC) 
			double dischargedTimes = (this.getDischargeAmountToFill() * 3600.0) / current; System.out.print("t0:"+dischargedTimes+", ");
			
			decrement = this.getBatteryMaxCharge() * Math.exp(- (dischargedTimes+1) / (dischargingResistance*this.internalCapacitor));
			//decrement = this.getAvailableAmount() * Math.exp(- 1 / (dischargingResistance*this.internalCapacitor));
			
			decrement *= this.dischargingEfficiency;	// consider discharging losses
			
			// compute the percentage of decrement for the state of charge
			this.stateOfCharge = decrement / getBatteryMaxCharge();
			
			// -----
			dischargedTimes = (this.getDischargeAmountToFill() * 3600.0) / current; System.out.print("t1:"+dischargedTimes);
		}else{
			// Linear model: irrealistic but simple
			decrement = (current * this.dischargingEfficiency) / this.getBatteryMaxCharge();
			// compute the percentage of decrement for the state of charge
			this.stateOfCharge -= decrement;
		}
		
		return decrement;
	}
	
	public static void main(String [] args) {
		Battery b = new Battery(12.0,	// nominal voltage
								1.8,	// size in Ah
								0.5,	// initial SOC
								1.0,	// charging rate
								1.0,	// charging efficiency
								1.0,	// discharging rate
								1.0);	// discharging efficiency
		//b.setCircuitParameters(1, 1, 1000000);
		b.setBatteryCurve(true);
		
		System.out.println("Battery charge is "+b.getStateOfCharge()+"%, discharge is then "+b.getStateOfDischarge()+"%");
		System.out.println("\t"+b.getAvailableAmount()+" Ah is left, "+b.getDischargeAmountToFill()+" Ah was used out of "+b.getBatteryCapacity()+" Ah");
		System.out.println("\tMeaning "+(b.getAvailableAmount()*3600.0)+"C left, "+(b.getDischargeAmountToFill()*3600.0)+" used out of "+(b.getBatteryCapacity()*3600)+"C");
		System.out.println("Current voltage is "+b.getVoltageAtTerminals()+" V");
		System.out.println("The battery is like a "+b.getEquivalentCapacitance()+" F");
		
		double chargeValue = b.getAvailableCharge();
		
		// -----
		boolean charge = false;
		
		if(charge){
			double chargingCurrent = 1.8;
			double chargingResistance = 3;
						
			double chargedTimes = (chargeValue / chargingCurrent);
			System.out.println("initial:"+chargeValue+", SOC:"+(chargeValue/b.getBatteryMaxCharge())+", "+chargedTimes+" secs");
			
			System.out.println("Charging resistance:"+chargingResistance+" Ohm");
			int expectedSeconds = (int) b.estimateChargingTimeInSecondsAtGivenCurrent(chargingCurrent);
			System.out.println("To fully charge the battery at "+chargingCurrent+"A it takes "+b.estimateChargingTimeInSecondsAtGivenCurrent(chargingCurrent)+" secs ("+b.estimateChargingTimeInHoursAtGivenCurrent(chargingCurrent)+" hours)");
			
			try{
				FileWriter writer = new FileWriter("/Users/andreamonacchi/Desktop/battery_charge.csv");
				
				writer.append(-1+","+0+","+b.getStateOfCharge()+","+b.getAvailableCharge()+","+b.getVoltageAtTerminals()+"\n");
				// Simulate each second of charge of the battery
				//while(b.getStateOfCharge() < 1.0){
				for(int i = 0; i < expectedSeconds ; i++){
					//System.out.println("Charging battery ("+i+")");
					double increment = b.charge(chargingCurrent, chargingResistance);
					System.out.println("\t Charge:"+b.getStateOfCharge()+"%, Discharge:"+b.getStateOfDischarge()+"%, "+b.getVoltageAtTerminals()+" V");
					// Thread.sleep(5);
					
					writer.append(i+","+increment+","+b.getStateOfCharge()+","+b.getAvailableCharge()+","+b.getVoltageAtTerminals()+"\n");
				}
				
				writer.flush();
				writer.close();
			}catch(HighBatteryCurrentException e){
				System.out.println(e.getMessage());
				
			} catch (IOException e) {
				e.printStackTrace();
			}	
		}else{
			
			double dischargingCurrent = 1.8;
			double dischargingResistance = 4;
			
			double chargedTimes = (chargeValue / dischargingCurrent);
			System.out.println("initial:"+chargeValue+", SOC:"+(chargeValue/b.getBatteryMaxCharge())+", "+chargedTimes+" secs");
			
			int expectedSeconds = (int) b.estimateChargingTimeInSecondsAtGivenCurrent(dischargingCurrent);
			
			try{
				FileWriter writer = new FileWriter("/Users/andreamonacchi/Desktop/battery_discharge.csv");
				writer.append(-1+","+0+","+b.getStateOfCharge()+","+b.getAvailableCharge()+","+b.getVoltageAtTerminals()+"\n");
				
				int i = 0;
				while(b.getStateOfCharge() > 0.152){
				//for(int i = 0; i < expectedSeconds ; i++){
					System.out.print(i+") ");
					double decrement = b.discharge(dischargingCurrent, dischargingResistance);
					System.out.println("\t Charge:"+b.getStateOfCharge()+"%, Discharge:"+b.getStateOfDischarge()+"%, "+b.getVoltageAtTerminals()+" V");
					writer.append(i+","+decrement+","+b.getStateOfCharge()+","+b.getAvailableCharge()+","+b.getVoltageAtTerminals()+"\n");
					i++;
				}
				writer.flush();
				writer.close();
				
			}catch(HighBatteryCurrentException e){
				System.out.println(e.getMessage());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		
	}
}
