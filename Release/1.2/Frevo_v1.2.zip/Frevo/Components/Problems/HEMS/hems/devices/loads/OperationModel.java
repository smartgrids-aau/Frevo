package hems.devices.loads;

import hems.devices.modelManager.RemoteManagerUanavailableException;
import hems.display.report.DiscomfortTable;
import hems.market.priceModel.PriceModel;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Random;

public abstract class OperationModel implements Cloneable {
	
	protected SimpleDateFormat format = new SimpleDateFormat("yyyy MMM dd HH:mm:ss");
	
	protected DiscomfortTable table;					// used to notify updates to the interface upon operation events
	protected Random randomGen;
	protected PriceModel priceSensitivity;
	protected boolean serviceFlexibility;				// models the flexibility of the service wrt being shifted
	
	// *** properties of the simulation ***
	protected ArrayList<OperationStats> operations;		// stats per each operation of the device
	protected OperationStats currentOperationStats;		// reference to the current operation -> to be able to modify it after adding it to the list
	
	// *** Fitness value ***
	protected double moneySpentWithGrid;				// keeps track of transactions with the grid
	protected double moneySpentLocally;					// keeps track of transactions with local generators
	protected int timesUnallocatedWithinHardDeadline;	// TIMES power was not allocated within a hard deadline (useful to give a high penalty to the controller)
	protected int timesInflexibleUnallocated;
	
	public OperationModel(PriceModel priceSensitivity){
		this.priceSensitivity = priceSensitivity;
		
		moneySpentWithGrid = 0.0;
		moneySpentLocally = 0.0;
		timesUnallocatedWithinHardDeadline = 0;
		timesInflexibleUnallocated = 0;
		
		// simulation properties
		operations = new ArrayList<OperationStats>();
	}
	
	public abstract OperationModel clone();
	
	public void setRandomGen(Random randomGen){
		this.randomGen = randomGen;
	}
	
	/**
	 * Sets a reference to the discomfort table to keep the interface up to date
	 * @param table
	 */
	public void setTableReference(DiscomfortTable table){
		this.table = table;
	}
	
	/**
	 * Returns true if the device operation is a flexible service
	 * @return
	 */
	public boolean isAFlexibleService(){
		return this.serviceFlexibility;
	}
	
	/**
	 * Sets the operation of the device as a flexible service
	 */
	public void setAsFlexible(){
		this.serviceFlexibility = true;
	}
	
	/**
	 * Returns the profit for the buyer, as difference between the wished and actually payed price
	 * @param currentTime
	 * @param actualPrice
	 * @return
	 */
	public double getBuyerProfit(Calendar currentTime, double actualPrice){
		return this.priceSensitivity.getPrice(currentTime) - actualPrice;
	}
	
	/**
	 * Returns the price sensitivity for the device
	 * @param currentTime
	 * @return
	 */
	public double getPriceSensitivity(Calendar currentTime){
		return priceSensitivity.getPrice(currentTime);
	}
	
	public abstract boolean isRunning();
	
	public abstract void allowToRun(int amount, Calendar simulationTime);
	
	public abstract void updateStatus(Calendar currentTime);
	
	public abstract boolean isWithinHardDeadline(Calendar simulationTime);
	
	public abstract int getDelaySensitivity();
	
	public abstract int getPowerDemand();
	
	public abstract int getFutureDemand(Calendar simulationTime, Calendar allocationTime) throws RemoteManagerUanavailableException;
	
	// -------------------------------
	/**
	 * Returns the number of times the devices was not started within the hard deadline
	 * @return
	 */
	public int getTimesUnallocatedWithinHardDeadline(){
		return timesUnallocatedWithinHardDeadline;
	}
	
	/**
	 * Increases the number of times the devices was not allocated, in spite of its inflexibility
	 */
	public void addTimeInflexibleUnallocated(){
		timesInflexibleUnallocated++;
	}
	
	/**
	 * Returns the times the device was not unallocated, in spite of its inflexibility
	 * @return
	 */
	public int getTimesInflexibleUnallocated(){
		return timesInflexibleUnallocated;
	}
	
	/**
	 * Returns the expenses for energy bought from the grid
	 * @return
	 */
	public double getGridEnergyCost(){
		return this.moneySpentWithGrid;
	}
	
	/**
	 * Add the cost of energy bought from the grid
	 * @param cost
	 */
	public void addGridCost(double cost){
		this.moneySpentWithGrid += cost;
	}
	
	/**
	 * Returns the expenses for energy bought from the local generators
	 * @return
	 */
	public double getMoneySpentLocally(){
		return this.moneySpentLocally;
	}
	
	/**
	 * Adds expenses for energy bought from local generators
	 * @param cost
	 */
	public void addLocalMarketCost(double cost){
		this.moneySpentLocally += cost;
	}
	
	public abstract double getAverageInterruptionTime();
	public abstract double getAverageRelativeInterruptionTime();
	public abstract double getAverageRelativeWaitedTimeToStartIntermediateStates();
	public abstract double getAverageWaitedTimeToStartIntermediateStates();
	public abstract double getAverageRelativeTimeToStartDevice();
	public abstract double getAverageWaitedTimeToStartDevice();
	public abstract double getCumulativeReward();
	
}
