package hems.display.report;

import java.awt.Color;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.swing.BoxLayout;
import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.time.Second;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.ui.RectangleEdge;
import org.jfree.ui.RectangleInsets;

public class DeviceCard extends JPanel{
	
	private static final long serialVersionUID = 7003362218512469626L;

	private ChartPanel chartPanel;
	private TimeSeriesCollection dataset;
	
	public DeviceCard(String title, String x, String y, String[] titles){
		
		dataset = new TimeSeriesCollection();
		
		for(String t: titles){
			dataset.addSeries(new TimeSeries(t));
		}
		
		JFreeChart chart = ChartFactory.createTimeSeriesChart(
							title,		// title
							x,			// x-axis label
							y,   		// y-axis label
							dataset,            // data
							true,               // create legend?
							true,               // generate tooltips?
							false               // generate URLs?
							);

		// transparent background
		chart.setBackgroundPaint(new Color(0xFF, 0xFF, 0xFF, 0));
		chart.getLegend().setPosition(RectangleEdge.TOP);
		XYPlot plot = (XYPlot) chart.getPlot();
		plot.setBackgroundPaint(Color.lightGray);
		plot.setDomainGridlinePaint(Color.white);
		plot.setRangeGridlinePaint(Color.white);
		plot.setAxisOffset(new RectangleInsets(5.0, 5.0, 5.0, 5.0));
		plot.setDomainCrosshairVisible(true);
		plot.setRangeCrosshairVisible(true);
		
		plot.setDomainPannable(true);
		plot.setRangePannable(true);

		XYItemRenderer r = plot.getRenderer();
		if (r instanceof XYLineAndShapeRenderer) {
			XYLineAndShapeRenderer renderer = (XYLineAndShapeRenderer) r;
			renderer.setBaseShapesVisible(true);
			renderer.setBaseShapesFilled(true);
			renderer.setDrawSeriesLineAsPath(true);
		}
		
		DateAxis axis = (DateAxis) plot.getDomainAxis();
		axis.setDateFormatOverride(new SimpleDateFormat("yyyy MMM dd HH:mm:ss"));		
		
		chartPanel = new ChartPanel(chart);
		chartPanel.setFillZoomRectangle(true);
		chartPanel.setMouseWheelEnabled(true);
		
		chartPanel.setMinimumDrawWidth( 0 );
		chartPanel.setMinimumDrawHeight( 0 );
		chartPanel.setMaximumDrawWidth( 1920 );
		chartPanel.setMaximumDrawHeight( 1200 );
	
		this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		this.add(chartPanel);
	}
	
	public void addEntry(Calendar time, double[] values){
		for(int i = 0; i < values.length; i++){
			dataset.getSeries(i).addOrUpdate(new Second(time.getTime()), values[i]);
		}
	}
}
