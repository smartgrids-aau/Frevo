package hems.solvers;

import hems.devices.Agent;
import hems.devices.TraderWillingness;
import hems.devices.agents.DAAgent;
import hems.devices.generators.weather.Weather;
import hems.devices.mainGrid.GridAgent;
import hems.market.Offer;
import hems.market.Transaction;
import hems.solvers.Solver.TradeResult;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Random;

public class ClockAuction extends Solver{

	public ClockAuction(boolean allowGridToGridEnergyTrade) {
		super(allowGridToGridEnergyTrade);
		
	}

	@Override
	public TradeResult simulateAuction(Calendar currentTime, Calendar allocationTime, Weather currentWeather, 
											double localPrice,
											int iterations, Random randomGen,
											HashMap<String, TraderWillingness> willingnessToTrade,
											ArrayList<GridAgent> grids, ArrayList<Agent> prosumers) {
	/*	
		ArrayList<Transaction> matches = new ArrayList<Transaction>();	// temporary matches
		
		double closing_price = 0;
		
		// we assume the presence of only a grid and a generator in the current version
		Offer grid_demand;
		Offer grid_supply;
		for(GridAgent grid : grids){
			grid_demand = grid.getBIDOffer(currentTime, allocationTime, currentWeather);
			grid_supply = grid.getASKOffer(currentTime, allocationTime, currentWeather);
		}
		
		Offer renewable_supply;
		for(Agent a : prosumers){ 
			if(a.isGenerator()){
				renewable_supply = a.
			}
		}
		
		// Get a shallow copy to avoid changing the order also on the interface
		ArrayList<DAAgent> prosumersCopy = new ArrayList<DAAgent>();
		for(Agent a : prosumers) prosumersCopy.add((DAAgent) a);
		
		while( proposed_price > feed_in_tariff){
			
		}
		
		return new TradeResult(fr.approvedTransactions,
				fr.participatingTraders,
				fr.allowedToStart,
				equilibriumResult != null ? equilibriumResult.auctionPrice : 0);
				*/
		return null;
	}

	
}
