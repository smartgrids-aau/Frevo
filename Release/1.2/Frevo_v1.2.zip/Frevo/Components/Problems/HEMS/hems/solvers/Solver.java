package hems.solvers;

import hems.devices.Agent;
import hems.devices.TraderWillingness;
import hems.devices.generators.weather.Weather;
import hems.devices.mainGrid.GridAgent;
import hems.display.marketView.MarketView;
import hems.market.MarketStatus;
import hems.market.Offer;
import hems.market.Offer.OfferType;
import hems.market.Transaction;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Random;

public abstract class Solver {

	protected boolean allowGridToGridEnergyTrade;
	protected boolean allowBIDfragmentation;
	protected boolean allowGridfragmentation;
	
	public Solver(boolean allowGridToGridEnergyTrade){
		this.allowGridToGridEnergyTrade = allowGridToGridEnergyTrade;
	}
	
	protected MarketView marketView;	// null when operating in CLI mode
	/**
	 * Sets the market view on the solver, so that the market evolution can be displayed on the GUI
	 * @param reference
	 */
	public void setMarketView(MarketView reference){
		this.marketView = reference;
	}
	
	/**
	 * Given an array of matched offers, it selects the ones that are related to the operation
	 * of the appliance and added up provide enough power for its supply
	 * @param currentTime
	 * @param pendingTransactions: matched offers waiting to be approved
	 * @param participatingTraders: traders which granted idle power for the next instant
	 * @return
	 */
	protected FilterResult filterTransactions(ArrayList<Transaction> pendingTransactions, 
												HashSet<Agent> participatingTraders,
												HashSet<Agent> temporarilyFullyAllocatedTraders){
		
		for(int j=0; j < pendingTransactions.size(); ){
			Transaction t = pendingTransactions.get(j);
			
			// check transaction type to distinguish the right list
			if(t.type == OfferType.REGULAR){
				// regular offer: buyers can be local agents or a grid connection
				if(temporarilyFullyAllocatedTraders.contains(t.buyer) || t.buyer instanceof GridAgent){
					// only appliances are allowed to start	
					j++;
				}else{
					// skip transaction for not completely allocated offer
					pendingTransactions.remove(j);
					// remove generators from which we got the unallocated power
					if(temporarilyFullyAllocatedTraders.contains(t.seller)){
						temporarilyFullyAllocatedTraders.remove(t.seller);
						//System.out.println("\tDEL R_"+t.seller.getName()+"->"+t.buyer.getName()+" ("+t.amount+"), removing "+t.seller.getName());
					}
				}
			}else{
				// idle offer: buyers can only be local agents
				if(participatingTraders.contains(t.buyer)){
					j++;
				}else{
					// remove transaction for not completely allocated offer
					pendingTransactions.remove(j);
					// remove generators from which we got the unallocated power
					if(temporarilyFullyAllocatedTraders.contains(t.seller)){
						temporarilyFullyAllocatedTraders.remove(t.seller);
						System.out.println("\tDEL I_"+t.seller.getName()+"->"+t.buyer.getName()+" ("+t.amount+"), removing "+t.seller.getName());
					}
				}
			}
		}
		return new FilterResult(pendingTransactions,
								participatingTraders,
								temporarilyFullyAllocatedTraders);
	}
	
	/**
	 * Performs a simulation epoch to allocate power at the next allocation time
	 * @param currentTime			Current simulation time
	 * @param allocationTime		allocation time (next time instant)
	 * @param currentWeather		current weather status
	 * @param localPrice			average transaction price last time instant
	 * @param iterations			number of iterations for the auction
	 * @param randomGen				
	 * @param willingnessToTrade	necessity to trade
	 * @param grids					grid connections
	 * @param generators			generators
	 * @param loads					electrical loads
	 * @return
	 */
	public abstract TradeResult simulateAuction(Calendar currentTime, Calendar allocationTime, Weather currentWeather, 
												double localPrice,
												int iterations, Random randomGen, HashMap<String, TraderWillingness> willingnessToTrade,
												ArrayList<GridAgent> grids,	ArrayList<Agent> prosumers);
	
	/**
	 * Given the orderbook it updates the best BID and ASK offers (market status)
	 * @param status
	 * @param buyOffers
	 * @param sellOffers
	 * @return
	 */
	protected MarketStatus updateMarketStatus(MarketStatus status, ArrayList<Offer> buyOffers, ArrayList<Offer> sellOffers){
		for(Offer b : buyOffers){
			if(b.price > status.buyQuote)
				status.buyQuote = b.price;
		}
			
		for(Offer s : sellOffers){
			if(s.price < status.sellQuote)
				status.sellQuote = s.price;
		}		
		return status;
	}


	/**
	 * Displays the message on the market view, as an alert window
	 * @param message
	 */
	protected void promptMarketMessage(String message){
		if(marketView != null && marketView.isMarketViewAvailable() && marketView.isMarketMessagingEnabled()){
			marketView.showAlert(message);
		}
	}
	
	/**
	 * Adds the new offer to the BID orderbook, updating the old offer if already existing
	 * @param orderbook
	 * @param a
	 * @param selectedType
	 * @param newOffer
	 * @return
	 */
	protected ArrayList<Offer> updateBIDOrderbook(ArrayList<Offer> orderbook, Agent a, OfferType selectedType, Offer newOffer){
		boolean found = false;
		int i=0;
		for( ; i<orderbook.size() && !found; i++){
			Offer old = orderbook.get(i);
			if(old.agent.equals(a) && old.getOfferType() == selectedType){
				old.price = newOffer.price;
				old.iteration = newOffer.iteration;
				found = true;
			}
		}
		// if not found add it to the orderbook
		if(!found) orderbook.add(0, newOffer); // add to the first position, the offer should have improved the market status (best)
		return orderbook;
	}
	
	/**
	 * Adds the new offer to the ASK orderbook, updating the old offer if already existing
	 * @param orderbook
	 * @param a
	 * @param newOffer
	 * @return
	 */
	protected ArrayList<Offer> updateASKOrderbook(ArrayList<Offer> orderbook, Agent a, Offer newOffer){
		boolean found = false;
		int i=0;
		for( ; i <orderbook.size() && !found; i++){
			Offer old = orderbook.get(i);
			if(old.agent.equals(a)){								
				old.price = newOffer.price;
				old.iteration = newOffer.iteration;
				found = true;
			}
		}
		// if not found add it to the orderbook
		if(!found) orderbook.add(0, newOffer);	// add to the first position, the offer should have improved the market status (best)
		return orderbook;
	}
	
	/**
	 * Returns the (first) position of an agent in the BID orderbook
	 * @param a
	 * @param orderbook
	 * @param type
	 * @return ranking percentage where 100% means first and 0% last
	 */
	protected double getPositionBIDOrderbook(Agent a, ArrayList<Offer> orderbook, OfferType type){
		// Returns the (first) position of an agent in the orderbook, depending on the offertype of interest
		// the BID orderbook is ordered DESC so the element at position 0 is the best BID
		for(int i = 0; i < orderbook.size(); i++){
			Offer tmp = orderbook.get(i);
			if(tmp.agent.equals(a) && tmp.getOfferType() == type){
				// the agent is found and is position is i
				// therefore when 0 the agent is 100% the ranking while 0% means last position
				return 1.0 - (((double) i) / ((double) orderbook.size()));
			}
		}
		// the agent is either not in the orderbook or in the last position
		return 0.0; // 0% means that the agent ranks last
	}
	
	/**
	 * Returns the (first) position of an agent in the ASK orderbook
	 * @param a
	 * @param orderbook
	 * @return the ranking percentage where 100% means first and 0% last
	 */
	protected double getPositionASKOrderbook(Agent a, ArrayList<Offer> orderbook){
		// Returns the (first) position of an agent in the orderbook, depending on the offertype of interest
		// the ASK orderbook is ordered ASC so the element at position 0 is the best ASK
		for(int i = 0; i < orderbook.size(); i++){
			Offer tmp = orderbook.get(i);
			if(tmp.agent.equals(a)){
				// the agent is found and is position is i
				// therefore when 0 the agent is 100% the ranking while 0% means last position
				return 1.0 - (((double) i) / ((double) orderbook.size()));
			}
		}
		// the agent is either not in the orderbook or in the last position
		return 0.0; // (0% means the agent ranks last)
	}
	
	/**
	 * returns the percentage of already allocated power as a (pending / toberequested) ratio
	 * @param a
	 * @param pendingTransactions
	 * @param toBeRequested
	 * @param type
	 * @return
	 */
	protected double getPercentageAllocatedBIDPower(Agent a, ArrayList<Transaction> pendingTransactions, double toBeRequested, OfferType type){
		double pendingAllocation = 0.0;
		double allocated = 1.0; // we already allocated all necessary (100%) if it's not necessary to trade
		if(toBeRequested > 0){
			// Add up all pending amount for agent a
			for(Transaction t : pendingTransactions) if(t.buyer.equals(a) && t.type.equals(type))	pendingAllocation += t.amount;
			allocated = pendingAllocation / toBeRequested;
		}
		return allocated;
	}
	
	/**
	 * returns the percentage of already allocated power as a (pending / toberequested) ratio
	 * @param a
	 * @param pendingTransactions
	 * @param toBeRequested
	 * @return
	 */
	protected double getPercentageAllocatedASKPower(Agent a, ArrayList<Transaction> pendingTransactions, double toBeRequested){
		double pendingAllocation = 0.0;
		double allocated = 1.0;	// we already allocated all necessary (100%) if nothing is needed
		
		if(toBeRequested > 0){
			// Add up all pending amount for agent a
			for(Transaction t : pendingTransactions) if(t.seller.equals(a))	pendingAllocation += t.amount;
			allocated = pendingAllocation / toBeRequested;
		}
		return allocated;
	}
	
	/**
	 * Specify whether a BID offer can be partially matched
	 * @param divisible
	 */
	protected void allowBIDFragmentation(boolean divisible){
		this.allowBIDfragmentation = divisible;
	}	
	
	
	public class TradeResult{
		// Device enable flags
		public ArrayList<Transaction> approvedTransactions;
		public HashSet<Agent> participatingTraders;
		public HashSet<Agent> allowedToStart;
		
		// approximation of the equilibrium Price, last offer price
		public double equilibriumPrice;
		
		public TradeResult(ArrayList<Transaction> approvedTransactions,
							HashSet<Agent> participatingTraders,
							HashSet<Agent> allowedToStart,
							double equilibriumPrice){
			this.approvedTransactions = approvedTransactions;
			this.participatingTraders = participatingTraders;
			this.allowedToStart = allowedToStart;
			this.equilibriumPrice = equilibriumPrice;
		}
	}
	
	public class FilterResult{
		public ArrayList<Transaction> approvedTransactions;
		public HashSet<Agent> participatingTraders;
		public HashSet<Agent> allowedToStart;
		
		public FilterResult(ArrayList<Transaction> approvedTransactions,
							HashSet<Agent> participatingTraders,
							HashSet<Agent> allowedToStart){
			this.approvedTransactions = approvedTransactions;
			this.participatingTraders = participatingTraders;
			this.allowedToStart = allowedToStart;
		}
	}
	
	public class MatcherResult{
		public ArrayList<Transaction> matched;
		public double auctionPrice;
		public HashSet<Agent> participatingTraders;
		public HashSet<Agent> temporarilyFullyAllocatedTraders;
		
		public ArrayList<Offer> buyOffers;
		public ArrayList<Offer> sellOffers;
		
		public MatcherResult(ArrayList<Offer> buyOffers, ArrayList<Offer> sellOffers,
							ArrayList<Transaction> matched, double auctionPrice, 
							HashSet<Agent> participatingTraders,
							HashSet<Agent> temporarilyFullyAllocatedTraders){
			
			this.buyOffers = buyOffers;
			this.sellOffers = sellOffers;
			
			this.matched = matched;
			this.auctionPrice = auctionPrice;
			this.participatingTraders = participatingTraders;
			this.temporarilyFullyAllocatedTraders = temporarilyFullyAllocatedTraders;
		}
	}
}
