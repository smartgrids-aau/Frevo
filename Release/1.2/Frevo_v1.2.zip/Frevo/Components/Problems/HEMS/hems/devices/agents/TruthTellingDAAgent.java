package hems.devices.agents;

import java.util.Calendar;

import hems.devices.TraderWillingness;
import hems.devices.generators.GenerationModel;
import hems.devices.generators.weather.Weather;
import hems.devices.loads.OperationModel;
import hems.market.MarketStatus;

public class TruthTellingDAAgent extends DAAgent{

	public TruthTellingDAAgent(String name, double credit,
			OperationModel operationModel, GenerationModel generationModel) {
		super(name, credit, operationModel, generationModel);
		
	}

	public TruthTellingDAAgent clone(){
		// build new device with same properties, but leaving out all performance measures
		TruthTellingDAAgent a = new TruthTellingDAAgent(this.name, this.credit, this.operationModel.clone(), this.generationModel.clone());
		a.idlePowerDemand = this.idlePowerDemand;
		
		return a;
	}
	
	protected double makePrice(Calendar simulationTime, Calendar allocationTime, MarketStatus marketStatus, Weather weather, 
			TraderWillingness willingness,
			double positionBIDOrderbook, double alreadyAllocatedBID, double positionASKOrderbook, double alreadyAllocatedASK){
		
		double offerPrice = 0.0;
			
		// willingness.priceSensitivity and willingness.reservationPrice
		// are the modeled ones for regular offers, and the marketLimit/0 for idle offers
		
		if(willingness.tradingTendency > 0.0){
			// Buy at price sensitivity if higher than market status, skip otherwise
			if(willingness.priceSensitivity >= marketStatus.buyQuote) 
				offerPrice = this.operationModel.getPriceSensitivity(simulationTime);
		}else if(willingness.tradingTendency < 0.0){
			// Sell at reservation price, iff lower than market status, skip otherwise
			if(willingness.reservationPrice <= marketStatus.sellQuote)
				offerPrice = this.generationModel.getReservationPrice(simulationTime);
		}	// Skip otherwise (p = 0.0)
			
		return offerPrice;
	}
}
