package hems.market;

import java.util.Calendar;

public class MarketEval {
	public Calendar date;
	public double marketEfficiency;
	
	public MarketEval(Calendar auctionTime){
		this.date = Calendar.getInstance();
		this.date.setTimeInMillis(auctionTime.getTimeInMillis());
		
		this.marketEfficiency = 0.0;
	}
	
	public void clear(){
		marketEfficiency = 0.0;
	}

}
