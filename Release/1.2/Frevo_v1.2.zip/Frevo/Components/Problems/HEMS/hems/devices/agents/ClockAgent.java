package hems.devices.agents;

import java.util.ArrayList;
import java.util.Calendar;

import hems.Market;
import hems.devices.Agent;
import hems.devices.TraderWillingness;
import hems.devices.generators.GenerationModel;
import hems.devices.generators.weather.Weather;
import hems.devices.loads.NotAvailableForTradeException;
import hems.devices.loads.OperationModel;
import hems.market.IllegalOfferException;
import hems.market.Offer;

public class ClockAgent extends Agent{

	public ClockAgent(String name, double credit,
			OperationModel operationModel, GenerationModel generationModel) {
		super(name, credit, operationModel, generationModel);
	
	}
	
	public ClockAgent clone(){
		// build new device with same properties, but leaving out all performance measures
		ClockAgent a = new ClockAgent(this.name, this.credit, this.operationModel.clone(), this.generationModel.clone());
		a.idlePowerDemand = this.idlePowerDemand;
		
		return a;
	}

	public Offer queryController(Calendar simulationTime, Calendar allocationTime, Weather weather, 
								TraderWillingness willingness, 
								double proposedPrice, double excessDemandAtPreviousIteration) throws IllegalOfferException, NotAvailableForTradeException{
		Offer offer = null;
		
		double output = getDemandAtPrice(simulationTime, allocationTime, willingness, 
											proposedPrice, excessDemandAtPreviousIteration);
		
		// the output of the ANN is 0-1 so we need to scale it to [-1, +1], e.g. when [-1, +1] we have 2*1 * n - 1
		double amountPercentage = 2.0 * Market.limitPrice * output - Market.limitPrice;	
		
		// Validate the offer based on the agent willingness
		if(amountPercentage > 0.0){
			// *** BID
			if(willingness.tradingTendency < 0.0){
				this.punishOfferNotReflectingNeeds();
				this.punishOfferNotReflectingNeeds();
						
				throw new IllegalOfferException(this.name+": BID rather than ASK");			// throw an exception to prevent the propagation of the wrong offer
			}else if(willingness.tradingTendency == 0.0){
				this.punishOfferNotReflectingNeeds();
							
				throw new IllegalOfferException(this.name+": BID rather than NOOP");
			}else{
				offer = new Offer( (int) (willingness.amountToBuy * amountPercentage), 
								proposedPrice, true, this, 
								simulationTime, willingness.delayToleranceLeft);
			}
			
			// if the offer was approved we need to check if the price violates the agent's sensitivity
			if(proposedPrice > this.operationModel.getPriceSensitivity(simulationTime)) this.addInsensitivePriceOffer(); 
			
			this.trackPriceOffer(proposedPrice, this.operationModel.getPriceSensitivity(simulationTime), true);
		}else if(amountPercentage < 0.0){
			// ASK
			amountPercentage = Math.abs(amountPercentage);
					
			if(willingness.tradingTendency > 0.0){
				this.punishOfferNotReflectingNeeds(); 
				this.punishOfferNotReflectingNeeds();
	
				throw new IllegalOfferException(this.name+": ASK rather than BID");
			}else if(willingness.tradingTendency == 0.0){
				this.punishOfferNotReflectingNeeds();
				throw new IllegalOfferException(this.name+": ASK rather than NOOP");
			}else{
				// approve the offer, it's an ASK as needed
				offer = new Offer( (int) (willingness.amountToSell * amountPercentage), 
								proposedPrice, false, this, simulationTime);
			}
			if(proposedPrice < this.generationModel.getReservationPrice(simulationTime)) this.addInsensitivePriceOffer();
			
			this.trackPriceOffer(proposedPrice, this.generationModel.getReservationPrice(simulationTime), false);
		}else{
			// NOOP
			amountPercentage = Math.abs(amountPercentage);
			
			// we have to make sure that the agent did actually not want to trade by checking its necessity to buy/sell
			if(willingness.tradingTendency == 0.0){
				throw new NotAvailableForTradeException("No demand/production to trade");
			}else if(willingness.tradingTendency < 0.0){
				// when energy is available it should be sold, but not necessarily
				if(this.generationModel.isAFlexibleService()){
					// flexible generator (e.g., battery), we respect the choice
					throw new IllegalOfferException("NOOP rather than flexible-ASK");
				}else{
					this.punishOfferNotReflectingNeeds();
					throw new IllegalOfferException(this.name+": NOOP rather than inflexible-ASK");
				}
			}else{
				// the agent WOULD like to operate
				if(this.operationModel.isAFlexibleService()){
					throw new IllegalOfferException(this.name	+": NOOP rather than flexible-BID");
				}else{
					// an inflexible load should always pursue the operation
					this.punishOfferNotReflectingNeeds();
					throw new IllegalOfferException(this.name	+" NOOP rather than inflexible-BID");
				}
			}
		}
				
		// we have correctly formulated an offer which has to be accepted to operate
		unacceptedOffer = offer;
		return offer;
	}
	
	protected double getDemandAtPrice(Calendar simulationTime, Calendar allocationTime, TraderWillingness willingness, double proposedPrice, double excessDemandAtPreviousIteration){
		double percentageAmountToTrade = 0;
		
		ArrayList<Float> inputValues = new ArrayList<Float>();
		
		/* Controller:
		 * 								 ________
		 * 		-- reservation price --> |		|
		 * 		-- Hour ---------------> |		|
		 * 		-- Month --------------> |		|
		 * 		-- Weekday ------------> |		|
		 * 		-- offer importance ---> |		|
		 * 		-- trading tendency ---> |		|  --- amount -->
		 * 		-- current price ------> |		|
		 * 		-- price sensitivity --> |		|
		 * 		-- excess demand ------> |		|
		 * 		-- curtailability -----> |		|
		 * 		-- rel delay tolerance-> |		|
		 * 								 *******
		 */
		
		
		// SELLER'S inputs
		inputValues.add((float) (willingness.reservationPrice / Market.limitPrice));
		
		// COMMON inputs
		double dayHour = simulationTime.get(Calendar.HOUR_OF_DAY) / 23;								// Midnight is 0.0, 11 pm is 1.0
		double month = simulationTime.get(Calendar.MONTH) / 11;										// January is 0.0, December is 1.0
		double weekday = simulationTime.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY ? 0.0 :		// Sunday
							simulationTime.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY ? 1.0 :	// Saturday
							0.5;
		
		inputValues.add((float) dayHour);
		inputValues.add((float) month);
		inputValues.add((float) weekday);
		
		inputValues.add((float) willingness.offerImportance);	// is the offer flexible? inflexible/idle = 1.0, flexible sell = 0.0, flexible buy = 0.0 (1st state), 0.5 (intermediate)
		inputValues.add((float) willingness.tradingTendency);	// when 1.0 BUY, when -1.0 SELL, when 0.0 NOOP
		
		inputValues.add((float) proposedPrice);
		
		// BUYER'S inputs
		inputValues.add((float) excessDemandAtPreviousIteration);
		inputValues.add((float) (willingness.priceSensitivity / Market.limitPrice));
		inputValues.add((float) willingness.relativeDelayToleranceLeft);
		
		percentageAmountToTrade = this.brain.getOutput(inputValues).get(0);
		
		return percentageAmountToTrade; 
	}
	
	@Override
	public double computeFitness(double reward, 
			double gridEnergySold, double gridEnergyCosts, double localEnergyCosts,
			double relDevStart, double relStateStart, double relInterruption, 
			double unallocatedInflexibleBID, double unallocatedInflexibleASK,
			
			double violatingDeadline,
			double violatingMarket, double relForbiddenMarket,
			double violatingSensitivity, double relBIDLosses, double relASKLosses,
			double unpoweredController,
			double violatingNeeds, double relDoesNotReflectNeeds
			){
		
		// weight the importance of the completion of operations for the devices
		reward *= Market.rewardFactor;
				
		// The cost is what we are trying to minimize and it is given by:
		double cost = 
			Market.penaltyGridUse * gridEnergyCosts +								// Cost for the energy traded with the grid (both feed-in and purchased from there)
				
			// what happens when the grid price is low for over availability of energy and we have no PV? shouldn't we simply prefer that?	
			localEnergyCosts + 														// Cost for the energy spent locally
				
			// ------------ Penalties on relative values
			(relDevStart > 0.0 ? Market.penaltyDelayedDeviceStart : Market.rewardDeviceStart)			// Cost for delaying the beginning of a device 
											* relDevStart +						
				
			(relStateStart > 0.0 ? Market.penaltyDelayedStateStart : Market.rewardStateStart)			// Cost for delaying the beginning of an intermediate state
											* relStateStart +					
				
			//(relInterruption > 0.0 ? Market.penaltyStateInterruption : 100)	* relInterruption +		// Cost for interrupting an atomic state
			Market.penaltyStateInterruption * relInterruption +
				
			// ------------ Penalties on number of misbehaviors
			Market.penaltyInflexibleOffers * unallocatedInflexibleBID +
			Market.penaltyInflexibleOffers * unallocatedInflexibleASK +
				
			Market.penaltyUnstarted * violatingDeadline + 							// Cost for not allocating at all a device (within a hard deadline)
			Market.penaltyViolatingMarket * relForbiddenMarket * violatingMarket +
			//Market.penaltyViolatingMarket * violatingMarket +						// Cost for making an offer which does not fulfill the market rules
				
			Market.penaltyViolatingSensitivity * relBIDLosses +
			Market.penaltyViolatingSensitivity * relASKLosses +
				
			Market.penaltyUnpoweredController * unpoweredController +				// Cost for interrupting the service when needed
				
			Market.penaltyUnnecessaryTrading * violatingNeeds;
				
				
		return reward + 
			(Market.penaltyGridUse * gridEnergySold) 
			- cost;
		
	}

	@Override
	public double getAverageOfferMarketDeviation() {
		return 0;
	}

	@Override
	public double getAverageDeviationFromNeeds() {
		return 0;
	}
}
