package hems.display.networkStatus;

import hems.Market;
import hems.devices.Agent;
import hems.devices.mainGrid.GridAgent;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.HashSet;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingUtilities;
import javax.swing.table.AbstractTableModel;

public class Wallet extends JPanel {
	
	private JTable table;
	
	public Wallet(){
		super(new GridLayout(1,0));
		
		Object[][] data = new Object[0][0];
		
		//table = new JTable(data, columnNames);
		AbstractTableModel model = new WalletTable(data);
	    table = new JTable(model);
	    
	    //table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
	    table.setPreferredSize(new Dimension(350,210));
        table.setFillsViewportHeight(true);
        table.setEnabled(false);
        
        JScrollPane scrollPane = new JScrollPane(table, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        add(scrollPane);
	}
		
	public void updateTable(final ArrayList<Agent> prosumers, final ArrayList<GridAgent> gridConnections){
		
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				int entries = prosumers.size() + gridConnections.size();
				
				Object[][] data = new Object[entries][entries > 0 ? 3 : 0];
				
				int i=0;
				for(Agent c : gridConnections){
					data[i][0] = c.getName();
					data[i][1] = c.getCreditLeft();
					data[i][2] = c.getExpenses();
					i++;
				}
				
				for(Agent a : prosumers){
					data[i][0] = a.getName();
					data[i][1] = a.getCreditLeft();
					data[i][2] = a.getExpenses();
					i++;
				}
				
				WalletTable wt = new WalletTable(data);
				table.setModel(wt);
				wt.fireTableDataChanged();
			}
	    });
		
	}
	
	class WalletTable extends AbstractTableModel {
		private String[] columnNames = {"Name", "Credit ["+Market.moneySymbol+"]", "Expenses ["+Market.moneySymbol+"]"};
		private Object[][] table = null;
		
		
		public WalletTable(Object[][] table){
			this.table = table;
		}
		
		public WalletTable(int r, int c) {
			table = new Object[r][c];
		}
		
		@Override
		public int getColumnCount() {
			return columnNames.length;
		}

		@Override
		public int getRowCount() {
			return table.length;
		}

		@Override
		public Object getValueAt(int r, int c) {
			return table[r][c];
		}
		
		@Override
		public String getColumnName(int col) {
            return columnNames[col];
        }
		
		public void setName(String name, int r){
			table[r][0] = name;
			//fireTableCellUpdated(r, 0);
		}
		
		public void setCredit(Double credit, int r){
			table[r][1] = credit;
			//fireTableCellUpdated(r, 1);
		}

		@Override
		public void setValueAt(Object obj, int r, int c) {
			if(obj instanceof String)
				table[r][c] = obj;
			else
				table[r][c] = obj;
			//fireTableCellUpdated(r, c);
		}
		
		@Override
		public Class getColumnClass(int col) {
            return getValueAt(0, col).getClass();
        }
	}
	
	 public static void main(String[] args) {
		 javax.swing.SwingUtilities.invokeLater(new Runnable() {
			 @Override
			public void run() {
				 JFrame frame = new JFrame("SimpleTableDemo");
				 frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

				 Wallet newContentPane = new Wallet();
				 newContentPane.setOpaque(true); //content panes must be opaque
				 frame.setContentPane(newContentPane);
				 frame.pack();
				 frame.setVisible(true);
			 } 
		 }); 
	 }
}