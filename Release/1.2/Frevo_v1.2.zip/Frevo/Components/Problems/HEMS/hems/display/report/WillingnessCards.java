package hems.display.report;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.Calendar;

import javax.swing.BoxLayout;
import javax.swing.JComboBox;
import javax.swing.JPanel;

public class WillingnessCards extends JPanel implements ItemListener{
	
	private static final long serialVersionUID = 6578280473606361490L;
	
	private JPanel cards;
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public WillingnessCards(String[] agentNames){
		
		JPanel comboBoxPane = new JPanel();
		
		// create the card panel
     	cards = new JPanel(new CardLayout());
     	String titles[] = {"Trading tendency", "Relative delay tolerance left", "Offer importance"};
     	
     	for(String agentName : agentNames){
     		// add a card for the device
        	DeviceCard c = new DeviceCard("Willingness", "Time", "Percentage", titles);
        	cards.add(c, agentName);
     	}
        
        JComboBox cb = new JComboBox(agentNames);
        cb.setEditable(false);
        cb.addItemListener(this);
        comboBoxPane.add(cb);
             
     	this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
     	this.add(comboBoxPane, BorderLayout.PAGE_START);
     	this.add(cards, BorderLayout.CENTER);
	}
	
	public void updateWillingnessToTrade(Calendar time, ArrayList<Double> values){
		double vals[] = new double[3];
		// loop on all cards to update their value
		for(int i = 0; i < values.size(); ){
			vals[0] = values.get(i);
			vals[1] = values.get(i+1);
			vals[2] = values.get(i+2);
			((DeviceCard) cards.getComponent(i/3)).addEntry(time, vals);
			i += 3;
		}
	}
	
	
	@Override
	public void itemStateChanged(ItemEvent evt) {
        CardLayout cl = (CardLayout)(cards.getLayout());
        cl.show(cards, (String) evt.getItem());
    }
	
	

}
