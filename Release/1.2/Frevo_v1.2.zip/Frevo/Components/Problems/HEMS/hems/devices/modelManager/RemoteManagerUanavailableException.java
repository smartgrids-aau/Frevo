package hems.devices.modelManager;

public class RemoteManagerUanavailableException extends Exception {
	public RemoteManagerUanavailableException(String message){
		super(message);
	}
	
	public RemoteManagerUanavailableException(){
		super();
	}
}
