package hems.devices;

import hems.Debugger;
import hems.Market;
import hems.devices.generators.GenerationModel;
import hems.devices.generators.weather.Weather;
import hems.devices.loads.EmptyOperationModel;
import hems.devices.loads.OperationModel;
import hems.devices.loads.StateBasedOperationModel;
import hems.devices.modelManager.RemoteManagerUanavailableException;
import hems.display.report.DiscomfortTable;
import hems.market.Offer;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Random;

import core.AbstractRepresentation;

public abstract class Agent implements Cloneable{
	
	protected SimpleDateFormat format = new SimpleDateFormat("yyyy MMM dd HH:mm:ss");
	
	// General purpose information
	protected String name;
	protected double credit;						// balance
	protected double expenses;						// total expenses from the trade
	
	protected OperationModel operationModel;		// model of consumer
	protected GenerationModel generationModel;		// model of producer
	
	protected AbstractRepresentation brain;			// neural controller
	
	protected boolean enabledToParticipate;			// switch physically the device OFF/ON (manage the idle state)
	protected int idlePowerDemand;					// Consumption of the agent in the idle state
	
	// stuff used to manage the offers over time
	protected Offer unacceptedOffer;				// last offer made, and not yet accepted
	
	// performance attributes
	protected int insensitivePriceOffers;			// the offer price is higher than allowed to (the agent is losing money, irrational behavior)
	protected int unpoweredController;				// the controller is not powered and can not be reached by other agents, while the human wanted to trade energy (as it is available)

	protected int invalidMarketOffers;				// the offer violates the market policy
	protected int timesOfferDoesNotReflectNeeds;	// the agent made an ASK/BID offer while it was not necessary according to its production/generation models
													// or made an idle offer which has a too low price or is negative
	
	protected ArrayList<Double> insensitiveBIDs;
	protected ArrayList<Double> insensitiveASKs;
	
	public Agent(String name, double credit, 
			OperationModel operationModel,
			GenerationModel generationModel
			){
		
		this.operationModel = operationModel;
		this.generationModel = generationModel;
				
		this.name = name;
		this.credit = credit;
		this.expenses = 0.0;
		this.idlePowerDemand = 0;
		
		this.insensitivePriceOffers = 0;
		this.unpoweredController = 0;
		this.invalidMarketOffers = 0;
		this.timesOfferDoesNotReflectNeeds = 0;
		
		this.insensitiveASKs = new ArrayList<Double>();
		this.insensitiveBIDs = new ArrayList<Double>();
	}
	
	public boolean isLoad(){
		return this.operationModel instanceof StateBasedOperationModel;
	}
	
	public boolean isGenerator(){
		return this.operationModel instanceof EmptyOperationModel;
	}
	
	/**
	 * Compares two agents using their names
	 */
	public boolean equals(Object obj) {
		
		// shortcircuit
		if(obj == this) return true;
		
		// check members otherwise
        if (obj instanceof Agent)
            return this.name.equals(((Agent) obj).getName()); 
        else
            return false;
    }
	
	/**
	 * The value returned by hashCode() is the object's hash code, which is the object's memory address in hexadecimal.
		By definition, if two objects are equal, their hash code must also be equal. 
		If you override the equals() method, you change the way two objects are equated and Object's implementation of hashCode() is no longer valid.
		Therefore, if you override the equals() method, you must also override the hashCode() method as well.
	 */
	
	@Override
    public int hashCode() {		
        int hash = 1;
        hash = 31 + name.hashCode();
        return hash;
    }
	
	/**
	 * Sets a decision maker for the agent
	 * @param brain
	 */
	public void injectBrain(AbstractRepresentation brain){
		this.brain = brain;
	}
	
	public AbstractRepresentation getBrain(){
		return brain;
	}
	
	public void setRandomGen(Random randomGen){
		this.operationModel.setRandomGen(randomGen);
	}
	
	public void setTableReference(DiscomfortTable table){
		this.operationModel.setTableReference(table);
	}
	
	public OperationModel getOperationModel(){
		return this.operationModel;
	}
	
	public GenerationModel getGenerationModel(){
		return this.generationModel;
	}
	// -----------------------------------------------------------------------------
	public void updateStatus(Calendar currentTime){
		// update the operation model for the device
		this.operationModel.updateStatus(currentTime);
	}
	// -----------------------------------------------------------------------------
	protected int getIdlePowerDemand(Calendar simulationTime, Calendar allocationTime, Weather weather){
		int idleDemand = 0;
		
		// check if a local energy source is available (free)
		int localProduction = (int) this.generationModel.getCurrentProduction(simulationTime, weather);		
					
		// use leftover to make an offer if necessary
		int leftover = this.idlePowerDemand - localProduction;
		
		// return idle demand only if the local production is not enough to cover it
		if(leftover > 0) idleDemand = leftover;
		
		return idleDemand;
	}

	
	/**
	 * Get demandsupply returns a double reflecting the availability or necessity of energy
	 * the method is not idempotent as a random generator is used to handle the starting probability
	 * therefore it should not be called more than once per time instant
	 * @param simulationTime
	 * @param allocationTime
	 * @param weather
	 * @return
	 * @throws RemoteManagerUanavailableException 
	 */
	protected double[] getDemandSupplyAvailability(Calendar simulationTime, Calendar allocationTime, Weather weather) throws RemoteManagerUanavailableException{
		double[] demandSupply = new double[3];
		demandSupply[0] = 0;	// necessary to trade demand (+1.0), supply (-1.0) or Nothing (0.0)? 
		demandSupply[1] = 0;	// amount to BUY
		demandSupply[2] = 0;	// amount to SELL
		
		// consider the stricter necessity of the idle power demand
		int leftoverProduction = (int) this.generationModel.getCurrentProduction(simulationTime, weather) - this.idlePowerDemand;
		int demand = this.operationModel.getFutureDemand(simulationTime, allocationTime);
		
		// do we have production left?
		if(leftoverProduction > 0){ 	// # leftover > 0 then leftover is indicating available production
			
			// do we have to use energy?
			if(demand > 0){
				// positive demand is decreased from local production
				int leftover = demand - leftoverProduction;
				
				// when leftover is positive we have demand to serve
				if(leftover > 0){
					demandSupply[0] = 1.0;
					demandSupply[1] = Math.abs(leftover);
					demandSupply[2] = 0;
				}
				// otherwise we have more production than demand
				else if(leftover < 0){
					demandSupply[0] = -1.0;
					demandSupply[1] = 0;
					demandSupply[2] = Math.abs(leftover);
				}
				// else we are just fine and need nothing do do
				else{
					demandSupply[0] = 0.0;
					demandSupply[1] = 0;
					demandSupply[2] = 0;
				}
				
				//demandSupply[1] = Math.abs(leftover);
			}else{
				// SELL as demand <= 0 and production > 0
				demandSupply[0] = -1.0;
				demandSupply[1] = 0;
				demandSupply[2] = leftoverProduction;
			}
			
		}else{	//	# leftover < 0 then leftover is indicating the idle power or the unavailability of local generators
			
			// do we have to buy energy?
			if(demand > 0){
				// We need to buy energy
				demandSupply[0] = 1.0;
				demandSupply[1] = demand;
				demandSupply[2] = 0;
			}else{
				// NOOP as demand <= 0 and production <= 0
				demandSupply[0] = 0.0;
				demandSupply[1] = 0;
				demandSupply[2] = 0;
			}
		}
			
		//System.out.println(this.name+": leftoverProduction="+leftoverProduction+", demand="+demand+", demandSupply="+demandSupply[0]+", amount="+demandSupply[1]);
		// Correct!!!
		
		// TODO: in case of a battery having both we might compute a continuous value of willingness/production to reflect the proportion of available charge on this values
		return demandSupply;
	}
	
	/**
	 * Called once at the beginning of every trading day (each time instant) to determine the willingness of an agent to trade energy
	 * ATTENTION: this function is not idempotent and should not be called over various iterations of the same day!
	 * @param simulationTime
	 * @param allocationTime
	 * @param weather
	 * @return
	 * @throws RemoteManagerUanavailableException 
	 */
	public TraderWillingness getWillingnessToTrade(Calendar simulationTime, Calendar allocationTime, Weather weather) throws RemoteManagerUanavailableException{
		
		boolean newOfferNeeded = true;
		
		// *** inputs for the decision maker ***		
		double[] ds = getDemandSupplyAvailability(simulationTime, allocationTime, weather);
		double demandSupply = ds[0]; 
		int amountToBuy = (int) ds[1];
		int amountToSell = (int) ds[2];
				
		// tolerance to a delayed allocation of the offer to be formulated (initially neutral)
		double relativeDelayToleranceLeft = 1.0;	// % left (for the controller)
		int delayToleranceLeft = 0;					// seconds left (only for the GUI)
		/*
		 * For a NEW start
		 * 	Inflexible service:	dt = 0 secs, rdt = 0%
		 * 	Flexible service:
		 * 			# NOT willing to trade	-> dt = 0, rdt = 100%
		 * 			# willing to trade
		 * 				> Buy	->	NEW			->	dt = model.dt, rdt = 100%
		 * 						->	Existing	->	dt_t -1, rdt = dt_t / dt
		 * 				> Sell	->	dt = 0, rdt = 100%
		 * Intra-state: dt = 0, rdt = 0%
		 */
		
		double offerImportance = 0.0;	// offer is of a flexible service
		
		
		// ******** Check operation and generation models for necessity to trade ***************
		if(demandSupply > 0 && 												// we still want to buy energy
				unacceptedOffer != null && unacceptedOffer.isBIDtype){		// there is an offer made previously, not yet accepted, and it is a BID
			
			// *** manage a hard deadline mechanism to push the devices to start within a finite time window ***
			if(this.operationModel.isWithinHardDeadline(simulationTime)){
				
				// *** if still in time try to improve the BID offer ***
				newOfferNeeded = false;										// no need for a new offer
				
				demandSupply = 1.0;											// conclude operation once started (Rationality)
				amountToBuy = unacceptedOffer.amount;
				amountToSell = 0;
				
				// update existing offer to the current time
				unacceptedOffer.decreaseTolerance();
						
				if(this.operationModel.getDelaySensitivity() > 0){
					// e.g. 3 waited seconds out of 5 tolerated means: 5 - 3 = 2 left, i.e. 2/5 = 0.4 = 40% tolerance left
					relativeDelayToleranceLeft = unacceptedOffer.delayTolerance / (double) this.operationModel.getDelaySensitivity();
					// when we have waited 5 seconds out of 5 tolerated we have (5-5), i.e. 0 / 5 = 0% tolerance left
				}else{	// avoid divisions by 0
					// e.g. -2 seconds of tolerance means we already waited 2 seconds out of 0,
					// i.e., -200% tolerance is left to use
					relativeDelayToleranceLeft = unacceptedOffer.delayTolerance;
				}
				delayToleranceLeft = unacceptedOffer.delayTolerance;
				
				if(!this.operationModel.isAFlexibleService()){	offerImportance = 1.0;
				}else{
					if(this.operationModel instanceof StateBasedOperationModel){
						if( ((StateBasedOperationModel) this.operationModel).getCurrentState() > 0) offerImportance = 0.5;
						else offerImportance = 0.0;
					}else{
						offerImportance = 0.0;	// this includes also batteries and generators brokering energy for loads
					}
				}
				
			}else{
				//System.out.println(this.name+": violated deadline at "+this.format.format(simulationTime.getTime()));
				
				// make the offer expire
				unacceptedOffer = null;	
				// new offer needed based on current willingness
			}
		}

		if(newOfferNeeded){					
			// decide whether we need to start and sell (NEW)
			if(demandSupply > 0.0){	// BUY				
				delayToleranceLeft = this.operationModel.getDelaySensitivity();
				relativeDelayToleranceLeft = delayToleranceLeft > 0 ? 
																	1.0		// all tolerance to be used (100%)
																	: 0.0; 	// the device has no tolerance to delay at all (0%)
				/* State importance:
				 * 
				 * flexible offer: flexible service (distinguishes first from intermediate states)
				 * 			# 1st state			i = 0.0	NOT CRITICAL
				 * 			# 2nd..nth state	i = 0.5 MEDIUM CRITICAL
				 * 
				 * inflexible offer: inflexible service and idle power, i = 1.0 (any state is CRITICAL)
				 */
				if(!this.operationModel.isAFlexibleService()){
					offerImportance = 1.0;
				}else{
					if(this.operationModel instanceof StateBasedOperationModel){
						if( ((StateBasedOperationModel) this.operationModel).getCurrentState() > 0) offerImportance = 0.5;
						else offerImportance = 0.0;
					}else{
						// this includes also batteries and generators brokering energy for loads
						// TODO: how do we deal with this??????
						offerImportance = 0.0; // let's say it is not critical for now
					}
				}
			}else if(demandSupply < 0.0){ //SELL
				delayToleranceLeft = 0;
				relativeDelayToleranceLeft = this.generationModel.isAFlexibleService() ? 
																					1.0 	// flexible service (100% left)
																					: 0.0;	// inflexible service (0% left)
				offerImportance = this.generationModel.isAFlexibleService() ? 
																			0.0		// flexible -> not critical 
																			: 1.0;	// inflexible -> critical
			}else{	// NOOP
				delayToleranceLeft = 0;
				relativeDelayToleranceLeft = 1.0;	// 100% available
				offerImportance = 0.0;				// not critical to trade now
			}
		}
		
		return new TraderWillingness(demandSupply, offerImportance, 
									getIdlePowerDemand(simulationTime, allocationTime, weather),
									amountToBuy, delayToleranceLeft, relativeDelayToleranceLeft,
										demandSupply > 0.0 ? this.operationModel.getPriceSensitivity(simulationTime) : 0.0, 
									amountToSell,
										demandSupply < 0.0 ? this.generationModel.getReservationPrice(simulationTime) : Market.limitPrice
									);
	}
	
	public abstract double computeFitness(double reward, 
			double gridEnergySold, double gridEnergyCosts, double localEnergyCosts,
			double relDevStart, double relStateStart, double relInterruption, 
			double unallocatedInflexibleBID, double unallocatedInflexibleASK,
			
			double violatingDeadline,
			double violatingMarket, double relForbiddenMarket,
			double violatingSensitivity, double relBIDLosses, double relASKLosses,
			double unpoweredController,
			double violatingNeeds, double relDoesNotReflectNeeds
			);
	
	// ------------------------------------ Methods to get attributes of the agent
	public double getCreditLeft(){
		return credit;
	}
	
	public double getExpenses(){
		return expenses;
	}
	
	public String getName(){
		return name;
	}
	
	// Methods to set the consumption of the device during inactivity
	public void setIdleConsumption(int idleConsumption){
		Debugger.println(this.name+": idle="+idleConsumption);
		this.idlePowerDemand = idleConsumption;
	}
	
	/**
	 * Return the idle 
	 * @return
	 */
	public int getIdlePowerDemand(){
		return idlePowerDemand;
	}
	
	/**
	 * Returns true if the agent is running its controller and can participate to the current auction
	 * @return
	 */
	public boolean isRunningItsController(){
		return this.enabledToParticipate;
	}
	
	/**
	 * Called at the end of the auction to switch ON/OFF the smart device
	 * @param enable
	 */
	public void allowParticipationToNextDay(boolean enable){
		this.enabledToParticipate = enable;
	}
	
	public void allowToRun(int allocatedAmount, int requested, Calendar simulationTime){
		//if(allocatedAmount > 0 && allocatedAmount < requested) System.out.println("\t"+this.format.format(simulationTime.getTime())+": "+this.name+" requested "+requested+" W and got "+allocatedAmount+" W");
		
		// if we got allocated power then the offer was accepted
		if(allocatedAmount > 0){
			this.unacceptedOffer = null;
		}else{
			// penalize inflexible services which did not manage to allocate energy at the current time
			if(requested > 0 && !this.operationModel.isAFlexibleService()){
				this.operationModel.addTimeInflexibleUnallocated();
				//System.out.println(this.name+" did not allocate his inflexible BID power ("+allocatedAmount+", "+requested+") at "+this.format.format(simulationTime.getTime()));
			}
		}
		// enable the operation model
		this.operationModel.allowToRun(allocatedAmount, simulationTime);
	}
	
	public void allowToSupply(int allocatedAmount, int sellable, Calendar simulationTime){
		if(allocatedAmount < sellable && !this.generationModel.isAFlexibleService()){
			this.generationModel.addTimeInflexibleUnallocated();
			//System.out.println(this.name+" did not allocate his inflexible ASK power ("+allocatedAmount+", "+sellable+") at "+this.format.format(simulationTime.getTime()));
		}
	}
	
	// ------------------------------------ Methods to charge the agent
	public void charge(double money){
		credit -= money;
		expenses += money;
	}
	
	public void getPaid(double money){
		credit += money;
	}
	
	// ------------------------------------ Methods to punish the agent for making an offer exceeding the sensitivity price	
	public void trackPriceOffer(double offerPrice, double priceSensitivity, boolean bid){
		double distance = 0;
		if(bid){
			// BID offers should always be lower than price sensitivity, 
			distance = (offerPrice - priceSensitivity); // / priceSensitivity;
			this.insensitiveBIDs.add( distance );
		}else{
			// ASK offers should always be higher than the reservation price
			distance = offerPrice - priceSensitivity; //(priceSensitivity - offerPrice); // / priceSensitivity;
			
			this.insensitiveASKs.add( distance );
		}
	}
	
	public double getRelativeInsensitiveBIDs(){
		double res = 0.0;
		
		//System.out.println("IB("+this.name+")= "+this.insensitiveBIDs.toString());
		
		for(int i = 0; i < this.insensitiveBIDs.size(); i++){
			res += this.insensitiveBIDs.get(i);
		}
		
		if(this.insensitiveBIDs.size() > 0) res /= (double) this.insensitiveBIDs.size();
		
		//System.out.println("IB("+this.name+")= "+res);
		return res;
	}
	
	public double getRelativeInsensitiveASKs(){
		double res = 0;
		
		//System.out.println("IA("+this.name+")= "+this.insensitiveASKs.toString());
		
		for(int i = 0; i < this.insensitiveASKs.size(); i++){
			res += this.insensitiveASKs.get(i);
		}
		
		if(this.insensitiveASKs.size() > 0) res /= (double) this.insensitiveASKs.size();
		
		//System.out.println("IA("+this.name+")= "+res);
		return res;
	}

	public boolean isFlexibleLoad(){
		return this.operationModel.isAFlexibleService();
	}
	
	public boolean isFlexibleGenerator(){
		return this.generationModel.isAFlexibleService();
	}
	// ---------------
	public void addInsensitivePriceOffer(){
		this.insensitivePriceOffers++;
	}
	
	public int getInsensitivePriceOffers(){
		return this.insensitivePriceOffers;
	}
	
	// ----------------------------------- Methods to punish the agent for not getting idle power supply when necessary
	public int getTimesControllerWasNotPowered(){
		return this.unpoweredController;
	}
	
	public void addTimeControllerWasNotPowered(){
		this.unpoweredController++;
	}

	// ---------------- Methods which depend on the specific auction type
	public void addInvalidMarketOffer(){
		this.invalidMarketOffers++;
	}
		
	public int getInvalidMarketOffers(){
		return this.invalidMarketOffers;
	}
	
	public abstract double getAverageOfferMarketDeviation();
	
	public void punishOfferNotReflectingNeeds(){
		this.timesOfferDoesNotReflectNeeds++;
	}
	
	public int getTimesOfferDoesNotReflectNeeds(){
		return this.timesOfferDoesNotReflectNeeds;
	}
	public abstract double getAverageDeviationFromNeeds();
	// ----------------------
	/**
	 * Returns the power demand of the device, given the presence of a smart controller
	 * which also uses power, and the availability of local energy sources
	 * @param currentTime
	 * @param weather
	 * @return
	 */
	/*
	public int getExposedPowerDemand(Calendar currentTime, Weather weather) {
		int exposedDemand = 0;
		
		// filter out the grid connections as the energy fed into the grid is not considered as "consumed" local demand
		if(!(this instanceof GridAgent)){
			
			int productionLeftover = (int) this.generationModel.getCurrentProduction(currentTime, weather);
			// compute the power remaining from the use for the idle state
			if(this.enabledToParticipate && this.idlePowerDemand > 0) productionLeftover -= this.idlePowerDemand;
					
			// add up the ACTUAL consumption exposed by the device, by checking if it required more than the local production
			if(productionLeftover < 0){ // idle > production
				exposedDemand += Math.abs(productionLeftover);
				
				// add also the demand for the operation of the device
				exposedDemand += this.operationModel.getPowerDemand();
			}else{ // else when (production > idle) then satisfy local demand
				// try to satisfy the demand to operate the device first
				int operationalDemand = this.operationModel.getPowerDemand() - productionLeftover;
				
				// if the production leftover was not enough to satisfy the demand we need to expose the rest
				if(operationalDemand > 0){
					exposedDemand += operationalDemand;
				}
				
			}
		}
		
		return exposedDemand;
	}*/
}