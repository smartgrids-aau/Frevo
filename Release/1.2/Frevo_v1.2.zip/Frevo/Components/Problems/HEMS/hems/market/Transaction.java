package hems.market;

import hems.devices.Agent;
import hems.market.Offer.OfferType;


public class Transaction implements Cloneable {
	
	public int amount;			// power amount
	public double price;		// transaction price
	
	public Agent seller;
	public Agent buyer;
	
	public OfferType type;
	
	public Transaction(Agent seller, Agent buyer, int amount, OfferType type){
		this.seller = seller;
		this.buyer = buyer;
		this.amount = amount;
		this.type = type;
	}
	
	/**
	 * Sets the price for the transaction
	 * @param price
	 */
	public void setPrice(double price){
		this.price = price;
	}
	
	/**
	 * Clones the transaction
	 */
	@Override
	public Transaction clone(){
		Transaction t = new Transaction(seller, buyer, amount, type);
		t.setPrice(price);
		return t;
	}

}
