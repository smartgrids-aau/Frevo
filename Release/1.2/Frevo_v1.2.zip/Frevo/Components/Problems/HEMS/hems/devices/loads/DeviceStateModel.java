package hems.devices.loads;

import java.util.ArrayList;

public class DeviceStateModel {
	
	private ArrayList<State> states;
	
	public DeviceStateModel(){
		this.states = new ArrayList<State>();
	}
	
	public void addState(int peakPower, int duration){
		this.states.add(new State(duration, peakPower));
	}
	
	public void addState(int peakPower, int duration, int delayTolerance){
		this.states.add(new State(duration, peakPower, delayTolerance));
	}
	
	public ArrayList<State> getStates(){
		return states;
	}
	
	public State getInitialState(){
		return states.get(0);
	}
	
	public int getDuration(int index){
		return states.get(index).duration;
	}
	
	public int getPeakPower(int index){
		return states.get(index).peakPower;
	}
	
	public double getMaxCurtailabilityFactor(int index){
		return states.get(index).maxCurtailabilityFactor;
	}
	
	public int getStateNumber(){
		return states.size();
	}
	
	public boolean hasFurtherStates(int state){
		return states.size()>0 && state < states.size()-1;
	}
	
	public int next(int state){
		return (state + 1) % states.size();
	}
	
	public int getDelayTolerance(int state){
		return states.get(state).delayTolerance;
	}
	
	public int getInterruptionTolerance(int state){
		return states.get(state).interruptionTolerance;
	}
	
	public double getRunningCost(double energyCost){
		double cost = 0;
		for(State s : states){
			cost += s.peakPower * s.duration;	// P*t [W*s]
		}
		cost /= 1000*3600;						// [W*s] / 1000*3600 = [KW]
		cost *= energyCost;						// $ [euros] = P * t * (euros * P * t)
		return cost;
	}

	
	public class State{
		public int duration; // seconds
		public int peakPower;
		public int delayTolerance;
		public int interruptionTolerance;
		
		public double maxCurtailabilityFactor;	// defines the amount of power a device state can be curtailed
		
		public State(int duration, int peakPower){
			this.duration = duration;
			this.peakPower = peakPower;
			
			this.delayTolerance = 0;
			this.interruptionTolerance = 0;
			this.maxCurtailabilityFactor = 0;
		}
		
		public State(int duration, int peakPower, int delayTolerance){
			this.duration = duration;
			this.peakPower = peakPower;
			this.delayTolerance = delayTolerance;
			
			this.interruptionTolerance = 0;
			this.maxCurtailabilityFactor = 0;
		}
		
		public State(int duration, int peakPower, int delayTolerance, int interruptionTolerance){
			this.duration = duration;
			this.peakPower = peakPower;
			this.delayTolerance = delayTolerance;
			this.interruptionTolerance = interruptionTolerance;
			
			this.maxCurtailabilityFactor = 0;
		}
		
		
		public void setMaxCurtailabilityFactor(double factor){
			this.maxCurtailabilityFactor = factor;
		}
		
	}
}
