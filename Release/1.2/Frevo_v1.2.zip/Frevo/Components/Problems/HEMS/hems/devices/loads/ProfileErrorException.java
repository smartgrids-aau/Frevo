package hems.devices.loads;

public class ProfileErrorException extends Exception {

	public ProfileErrorException(String message) {
		super(message);
	}

	public ProfileErrorException() {
		super();
	}

}
