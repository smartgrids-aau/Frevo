package hems.display.report;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.SwingUtilities;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.filechooser.FileNameExtensionFilter;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.DateTickMarkPosition;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.time.Second;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.RectangleEdge;
import org.jfree.ui.RectangleInsets;

import hems.Market;
import hems.devices.Agent;
import hems.devices.TraderWillingness;
import hems.display.HEMSDisplay;
import hems.display.TimeInstant;
import hems.market.MarketEval;

public class SimulationStatusPanel extends JPanel {

	public static final int MINUTE_LENGHT = 0;
	public static final int HOUR_LENGHT = 1;
	public static final int DAY_LENGHT = 2;
	public static final int WEEK_LENGHT = 3;
	public static final int MONTH_LENGHT = 4;
	public static final int YEAR_LENGHT = 5;
	public static final int UNBOUNDED_LENGHT = 6;
	
	private static final long serialVersionUID = -1496486587053778197L;

	private int windowSize;
	private String prices[] = {"AVG Grid Price", "AVG feed-in price", "Local Price"};
	private String powerAmounts[] = {"Traded Demand", "Traded Demand From Local Production", "Traded Fed Into Grid", "Actual Grid Availability", "Actual Local Production", "Actual availability"};
	private String localPowerConsumption[] = {"Self-consumption"};
	private String cloudyness[] = {"Sun factor"};
	private String marketQuality[] = {"Market efficiency"};
	
	/*
	private String delays[] = {"Delay to start", "Delay to complete"};
	private String willingnessToTrade[] = {"TradingTendency", "RelativeDelayToleranceLeft", "OfferImportance"};
	private String priceSensitivity[] = {"PriceSensitivity", "ReservationPrice"};
	*/
	public enum TimeserieID {PRICE, POWER, SELFCONSUMPTION, WEATHER, MARKET, WILLINGNESS, SENSITIVITY, DISCOMFORT;
								static public final Integer lenght = 1 + DISCOMFORT.ordinal();
	};
	
	private JTabbedPane tabbedPane;
	private DiscomfortTab discomfortTab;
	
	private JButton btnSaveChart;
	private JButton btnSaveSeries;
	private JButton btnSaveLatex;
	
	private String[] agentNames;
	
	protected SimpleDateFormat format = new SimpleDateFormat("yyyy MM dd HH:mm:ss");
	
	private LoggerTimeserie logger;
	
	public SimulationStatusPanel(ArrayList<Agent> prosumers, LoggerTimeserie logger){
		
		this.agentNames = new String[prosumers.size()];	 for(int i=0; i<prosumers.size(); i++) agentNames[i] = prosumers.get(i).getName();
		
		// initialize timeseries logger
		this.logger = logger;
		
		this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		
		tabbedPane = new JTabbedPane();
		tabbedPane.setPreferredSize(new Dimension(1049, 290));
		
		tabbedPane.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
		
        tabbedPane.addTab("Price", null, makeChartPanel("Price", "Time", "Price [Euro]", prices), "Displays price over simulation time");
        tabbedPane.addTab("Power", null, makeChartPanel("Power", "Time", "Power [W]", powerAmounts), "Displays the power over simulation time");
        tabbedPane.addTab("Self-consumption", null, makeChartPanel("Self-consumption", "Time", "Percentage [%]", localPowerConsumption), "Displays the percentage of consumption of local generation over simulation time");
        tabbedPane.addTab("Weather", null, makeChartPanel("Weather", "Time", "Sun factor", cloudyness), "Displays the Sun factor over simulation time");
        tabbedPane.addTab("Market", null, makeSteppedPanel("Market efficiency", "Time", "factor", marketQuality), "Displays the market efficiency over simulation time");        
        
        tabbedPane.addTab("Willingness", 
        					null, 
        					new WillingnessCards(agentNames),
        					"Displays the willingness to trade over simulation time");
        tabbedPane.addTab("Price Sensitivity",
        					null,
        					new PriceSensitivityCards(agentNames),
        					"Displays the price sensitivity to buy and sell over simulation time");
        
        discomfortTab = new DiscomfortTab(prosumers);
        tabbedPane.addTab("Operations",
        				null,
        				discomfortTab,
        				"Displays the user discomfort over the simulation time");
        
        tabbedPane.setSelectedIndex(0);
        this.add(tabbedPane);
        
        // ADD timeseries to the logger
        logger.addTimeserie(TimeserieID.PRICE.ordinal(), prices);							// TAB 0
        logger.addTimeserie(TimeserieID.POWER.ordinal(), powerAmounts);						// TAB 1
        logger.addTimeserie(TimeserieID.SELFCONSUMPTION.ordinal(), localPowerConsumption);	// TAB 2
        logger.addTimeserie(TimeserieID.WEATHER.ordinal(), cloudyness);						// TAB 3
        logger.addTimeserie(TimeserieID.MARKET.ordinal(), marketQuality);					// TAB 4
        
        String willingnessTitles[] = new String[ agentNames.length * 2 ];
        String sensitivityTitles[] = new String[ agentNames.length * 2 ];
        for(int i = 0; i < willingnessTitles.length; ){
        	willingnessTitles[i] = agentNames[i/2]+"_willingness";
        	willingnessTitles[i+1] = agentNames[i/2]+"_delay_tolerance";
        	
        	sensitivityTitles[i] = agentNames[i/2]+"_price_sensitivity";
        	sensitivityTitles[i+1] = agentNames[i/2]+"_reservation_price";
        	
        	i += 2;
        }
        logger.addTimeserie(TimeserieID.WILLINGNESS.ordinal(), willingnessTitles);			// TAB 5
        logger.addTimeserie(TimeserieID.SENSITIVITY.ordinal(), sensitivityTitles);			// TAB 6
        
        // --------------------------------------------------------------
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());
        this.add(buttonPanel);
        
        // **** Save as picture ****
        btnSaveChart = new JButton("Save as Picture");
		btnSaveChart.setPreferredSize(new Dimension(150, 25));
		
		buttonPanel.add(btnSaveChart);
		btnSaveChart.setAlignmentX(Component.CENTER_ALIGNMENT);		
		btnSaveChart.addActionListener(new ActionListener () {
		    @Override
			public void actionPerformed(ActionEvent e) {
					try{
						saveChart();
					}catch(Exception ex){
						JOptionPane.showMessageDialog(tabbedPane, ex.getMessage(), "Warning", JOptionPane.WARNING_MESSAGE);
					}
		    }
		});
		
		// **** Save as Latex ****
		btnSaveLatex = new JButton("Save as LaTeX");
		btnSaveLatex.setPreferredSize(new Dimension(150, 25));
		btnSaveLatex.setAlignmentX(Component.CENTER_ALIGNMENT);
		buttonPanel.add(btnSaveLatex);
		btnSaveLatex.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				try{
					saveAsLatex();
				}catch(Exception ex){
					JOptionPane.showMessageDialog(tabbedPane, ex.getMessage(), "Warning", JOptionPane.WARNING_MESSAGE);
				}
			}
			
		});
		
		// **** Save as CSV ****
		btnSaveSeries = new JButton("Save as CSV");
		btnSaveSeries.setPreferredSize(new Dimension(150, 25));
		btnSaveSeries.setAlignmentX(Component.CENTER_ALIGNMENT);
		
		buttonPanel.add(btnSaveSeries);
		btnSaveSeries.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e){
				try{
					saveSeries();
				}catch(Exception ex){
					JOptionPane.showMessageDialog(tabbedPane, ex.getMessage(), "Warning", JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		
	}
	
	
	public void saveChart() throws IOException{
	
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
		fileChooser.setAcceptAllFileFilterUsed(false);
		fileChooser.setFileFilter(new FileNameExtensionFilter("PNG Files (*.png)", "png"));
		fileChooser.setSelectedFile(new File(System.getProperty("user.home")+"/imgplot_"+tabbedPane.getTitleAt(tabbedPane.getSelectedIndex())+".png"));
		
		int returnVal = fileChooser.showSaveDialog(this);
		if(returnVal == JFileChooser.APPROVE_OPTION) {
			// Get content of selected tab
			JPanel selected = (JPanel) tabbedPane.getComponentAt(tabbedPane.getSelectedIndex());
			
			String filepath = fileChooser.getSelectedFile().getPath();
			File file = new File(filepath);
			
			BufferedImage image = new BufferedImage(selected.getWidth(), selected.getHeight(), BufferedImage.TYPE_INT_ARGB);
			Graphics g = image.getGraphics();
			selected.paint(g);
			try {
				ImageIO.write(image, "png", file);
			}catch (IOException ex) {
				JOptionPane.showMessageDialog(tabbedPane, ex.getMessage(), "Inane warning", JOptionPane.WARNING_MESSAGE);
			}
		}
	}	
	
	public void saveAsLatex() throws IOException{
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
		fileChooser.setAcceptAllFileFilterUsed(false);
		fileChooser.setFileFilter(new FileNameExtensionFilter("Tex Files (*.tex)", "tex"));
		fileChooser.setSelectedFile(new File(System.getProperty("user.home")+"/texplot_"+tabbedPane.getTitleAt(tabbedPane.getSelectedIndex()).replaceAll("\\s","")+".tex"));
		
		int returnVal = fileChooser.showSaveDialog(this);
		if(returnVal == JFileChooser.APPROVE_OPTION) {
			String filepath = fileChooser.getSelectedFile().getPath();
			FileWriter writer = new FileWriter(filepath);
			
			// Get content of selected tab
			JPanel selected = (JPanel) tabbedPane.getComponentAt(tabbedPane.getSelectedIndex());
		
			if(selected instanceof ChartPanel || selected instanceof WillingnessCards){
				
				writer.append("\\begin{tikzpicture}\n");
				
				String[] colNames = logger.getColNames(tabbedPane.getSelectedIndex());
				ArrayList<hems.display.report.LoggerTimeserie.TimeInstant<Double>> ts = logger.getSeries(tabbedPane.getSelectedIndex());
				
				double[][] minMaxValues = logger.getMinMaxValue(tabbedPane.getSelectedIndex());
				double ymin = 0.0; double ymax = 0.0;
				for(double[] minMax : minMaxValues){
					if(minMax[0] < ymin) ymin = minMax[0]; // look among min values for the smallest
					if(minMax[1] > ymax) ymax = minMax[1]; // look among max values for the biggest
				}
				
				long startTime = 0;
				long endTime = 0;
				double timeInterval = 0;
				String xtick = "";
				String xticklabels = "";
				if(ts.size() > 0){
					startTime = ts.get(0).time.getTimeInMillis();
					endTime = ts.get(ts.size() - 1).time.getTimeInMillis();
					
					timeInterval = endTime - startTime;
					// divide the time interval by 10
					timeInterval /= 10;
					
					double indexInterval = ts.size() / 10;
					
					for(int i = 0; i < 11; i++){
						
						xtick += i * indexInterval; if(i <  10) xtick += ",";
						
						long offset = (long) (startTime + i * timeInterval);
						//xtick += offset; if(i <  10) xtick += ",";
						xticklabels += "{"+this.format.format(offset)+"}"; if(i < 10) xticklabels += ",";
					}
				}
				
				String scale =	"\\begin{axis}[%"+ "\n" +
								"width=\\figurewidth,"+ "\n" +
								"height=\\figureheight,"+ "\n" +
								"scale only axis,"+ "\n" +
								//"xmin="+startTime+","+ "\n" +
								"xmin="+(0 - (ts.size()*0.1))+","+ "\n" +
								//"xmax="+endTime+","+ "\n" +
								"xmax="+(ts.size()+(ts.size()*0.1))+","+ "\n" +
								"xtick={"+xtick+"},"+ "\n" +
								"xticklabels={"+xticklabels+"},"+ "\n" +
								"x tick label style={font=\\footnotesize,align=right,rotate=90}," +"\n" +
					            "xlabel={Time}," +"\n" +
								"ymin="+ (ymin-(ymax*0.1)) +",\n" +
								"ymax="+(ymax+(ymax*0.1))+",\n" +
								"ylabel={"+tabbedPane.getTitleAt(tabbedPane.getSelectedIndex())+"}," + "\n" +
								"legend style={draw=black,fill=white,legend cell align=left,at={(1.5\\figurewidth,1.0)},anchor=north}" +"\n" + // legend pos=north east
								"]" + "\n";
				
				writer.append(scale);
				
				String[] colors = {"red", "blue", "cyan", "black", "magenta", "orange", "yellow", "green", "gray", "darkgray", "lightgray", "brown", "lime", "olive", "pink", "purple", "teal"};
				String[] lineTraits = {"solid", "dashed", "dotted", "dashdotted", "densely dotted", "loosely dotted", "double"};
				String[] marks = {"*", "+", "triangle*", "square*", "otimes*", "diamond*", "star"};
				
				// print timeseries
				for(int s = 0; s < colNames.length; s++){
					writer.append("\\addplot [color="+colors[s%colors.length]+","+lineTraits[s%lineTraits.length]+",line width=0.8pt,mark="+marks[s%marks.length]+",mark options={solid,fill=white}]\n"+ "table[row sep=crcr]{" );
					for(int i = 0; i < ts.size(); i++){
					//for(hems.display.report.LoggerTimeserie.TimeInstant<Double> t : ts){
						//writer.append(""+  t.time.getTimeInMillis() +"\t" + t.getValues().get(s) +"\\\\\n");
						writer.append(""+  i +"\t" + ts.get(i).getValues().get(s) +"\\\\\n");
					}
					writer.append( "};" +"\n" + "\\addlegendentry{"+colNames[s].replaceAll("\\P{Alnum}", "")+"};\n\n");
				}
				
				writer.append("\\end{axis}\n");
				writer.append("\\end{tikzpicture}%");
				
			}else if(selected instanceof DiscomfortTab){ 
				
				DiscomfortTable dt = (DiscomfortTable) ((DiscomfortTab) selected).getVisibleCard();
							
				String[] columnNames = dt.getColumnNames();
				String[][] dataset = dt.getDataTable(); // [r][c]

				String l = ""; 
				for(int c = 0; c < columnNames.length; c++){
					l += "l";
					if(c < columnNames.length - 1) l += " | ";
				}
				
				writer.append("\\begin{table}[h]\n");
				writer.append("\\centering\n\\begin{tabular}{| "+l+" |}\n\\hline\n");
				
				String row = "";
				for(int s = 0; s < columnNames.length; s++){
					row += columnNames[s];
					if(s < columnNames.length - 1){
						row += " &\t";
					}else{
						row += "\\\\\n";
					}
				}
				writer.append(row);
				writer.append("\\hline\n");
				
				for(int r = 0; r < dataset.length; r++){
					row = "";
					for(int c = 0; c < dataset[r].length; c++){
						row += dataset[r][c];
						if(c < dataset[r].length - 1){
							row += " &\t";
						}else{
							row += "\\\\\n";
						}
					}
					writer.append(row);
				}
				
				// get the name and remove all weird characters users might have added
				String deviceName = ((DiscomfortTab) selected).getVisibleCard().getName().replaceAll("\\P{Alnum}", "");
				writer.append("\\hline\n\\end{tabular}\n");
				writer.append("\\caption[Operations of device "+deviceName+"]{Operations of device "+deviceName+"}\n"+"\\label{table:discomfort:"+deviceName+"}\\end{table}");
			}
			
			writer.flush();
			writer.close();
		}
	}
	
	public void saveSeries() throws IOException{
		
		JFileChooser chooser = new JFileChooser();
		chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
		chooser.setAcceptAllFileFilterUsed(false);
		chooser.setFileFilter(new FileNameExtensionFilter("CSV File (.csv)", ".csv"));
		chooser.setSelectedFile(new File(System.getProperty("user.home")+"/timeserie_"+tabbedPane.getTitleAt(tabbedPane.getSelectedIndex())+".csv"));
		
		int returnVal = chooser.showSaveDialog(this);
		if(returnVal == JFileChooser.APPROVE_OPTION){
			String filepath = chooser.getSelectedFile().getPath();
			FileWriter writer = new FileWriter(filepath);
			
			// get selected tab
			JPanel selected = (JPanel) tabbedPane.getComponentAt(tabbedPane.getSelectedIndex());
			
			if(selected instanceof ChartPanel){
				
				String[] colNames = logger.getColNames(tabbedPane.getSelectedIndex());
				ArrayList<hems.display.report.LoggerTimeserie.TimeInstant<Double>> ts = logger.getSeries(tabbedPane.getSelectedIndex());
				
				writer.append("timestamp,");
				for(int n = 0; n < colNames.length; n++){
					writer.append(colNames[n]);
					if(n < colNames.length -1) writer.append(",");
				}writer.append("\n");
				
				for(hems.display.report.LoggerTimeserie.TimeInstant<Double> t : ts){
					// as the unix time is in secs we need to divide by 1000 to get it from the ms value
					writer.append(""+ (t.time.getTimeInMillis()/1000) ); writer.append(",");
					
					int colnum = t.getValues().size();
					
					for(int c = 0; c < colnum; c++){
						writer.append(""+t.getValues().get(c));
						if(c < colnum -1) writer.append(",");
					}
					writer.append('\n');
				}
				
			}else if(selected instanceof DiscomfortTab){ // get data from jtable
					
				DiscomfortTable dt = (DiscomfortTable) ((DiscomfortTab) selected).getVisibleCard();
					
				String[] columnNames = dt.getColumnNames();
				String[][] dataset = dt.getDataTable(); // [r][c]

				String row = "";
				for(int s = 0; s < columnNames.length; s++){
					row += columnNames[s];
					if(s < columnNames.length - 1){
						row += ",";
					}else{
						row += "\n";
					}
				}
				writer.append(row);
				
				for(int r = 0; r < dataset.length; r++){
					row = "";
					for(int c = 0; c < dataset[r].length; c++){
						row += dataset[r][c];
						if(c < dataset[r].length - 1){
							row += ",";
						}else{
							row += "\n";
						}
					}
					writer.append(row);
				}
			}else if(selected instanceof WillingnessCards){
				String[] colNames = logger.getColNames(tabbedPane.getSelectedIndex());
				ArrayList<hems.display.report.LoggerTimeserie.TimeInstant<Double>> ts = logger.getSeries(tabbedPane.getSelectedIndex());
				
				writer.append("timestamp,");
				for(int n = 0; n < colNames.length; n++){
					writer.append(colNames[n]);
					if(n < colNames.length -1) writer.append(",");
				}writer.append("\n");
				
				for(hems.display.report.LoggerTimeserie.TimeInstant<Double> t : ts){
					// as the unix time is in secs we need to divide by 1000 to get it from the ms value
					writer.append(""+ (t.time.getTimeInMillis()/1000) ); writer.append(",");
					
					int colnum = t.getValues().size();
					
					for(int c = 0; c < colnum; c++){
						writer.append(""+t.getValues().get(c));
						if(c < colnum -1) writer.append(",");
					}
					writer.append('\n');
				}
				
			}
			
			writer.flush();
			writer.close();	
		}
		
	}
	
	public void clear(){		
		
		for(int i = 0; i < tabbedPane.getTabCount(); i++){
			//TimeSeriesCollection tsc = (TimeSeriesCollection) ((ChartPanel) ((JPanel) tabbedPane.getComponentAt(i)).getComponent(0)).getChart().getXYPlot().getDataset();
			if(tabbedPane.getComponentAt(i) instanceof ChartPanel){
				TimeSeriesCollection tsc = (TimeSeriesCollection) ((ChartPanel) tabbedPane.getComponentAt(i)).getChart().getXYPlot().getDataset();
				for(int j=0; j< tsc.getSeriesCount(); j++){
					tsc.getSeries(j).clear();
				}
			}
		}
	}
	
	
	public void setWindowSize(int size){
		
		int periods = 0;
		
		// second-based simulation -> 1 second = 1 time period
		switch(size){
			case MINUTE_LENGHT: // 1 minute
				periods = 60;
				break;
				
			case HOUR_LENGHT: // 1 hour
				periods = 3600;
				break;
				
			case DAY_LENGHT: // 1 day
				periods = 86400;
				break;
				
			case WEEK_LENGHT:	// 7 days
				periods = 604800;
				break;
				
			case MONTH_LENGHT:	// 31 days
				periods = 2678400;
				break;
				
			case YEAR_LENGHT: // 365 days
				periods = 31536000;
				break;
				
			default: // whole simulation
				break;
		}
		
		
		if(periods > 0){
			for(int i = 0; i < tabbedPane.getTabCount(); i++){
				if(tabbedPane.getComponentAt(i) instanceof ChartPanel){
					TimeSeriesCollection tsc = (TimeSeriesCollection) ((ChartPanel) tabbedPane.getComponentAt(i)).getChart().getXYPlot().getDataset();
					
					for(int j=0; j< tsc.getSeriesCount(); j++){
						tsc.getSeries(j).setMaximumItemAge(periods);
					}
				}
			}
		}
		
		
		windowSize = periods;
	}
	
	private ChartPanel makeChartPanel(String title, String x, String y, String[] legend){
		
		final ChartPanel chartPanel;
		
		XYDataset dataset = createDataset(legend);
		JFreeChart chart = ChartFactory.createTimeSeriesChart(
							title,		// title
							x,			// x-axis label
							y,   		// y-axis label
							dataset,            // data
							true,               // create legend?
							true,               // generate tooltips?
							false               // generate URLs?
							);

		// transparent background
		chart.setBackgroundPaint(new Color(0xFF, 0xFF, 0xFF, 0));
		chart.getLegend().setPosition(RectangleEdge.RIGHT);
		//chart.setBackgroundPaint(Color.white);
		XYPlot plot = (XYPlot) chart.getPlot();
		plot.setBackgroundPaint(Color.lightGray);
		plot.setDomainGridlinePaint(Color.white);
		plot.setRangeGridlinePaint(Color.white);
		plot.setAxisOffset(new RectangleInsets(5.0, 5.0, 5.0, 5.0));
		plot.setDomainCrosshairVisible(true);
		plot.setRangeCrosshairVisible(true);
		
		plot.setDomainPannable(true);
		plot.setRangePannable(true);

		XYItemRenderer r = plot.getRenderer();
		if (r instanceof XYLineAndShapeRenderer) {
			XYLineAndShapeRenderer renderer = (XYLineAndShapeRenderer) r;
			renderer.setBaseShapesVisible(true);
			renderer.setBaseShapesFilled(true);
			renderer.setDrawSeriesLineAsPath(true);
		}
		
		DateAxis axis = (DateAxis) plot.getDomainAxis();
		axis.setDateFormatOverride(new SimpleDateFormat("yyyy MMM dd HH:mm:ss"));
		
		// added for testing
	    axis.setTickMarkPosition(DateTickMarkPosition.MIDDLE);
		axis.setAutoRange(true);
		// ---
		
		chartPanel = new ChartPanel(chart);
		chartPanel.setFillZoomRectangle(true);
		chartPanel.setMouseWheelEnabled(true);
		
		chartPanel.setMinimumDrawWidth( 0 );
		chartPanel.setMinimumDrawHeight( 0 );
		chartPanel.setMaximumDrawWidth( 1920 );
		chartPanel.setMaximumDrawHeight( 1200 );
		
		return chartPanel;
	}
	
	private ChartPanel makeSteppedPanel(String title, String x, String y, String[] legend){
		
		ChartPanel chartPanel;
		
		XYDataset dataset = createDataset(legend);
		
		JFreeChart chart = ChartFactory.createXYStepChart(
							title,					// title
							x,						// x-axis label
							y,   					// y-axis label
							dataset,            	// data
							PlotOrientation.VERTICAL,
							true,               // create legend?
							true,               // generate tooltips?
							false               // generate URLs?
							);

		// transparent background
		chart.setBackgroundPaint(new Color(0xFF, 0xFF, 0xFF, 0));
		chart.getLegend().setPosition(RectangleEdge.RIGHT);
		//chart.setBackgroundPaint(Color.white);
		XYPlot plot = (XYPlot) chart.getPlot();
		plot.setBackgroundPaint(Color.lightGray);
		plot.setDomainGridlinePaint(Color.white);
		plot.setRangeGridlinePaint(Color.white);
		plot.setAxisOffset(new RectangleInsets(5.0, 5.0, 5.0, 5.0));
		plot.setDomainCrosshairVisible(true);
		plot.setRangeCrosshairVisible(true);
		
		plot.setDomainPannable(true);
		plot.setRangePannable(true);

		XYItemRenderer r = plot.getRenderer();
		if (r instanceof XYLineAndShapeRenderer) {
			XYLineAndShapeRenderer renderer = (XYLineAndShapeRenderer) r;
			renderer.setBaseShapesVisible(true);
			renderer.setBaseShapesFilled(true);
			renderer.setDrawSeriesLineAsPath(true);
		}
		
		DateAxis axis = (DateAxis) plot.getDomainAxis();
		axis.setDateFormatOverride(new SimpleDateFormat("yyyy MMM dd HH:mm:ss"));
		
		// added for testing
	    axis.setTickMarkPosition(DateTickMarkPosition.MIDDLE);
		axis.setAutoRange(true);
		// ---
		
		chartPanel = new ChartPanel(chart);
		chartPanel.setFillZoomRectangle(true);
		chartPanel.setMouseWheelEnabled(true);
		
		chartPanel.setMinimumDrawWidth( 0 );
		chartPanel.setMinimumDrawHeight( 0 );
		chartPanel.setMaximumDrawWidth( 1920 );
		chartPanel.setMaximumDrawHeight( 1200 );
		
		
		return chartPanel;
	}
	
	private static XYDataset createDataset(String[] legend) {
	
		TimeSeriesCollection dataset = new TimeSeriesCollection();
		
		for(String l : legend){
			TimeSeries s = new TimeSeries(l);			
			dataset.addSeries(s);
		}
		
		return dataset;
	}
	
	public void updateMarketQuality(MarketEval mv){
		
		ChartPanel cp = ((ChartPanel) tabbedPane.getComponentAt(TimeserieID.MARKET.ordinal()));
		JFreeChart jfc = cp.getChart();
		jfc.setNotify(false);
		
		TimeSeriesCollection dataset = (TimeSeriesCollection) jfc.getXYPlot().getDataset();
		List<TimeSeries>ts = dataset.getSeries();
		
		TimeSeries me = ts.get(0);
		me.addOrUpdate(new Second(mv.date.getTime()), mv.marketEfficiency);
		
		// -----------------
		ArrayList<Double> values = new ArrayList<Double>();
		values.add(mv.marketEfficiency);
		logger.addInstant(TimeserieID.MARKET.ordinal(), mv.date, values);
		// -----------------
		
		jfc.setNotify(true);
	}
	
	public void updateWillingnessToTrade(Calendar currentTime, HashMap<String, TraderWillingness> willingness){
		/*
		 * Willingness = {tendency, amountToBuy, amountToSell, 
		 * 				delayToleranceLeft, relDelayToleranceLeft, 
		 * 				priceSensitivity, reservationPrice, idlePower}
		 */
		
		// the logger requires values ordered always in the same way
		ArrayList<Double> values = new ArrayList<Double>();	
		for(String name : agentNames){
			values.add(willingness.get(name).tradingTendency);				// willingness to trade
			values.add(willingness.get(name).relativeDelayToleranceLeft);	// relative delay tolerance left
			values.add(willingness.get(name).offerImportance);				// offer importance
		}
		
		// update logger
		logger.addInstant(TimeserieID.WILLINGNESS.ordinal(), currentTime, values);
		
		// update interface
		((WillingnessCards) tabbedPane.getComponentAt(TimeserieID.WILLINGNESS.ordinal())).updateWillingnessToTrade(currentTime, values);	
	}
	
	public void updatePriceSensitivity(Calendar currentTime, HashMap<String, TraderWillingness> willingness){
		/*
		 * Willingness = {tendency, amountToBuy, amountToSell, 
		 * 				delayToleranceLeft, relDelayToleranceLeft, 
		 * 				priceSensitivity, reservationPrice, idlePower}
		 */
		
		ArrayList<Double> values = new ArrayList<Double>();
		
		for(String name : agentNames){
			values.add(willingness.get(name).priceSensitivity); // price sensitivity
			values.add(willingness.get(name).reservationPrice); // reservation price
		}
		
		// update logger
		logger.addInstant(TimeserieID.SENSITIVITY.ordinal(), currentTime, values);
				
		// update interface
		((PriceSensitivityCards) tabbedPane.getComponentAt(TimeserieID.SENSITIVITY.ordinal())).updateSensitivity(currentTime, values);
	}

	public void update(TimeInstant ti) {
		
		try {
			SwingUtilities.invokeAndWait(new Updater(ti, tabbedPane));
        }
        catch (InvocationTargetException e) {
            e.printStackTrace();
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }		
	}
	
	public class Updater implements Runnable {
		private TimeInstant ti;
		//private JPanel cards;
		private JTabbedPane tabbedPane;
		
		//public Updater(TimeInstant ti, JPanel cards) {
		public Updater(TimeInstant ti, JTabbedPane tabbedPane){
			this.ti = ti;
			this.tabbedPane = tabbedPane;
		}
		
		@Override
		public void run() {
			// update all the charts
			ChartPanel cp;
			JFreeChart jfc;
			TimeSeriesCollection dataset;
			List<TimeSeries> ts;
			
			// Update the price, power, self-consumption and weather tab
			// and leave the market and discomfort tabs out of the game
			
			for(int i = 0; i < TimeserieID.MARKET.ordinal(); i++){
				cp = ((ChartPanel) tabbedPane.getComponentAt(i));
				jfc = cp.getChart();
				jfc.setNotify(false);
				dataset = (TimeSeriesCollection) jfc.getXYPlot().getDataset();
						
				ts = dataset.getSeries();
				
				ArrayList<Double> values = new ArrayList<Double>();
				
				switch(jfc.getTitle().getText()){
					case "Price":
						// AVG energy cost
						TimeSeries grid = ts.get(0);
						grid.addOrUpdate(new Second(ti.date.getTime()), ti.gridEnergyCost);
						// AVG fit tariff
						TimeSeries fit = ts.get(1);
						fit.addOrUpdate(new Second(ti.date.getTime()), ti.fitEnergyCost);
						// AVG transaction price
						TimeSeries local = ts.get(2);
						local.addOrUpdate(new Second(ti.date.getTime()), ti.localEnergyCost);
						
						// -----------------
						values.add(ti.gridEnergyCost);
						values.add(ti.fitEnergyCost);
						values.add(ti.localEnergyCost);
						logger.addInstant(TimeserieID.PRICE.ordinal(), ti.date, values);
						// -----------------
						break;
								
					case "Power":
						ts.get(0).addOrUpdate(new Second(ti.date.getTime()), ti.tradedLocalDemand);
						ts.get(1).addOrUpdate(new Second(ti.date.getTime()), ti.tradedDemandFromLocalGeneration);
						
						ts.get(2).addOrUpdate(new Second(ti.date.getTime()), ti.tradedPowerFedIntoGrid);
						
						ts.get(3).addOrUpdate(new Second(ti.date.getTime()), ti.actualGridAvailability);
						ts.get(4).addOrUpdate(new Second(ti.date.getTime()), ti.actualLocalProduction);
						ts.get(5).addOrUpdate(new Second(ti.date.getTime()), ti.actualGridAvailability + ti.actualLocalProduction);
						
						// -----------------
						values.add(ti.tradedLocalDemand);
						values.add(ti.tradedDemandFromLocalGeneration);
						values.add(ti.tradedPowerFedIntoGrid);
						values.add(ti.actualGridAvailability);
						values.add(ti.actualLocalProduction);
						values.add(ti.actualGridAvailability + ti.actualLocalProduction);
						
						logger.addInstant(TimeserieID.POWER.ordinal(), ti.date, values);
						// -----------------
						break;
						
					case "Self-consumption":
						double selfconsumption = 0.0; if(ti.actualLocalProduction > 0.0) selfconsumption = ti.tradedDemandFromLocalGeneration / ti.actualLocalProduction;
						
						TimeSeries selfconsumptionSerie = ts.get(0);
						selfconsumptionSerie.addOrUpdate(new Second(ti.date.getTime()), selfconsumption);
						// -----------------
						values.add(selfconsumption);
						logger.addInstant(TimeserieID.SELFCONSUMPTION.ordinal(), ti.date, values);
						// -----------------
						break;
								
					case "Weather":
						TimeSeries location = ts.get(0);
						//location.add(new Second(ti.date.getTime()), ti.sunFactor);
						location.addOrUpdate(new Second(ti.date.getTime()), ti.sunFactor);
						
						// -----------------
						values.add(ti.sunFactor);
						logger.addInstant(TimeserieID.WEATHER.ordinal(), ti.date, values);
						// -----------------
						break;
				}
				
				jfc.setNotify(true);
			}
		}
	}
}