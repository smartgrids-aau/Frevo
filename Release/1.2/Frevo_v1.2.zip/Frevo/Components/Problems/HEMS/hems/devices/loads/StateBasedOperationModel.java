package hems.devices.loads;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import hems.Debugger;
import hems.devices.modelManager.RemoteManagerUanavailableException;
import hems.market.priceModel.PriceModel;

public class StateBasedOperationModel extends OperationModel{
	
	// *** appliance usage model ***
	protected UsageModel usageModel;
	
	// *** state-based model ***
	protected int deviceState;
	protected DeviceStateModel stateModel;
		
	// *** Properties of the currently running state ***
	protected boolean started;							// the device is operating
	protected boolean newStateToRun;					// the device concluded a state and has to run a new one

	protected long startTime;							// start time in milliseconds
	protected ArrayList<Integer> runs;					// time intervals already run
	protected long lastSuccessfulRunTime;				// time (in millisecs) the device could run for the last time (and make an offer for the current state)
	
	protected boolean decisionToOperateWasTaken;		// did the agent decide to start operate already?
	protected long timeDecisionToOperateWasTaken;		// time the decision to run was made (in millisecs)
	
	protected boolean enabledToRun;						// the device is enabled to start at next update
	protected boolean previousStatus;					// state of the device at the previous time instant (ON/OFF)

	protected double temporaryReward;					// utility delivered by operating the device in a specific state, under the price sensitivity
	
	// hard deadline between a first offer and the starting time
	protected boolean firstOfferExpiration;				// flag to enable this functionality
	protected int expirationDeadline;					// window after which the device is considered unresponsive i.e. unable-to-rationally-make-an-offer-to-run
	
	public StateBasedOperationModel(PriceModel priceSensitivity, DeviceStateModel deviceStateModel, UsageModel usageModel){
		
		super(priceSensitivity);
		
		this.usageModel = usageModel;
		
		deviceState = 0;
		this.stateModel = deviceStateModel;	
		
		started = false;
		newStateToRun = false;
		
		enabledToRun = false;
		previousStatus = false;
		
		this.firstOfferExpiration = false;
		this.expirationDeadline = 0;
		
		runs = new ArrayList<Integer>();	// run intervals
		
		temporaryReward = 0;
		
		// performance metrics for the load (these factors create discomfort and should be minimized)
		moneySpentWithGrid = 0;								// expenses for energy bought from the Grid (to be minimized)
		decisionToOperateWasTaken = false;
		timeDecisionToOperateWasTaken = 0;
		lastSuccessfulRunTime = 0;
	}
	
	// ----------------------------		
	public void buildCriticalLoad(int expirationDeadline){
		this.firstOfferExpiration = true;
		this.expirationDeadline = expirationDeadline;
	}
	// ----------------------------
	@Override
	public int getDelaySensitivity(){
		return this.stateModel.getDelayTolerance(this.deviceState);
	}
	
	public int getCurrentState(){
		return this.deviceState;
	}
	
	public double getMaxCurtailabilityForCurrentState(){
		return this.stateModel.getMaxCurtailabilityFactor(this.deviceState);
	}
	
	/**
	 * Returns the demand of the device at the next allocation time
	 * it is used by the decision maker to know whether it is necessary to run at next time
	 * ATTENTION! the method is not idempotent, and should be only called once per trading day (beginning)
	 * @throws RemoteManagerUanavailableException 
	 */
	@Override
	public int getFutureDemand(Calendar simulationTime, Calendar allocationTime) throws RemoteManagerUanavailableException {
		int demand = 0; 	// initially the device does not want to run at next time instant
		
		// the demand of the device depend on its necessity to terminate ongoing operations
		// or the willingness to start a new operation

		if(started){
			// *** the device is already operating ***
			
			// check the duration of the device to manage the multiple states
			int elapsedSeconds = 0;
			// include the current state in case we are running
			if(this.enabledToRun) elapsedSeconds = (int) ((allocationTime.getTimeInMillis() - this.startTime) / 1000);
			// check how long the device has been already running
			for(Integer s : runs) elapsedSeconds += s;
			
			// check if the current state is over
			if(elapsedSeconds >= stateModel.getDuration(deviceState)){
				// we have completed the current state
				
				if(this.stateModel.hasFurtherStates(this.deviceState)){
					// we have further states to run
					newStateToRun = true;
					
					// go to next state (+1 mod lenght)
					this.deviceState = this.stateModel.next(deviceState);
					
					// get the demand for the next state
					demand = this.stateModel.getPeakPower(this.deviceState);
					
				}else{
					// we do NOT have other states to run, we conclude the operation
					started = false;
					this.decisionToOperateWasTaken = false;
					
					// add a completed run for the current time interval
					this.usageModel.addConcludedOperationForCurrentInterval();
					
					// go to next state (+1 mod lenght)
					this.deviceState = this.stateModel.next(deviceState);					
				}
				
				// clean the runs for the current concluded state
				runs.clear();
				
			}else{
				// we need to complete the current state, possibly with no interruptions
				demand = this.stateModel.getPeakPower(this.deviceState);
			}
			
		}else{
			// ** The device is OFF currently **
			
			// check if the device wants to run but for some reason could not make a first offer
			if(decisionToOperateWasTaken){
				demand = this.stateModel.getPeakPower(this.deviceState);
				//System.err.println("return previous demand: "+demand);
				
			}	// check if it wants to start at next time
			else if( this.randomGen.nextDouble() > (1.0 - this.usageModel.getInstantaneousWillingnessToStart(allocationTime) )){ 
				// TODO: shouldn't the decision be based on the current time? we can't predict the future, even of 1 second
				
				demand = this.stateModel.getPeakPower(0);
				
				// keep track of the time the decision to start was taken
				this.timeDecisionToOperateWasTaken = simulationTime.getTimeInMillis();
				this.decisionToOperateWasTaken = true;
				
				//System.err.println("decision to operate was taken");
			}
			// ELSE: no need to run
		}
		return demand;
	}
	// ----------------------------
	@Override
	public boolean isWithinHardDeadline(Calendar simulationTime){
		boolean isWithinDeadline = true;
		
		Long timeOfferWasMade =  Math.max(this.timeDecisionToOperateWasTaken,	// the device did not start yet, it only made a first offer to start 
										this.lastSuccessfulRunTime);			// the device had its first offer accepted but got stuck on the way

		// being the time in the past, we have waited at least 1 sec.
		int waitedTime = ((int) ((simulationTime.getTimeInMillis() - timeOfferWasMade) / 1000)) -1;
		
		//System.out.println("\t Offer waited for "+waitedTime+" secs");
		
		// if the deadline exists and was exceeded?
		if(firstOfferExpiration && waitedTime >= expirationDeadline){
			isWithinDeadline = false;
			
			// add a violation to keep track of it
			this.timesUnallocatedWithinHardDeadline++;
			
			// restart the device
			this.started = false;
			this.deviceState = 0;
			runs.clear();
			// we do not need to reset the usage model, as the current operation was not completed
			// and therefore this had no effect on the usage model, we should keep
			// the same probability to start for the remaining time
			
			// restart the hard deadline window, simulating the decision to operate at the current time instant
			this.timeDecisionToOperateWasTaken = simulationTime.getTimeInMillis();
			// the alternative is to set decisionToOperateWasTaken to False to check again the willingness to start
			// neverhteless, this is like the device has the chance to change its mind and decide not to operate
			// given the current probability to start (which might be lower for the current time interval).
			
			
		}
		
		return isWithinDeadline;
	}
	
	// ----------------------------
	@Override
	public StateBasedOperationModel clone() {
		StateBasedOperationModel model = new StateBasedOperationModel(this.priceSensitivity, this.stateModel, this.usageModel.clone());
		
		// attributes from the super class
		model.table = this.table;
		model.randomGen = this.randomGen;
		model.serviceFlexibility = this.serviceFlexibility;
		
		if(this.firstOfferExpiration){
			model.buildCriticalLoad(this.expirationDeadline);
		}
		return model;
	}
	
	private void notifyChange(){
		ArrayList<String[]> values = new ArrayList<String[]>();
		// get all operations of the device
		for(OperationStats stats : operations){
			// get all states of an operation
			for(StateOperation o : stats.getAllStatesStats()){
				String[] operation = { ""+o.deviceState,
										this.format.format(o.firstOfferTime),
										this.format.format(o.stateBeginningTime),
										""+(o.concluded? o.operationDuration :"*")+" ("+this.stateModel.getDuration(o.deviceState)+")",
										""+(o.startDelay - this.stateModel.getDelayTolerance(o.deviceState))+" ("+o.startDelay+" of "+this.stateModel.getDelayTolerance(o.deviceState)+")",
										""+o.interruptions.toString().replace(",", " "),
										""+(o.concluded? o.reward :"*")};
				values.add(operation);
			}
		}
		
		if(table != null) table.updateTable(values);
	}
	
	@Override
	public boolean isRunning(){
		return this.enabledToRun;
	}
	
	@Override
	public void allowToRun(int amount, Calendar simulationTime){
		// save the current state as previous state
		this.previousStatus = this.enabledToRun;
		
		// set the new status for the next time instant
		if(amount > 0){
			this.enabledToRun = true;
			this.temporaryReward += amount * this.priceSensitivity.getPrice(simulationTime) / (1000*3600);
		}else{
			this.enabledToRun = false;
		}
	}
	
	public boolean isInterState(){
		return !started							// the device was not yet started 
				|| (started && newStateToRun);	// the device was started and has completed already states
	}
	
	
	/**
	 * To be called at each iteration to update the status of the device (and its infos)
	 * @param currentTime
	 */
	@Override
	public void updateStatus(Calendar currentTime){
		
		// ---- Update willingness ------
		this.usageModel.updateInterval(currentTime);
		
		// ---- Manage the device status ----
		if(this.enabledToRun){	
			
			if(started){
				// keep the time going
				
				// check if the current state is a new one
				if(this.newStateToRun){
					// *** State_n -> State_n+1 ***
					this.startTime = currentTime.getTimeInMillis();
					this.newStateToRun = false;

					// --- create a new operation information object for the current state ---
					int delayedStart = ((int) ((currentTime.getTimeInMillis() - this.lastSuccessfulRunTime) / 1000)) -1;
					
					this.currentOperationStats.concludeStateOperation(this.lastSuccessfulRunTime, temporaryReward);			
					temporaryReward = 0;
					
					this.currentOperationStats.addStateOperation(this.lastSuccessfulRunTime,
																this.deviceState,
																delayedStart,
																this.startTime);
					// notify change on the data model
					this.notifyChange();
				}else if(!previousStatus){
					// *** PAUSE -> RUNNING ***
					Debugger.printLoadInfo(" Update: PAUSE -> Running");
					
					this.startTime = currentTime.getTimeInMillis();
					
					// compute the amount of time the device was paused while running an atomic state
					int pausedSeconds = ((int) ((currentTime.getTimeInMillis() - this.lastSuccessfulRunTime) / 1000)) -1; 
					// -1 is needed because the time is taken between two consecutive running times
					
					// update the operation information object
					this.currentOperationStats.addInterruption(pausedSeconds);	// the delay is added for the current state
					
					// notify change on the data model
					this.notifyChange();
				}
				
			}else{
				// *** OFF -> ON ***
				// the device was not running previously
				this.startTime = currentTime.getTimeInMillis();
				started = true;		// the device has started running,
				
				// compute the time the device has waited before starting a state (which might be the first start, or one of the following states)
				int delayedStart = ((int) ((currentTime.getTimeInMillis() - this.timeDecisionToOperateWasTaken) / 1000)) -1;
				// we need -1 because the time between the offer was made and accepted/run is always at least 1
				
				Debugger.printLoadInfo("The device has been waiting "+delayedStart+
									" before starting (now:"+this.format.format(currentTime.getTime())+
									", firstOffer:"+this.format.format(new Date(this.timeDecisionToOperateWasTaken))+")");
				
				// create a new operation information object for the current state
				this.currentOperationStats = new OperationStats();
				// add this operation to the list of all operations of the device
				this.operations.add(currentOperationStats);
				this.currentOperationStats.addStateOperation(timeDecisionToOperateWasTaken,
															this.deviceState, 
															delayedStart,
															this.startTime);
				// notify change on the data model
				this.notifyChange();
			}
			
			// last successful running time was now
			lastSuccessfulRunTime = currentTime.getTimeInMillis();	// we put it here because we used the current value to compute the pausedSeconds
			
		}else{
			// check if the device was started and was running at the previous time instant
			// but also make sure that the device is not in between two states, as this would mess up the counting of the elapsed time
			if(started && previousStatus && !this.newStateToRun){
				// *** Running -> Paused ***
				
				// the device did not win the contention for this state
				// its running interval was stopped at the current time,
				// we add the sub-interval to the runs arraylist to keep track of the whole duration
				runs.add(new Integer((int) ((currentTime.getTimeInMillis() - this.startTime) / 1000)));
				
			}else if(!started && previousStatus){
				// *** ON -> OFF ***
				Debugger.printLoadInfo(" **STOP** ");
				// the device was previously ON and it is not started anymore, which happens only when the state is concluded
				this.currentOperationStats.concludeStateOperation(this.lastSuccessfulRunTime, temporaryReward);
				temporaryReward = 0;
				this.notifyChange();
			}
			
			// else the device was not yet started
			// or it is in between two states and its run time was already counted previously
		}
	}
	
	// *************************************************************************************************************
	
	public double getCumulativeReward(){
		double cumulativeReward = 0.0;
		
		for(OperationStats stats : this.operations){
			for(StateOperation ops : stats.getAllStatesStats()){
				cumulativeReward += ops.reward;
			}
		}
		
		return cumulativeReward;
	}
	
	public boolean hasRunAtLeastOnce(){
		int nonEmptyOperations = 0;
		for(OperationStats s : this.operations){
			if(s.getAllStatesStats().size() > 0)
				nonEmptyOperations++;
		}
		return nonEmptyOperations > 0;
	}
	
	/**
	 * The device has ever run more than a state in its operations?
	 * @return
	 */
	public boolean hasRunAtLeastOnceAndMoreThanAState(){		
		int operationsWithMoreThanAStateRun = 0;
		
		for(OperationStats s : this.operations){
			if(s.getAllStatesStats().size() > 1)
				operationsWithMoreThanAStateRun++;
		}
		
		return operationsWithMoreThanAStateRun > 0;
	}
	
	// ------------------------------------------------------------------------------------------------------------
	/**
	 * Returns the average relative time waited before starting each intermediate state
	 * it basically considers the delay sensitivity of each state to determine the relative overwaited time
	 * the first state is skipped, as it is not part of the operation but of the user discomfort
	 * @return
	 */
	public double getAverageRelativeOverwaitedTimeToStartIntermediateStates(){
		double avg = 0;
		
		// for each operation of the device
		for(OperationStats s : this.operations){
			double relativeOverwaitedTime = 0;
			
			// get all information for each state
			ArrayList<StateOperation> states = s.getAllStatesStats();
			
			// check only the operation with at least 2 states
			if(states.size() > 1){
				// get only the second state (S_2 .. S_n)
				for(int i = 1; i < states.size() ; i++){
					
					// get the current state
					StateOperation o = states.get(i);
					
					int overwaitedSeconds = o.startDelay - this.stateModel.getDelayTolerance(o.deviceState);
					// overwaitedSeconds = overwaitedSeconds > 0 ? overwaitedSeconds : 0;	// this was initially used to only consider the times the device waited over the sensitivity
					
					// compute the relative overwaited time for the state 
					// (as states can have different sensitivity and therefore a simple average would not make sense in the end) 
										
					// if the device has a tolerance then normalize the excessively waited time
					if(this.stateModel.getDelayTolerance(o.deviceState) > 0){
						relativeOverwaitedTime += (double) overwaitedSeconds / (double) this.stateModel.getDelayTolerance(o.deviceState);
					}else{
						// else each overwaited time is already normalized to 0
						relativeOverwaitedTime += overwaitedSeconds;
					}
					
				}
				// compute the average for the current operation
				avg += relativeOverwaitedTime / (states.size() - 1); // the first state is not included
				
			}
		}
		// avoid division by 0 and 1
		if(operations.size() > 1){
			avg /= this.operations.size();
		}
		
		// return the average of all operations for the device
		return avg;
	}
	
	// ------------------------------------------------------------------------------------------------------------
	/**
	 * Returns the average time to start the device (only first state is considered)
	 * @return
	 */
	public double getAverageWaitedTimeToStartDevice(){
		double avgWaitedTimeToStart = 0;
		
		for(OperationStats s : this.operations){
			// the average starting delay of an operation is the average of the delay to start the first state
			StateOperation so = s.getAllStatesStats().get(0);
			// get only the delay to start the first state
			avgWaitedTimeToStart += so.startDelay;
		}
		
		// average the value for all operations of the device, avoiding division by 0 and 1
		if(operations.size() > 1) avgWaitedTimeToStart /= operations.size();
		
		return avgWaitedTimeToStart;
	}
	
	/**
	 * Returns the average relative time to start the device (only first state is considered)
	 * @return
	 */
	public double getAverageRelativeTimeToStartDevice(){
		double avg = this.getAverageWaitedTimeToStartDevice();
		
		// check if we can tolerate a delayed start
		if(this.stateModel.getDelayTolerance(0) > 0) avg /= (double) this.stateModel.getDelayTolerance(0);
		
		return avg;
	}
	
	/**
	 * Returns the average relative time excessively waited before starting the device
	 * @return
	 */
	public double getAverageRelativeOverwaitedTimeToStartDevice(){
		double avg = 0.0; 
		
		if(operations.size() > 0){
			double excessivelyWaited = this.getAverageWaitedTimeToStartDevice() - (double) this.stateModel.getDelayTolerance(0);
			
			// check if we can tolerate a delayed start
			if(this.stateModel.getDelayTolerance(0) > 0){
				// compute the relative value over the average excessively waited time
				avg = excessivelyWaited / (double) this.stateModel.getDelayTolerance(0);
			}else{
				// otherwise the relative waited time to start the device equals the waited time
				// as we could tolerate 0 delay (in secs)
				avg = excessivelyWaited;
			}
		}
		
		return avg;
	}
	// ------------------------------------------------------------------------------------------------------------
	
	/**
	 * Returns the average waited time before starting an intermediate state
	 * it skips the first state, see OperationStats class
	 * @return
	 */
	public double getAverageWaitedTimeToStartIntermediateStates(){
		double avgWaitedTimeToStart = 0.0;
		
		for(OperationStats s : this.operations){
						
			// the average starting delay of an operation is the average of the delay of each state
			avgWaitedTimeToStart += s.getAvgStartingDelayIntermediateStates();
		}
		
		// avoid division by 0
		if(operations.size() > 1) avgWaitedTimeToStart /= (double) operations.size();
		
		return avgWaitedTimeToStart;
	}
	
	/**
	 * Returns the average of the relative delay to start each intermediate state 
	 */
	public double getAverageRelativeWaitedTimeToStartIntermediateStates(){
		double avg = 0.0;
		int nonEmptyOperations = 0;	
		// even though we only add operations when a device starts
		// we make sure that we do not include empty operations
		
		for(OperationStats s : this.operations){
			// Get all state operations for the current operation
			ArrayList<StateOperation> states = s.getAllStatesStats();
			
			// make sure there are at least two states in the operation
			if(states.size() > 1){	// we always need at least two states, as the first is not considered
				nonEmptyOperations++;
				
				double avgStateOperation = 0.0;
				
				// get from the second state on
				for(int i = 1; i < states.size(); i++){
					StateOperation o = states.get(i);

					// compute the time excessively waited for the state
					int overwaited = o.startDelay - this.stateModel.getDelayTolerance(o.deviceState);
					
					// if the device has a tolerance then normalize the excessively waited time
					if(this.stateModel.getDelayTolerance(o.deviceState) > 0){
						avgStateOperation += (double) overwaited / (double) this.stateModel.getDelayTolerance(o.deviceState);
					}else{
						// else each overwaited time is already normalized to 0
						avgStateOperation += overwaited;
					}
				}
				// compute the average relative for the current operation
				avg += avgStateOperation / (states.size() - 1);	// the first state is not included 
			}
		}
		// compute the average over all non empty operations
		if(nonEmptyOperations > 1) avg /= nonEmptyOperations;
		
		return avg;
	}
	
	// ------------------------------------------------------------------------------------------------------------	
	/**
	 * Returns the average relative completion time of each state per each operation
	 * it basically considers the interruption sensitivity of each state to determine the relative completion time
	 * @return
	 */
	public double getAverageRelativeInterruptionTime(){
		double avg = 0.0;
		int nonEmptyOperations = 0;
		
		// for each operation of the device
		for(OperationStats s : this.operations){
			
			double relativeInterruptionTime = 0.0;
					
			// get all information for each state		
			ArrayList<StateOperation> states = s.getAllStatesStats();
			
			if(states.size() > 0){
				nonEmptyOperations++;
				
				// ---------
				boolean goAhead = true;
				int i = 0;	for(  ; goAhead && i < states.size(); ){
					// get the current state
					StateOperation o = states.get(i);
					
					if(o.concluded){
						// compute the relative average interruption time for the state
						// as different states might have different interruption sensitivity
						//System.out.println("State_"+i+": "+o.getAvgRelativeInterruptionTime(this.stateModel.getInterruptionTolerance(o.deviceState))+" while tolerates "+this.stateModel.getInterruptionTolerance(o.deviceState));
						relativeInterruptionTime += o.getAvgRelativeInterruptionTime(this.stateModel.getInterruptionTolerance(o.deviceState));
						i++;
					}else{
						// get outta here
						goAhead = false;
					}
				}
				
				// compute the average over all states of the operation
				if(i > 0) avg += relativeInterruptionTime / i; // compute the average relative for the current operation
				// ---------
			}		
			
		}
		
		// compute the average out of all operations of the device
		
		// avoid division by 0 and 1 (nonsense)
		if(nonEmptyOperations > 1){
			avg /= nonEmptyOperations;
		}
		
		return avg;
	}
	
	/**
	 * Returns the average interruption time for all operations, given that only concluded states are considered in the calculation
	 * @return
	 */
	public double getAverageInterruptionTime(){
		double avgCompletionDelay = 0;
		
		for(OperationStats s : this.operations){
			// the average interruption delay of an operation is the average of the interruption delay of each state
			avgCompletionDelay += s.getAvgInterruptionDelay();
		}
		
		// avoid division by 0 and 1
		if(operations.size() > 1){
			avgCompletionDelay /= (double) operations.size(); 
			// all operations are considered, each operation has for sure at least 1 state
			// since the stateOperation is created when OFF->ON
		}
		
		return avgCompletionDelay;
	}
	// ------------------------------------------------------------------------------------------------------------
	
	
	
	/**
	 * Get current power consumption for the device, based on its current status and state
	 */
	public int getPowerDemand() {
		int power = 0;
		
		if(this.enabledToRun)
			power += this.stateModel.getPeakPower(deviceState);
		
		return power;
	}
}
