package hems.devices.generators;

import java.util.Calendar;

import hems.devices.generators.weather.Weather;
import hems.devices.loads.NotAvailableForTradeException;
import hems.market.MarketStatus;
import hems.market.Offer;

public interface Generator {
	
	public abstract double getCurrentProduction(Calendar date, Weather weather);
}
