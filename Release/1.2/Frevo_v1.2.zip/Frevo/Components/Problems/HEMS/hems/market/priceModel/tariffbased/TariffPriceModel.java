package hems.market.priceModel.tariffbased;

import hems.market.priceModel.PriceModel;

import java.util.Calendar;
import java.util.List;

public class TariffPriceModel implements PriceModel{
	private List<Tariff> tariffPlan;
	
	public TariffPriceModel(List<Tariff> tariffPlan){
		this.tariffPlan = tariffPlan;
	}

	@Override
	public double getPrice(Calendar time) {
		Double price = null;
		for(Tariff tariff : tariffPlan){
			if(tariff.isInTariff(time)){
				price = tariff.getCost();
			}
		}
		return price;
	}

}
