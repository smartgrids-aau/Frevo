package hems.market.priceModel;

import java.util.Calendar;

public class StaticPriceModel implements PriceModel{

	private double price;
	
	public StaticPriceModel(double price){
		this.price = price;
	}
	
	@Override
	public double getPrice(Calendar time) {
		return price;
	}

}
