package hems.devices.generators.capabilityModel.timebased;

import java.util.Calendar;

public class TimeBasedTradeableAmount {
	
	// Attributes
	private int start;
	private int end;
	private int amount;
	
	public TimeBasedTradeableAmount(int startHour, int startMins, int endHour, int endMins, int amount){
		this.start = (60 * startHour) + startMins;
		this.end = (60 * endHour) + endMins; 
		
		// TODO: check possible bug with ending of last minute as ending at 23:59 and starting next at 24:59 means that
		// the last second is not covered by any of the two intervals -> solved in the python version
		this.amount = amount;
	}

	
	public boolean coversThisTime(Calendar time){		
		int current = (60 * time.get(Calendar.HOUR_OF_DAY)) + time.get(Calendar.MINUTE);
		boolean condition = ((current - start + 24*60) %  (24*60)) < (end - start + 24*60) % (24*60);

		return condition;		
	}
	
	public int getAmount(){
		return amount;
	}
	
	@Override
	public String toString(){
		return "Start: "+start+", End: "+end+", Amount: "+amount;
	}
}
