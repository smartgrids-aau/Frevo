package hems.display.report;

import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedHashMap;

public class LoggerTimeserie {
	
	private static LoggerTimeserie instance = null;
	
	private HashMap<Integer, ArrayList<TimeInstant<Double>>> timeseries;
	private HashMap<Integer, String[]> titles;
	// the hashmap collects all tabs, each tab (timeserie) is defined as an array of time instant
	// the time instant is a point in time, and describes multiple double values (matrix)
	
	public LoggerTimeserie(){		
		timeseries = new LinkedHashMap<Integer, ArrayList<TimeInstant<Double>>>();
		titles = new LinkedHashMap<Integer, String[]>();
	}
		
	public ArrayList<TimeInstant<Double>> getSeries(int page){
		return timeseries.get(page);
	}
	
	public String[] getColNames(int page){
		return titles.get(page);
	}
	
	public void addTimeserie(int page, String[] channels){
		timeseries.put(page, new ArrayList<TimeInstant<Double>>());
		titles.put(page, channels);
	}
	
	public void addInstant(int timeserieID, Calendar time, ArrayList<Double> values){
		timeseries.get(timeserieID).add(new TimeInstant<Double>(time, values));
	}
	
	public double[] getAverageValue(int timeserieID){
		BigDecimal[] sumValues = null;
		
		double[] averages = null;		// column to be returned
		
		ArrayList<TimeInstant<Double>> timeserie = timeseries.get(timeserieID);
		
		// if we have data entries
		if(timeserie.size() > 0){
			averages = new double[timeserie.get(0).values.size()];
			sumValues = new BigDecimal[timeserie.get(0).values.size()];
			Arrays.fill(sumValues, BigDecimal.ZERO);
			
			// loop on all points
			for(TimeInstant<Double> entry : timeserie){
				// loop on all columns
				for(int i = 0; i < entry.values.size(); i++){
					sumValues[i] = sumValues[i].add( new BigDecimal(entry.values.get(i)) );
				}
			}
			
			for(int i = 0; i < averages.length; i++){
				BigDecimal average = sumValues[i].divide( BigDecimal.valueOf(timeserie.size()), RoundingMode.HALF_UP );
				averages[i] = average.doubleValue();
			}
		}
		
		if(averages == null) System.out.println("ID: "+timeserieID);
		return averages;
	}
	
	/**
	 * Retusn the min and max values of each column of a timeserie
	 * @param timeserieID
	 * @return a [i][2] matrix with the min (0) and max (1) values of the selected column
	 */
	public double[][] getMinMaxValue(int timeserieID){
		double[][] minMaxValues = null;
		ArrayList<TimeInstant<Double>> timeserie = timeseries.get(timeserieID);
		int colNum = timeserie.get(0).values.size();
		
		if(timeserie.size() > 0){
			minMaxValues = new double[colNum][2];
			
			// loop on all points
			for(TimeInstant<Double> entry : timeserie){
							
				// loop on all columns
				for(int i = 0; i < colNum; i++){
					
					// look for minimal value
					if(entry.values.get(i) < minMaxValues[i][0]){
						minMaxValues[i][0] = entry.values.get(i); 
					}
					
					// look for maximal value
					if(entry.values.get(i) > minMaxValues[i][1]){
						minMaxValues[i][1] = entry.values.get(i); 
					}
				}
			}
		}
		
		return minMaxValues;
	}
	
	public void saveToCSV(String filepath, int timeserieID) throws IOException{
		
		FileWriter writer = new FileWriter(filepath);
		ArrayList<TimeInstant<Double>> timeserie = timeseries.get(timeserieID);	
		String[] columnNames = titles.get(timeserieID);
		
		writer.append("timestamp,");
		for(int i = 0; i < columnNames.length; i++){
			writer.append(columnNames[i]);
			if(i < columnNames.length - 1) writer.append(",");
		} writer.append("\n");
		
		for(TimeInstant<Double> entry : timeserie){
			
			writer.append(""+entry.time.getTimeInMillis()/1000);	// save as unix timestamp
			writer.append(",");
			
			for(int i=0; i < timeserie.get(0).values.size(); i++){
				// append the value for the column
				writer.append(""+entry.getValues().get(i));
				// if the column is not the last one add a comma
				if(i < timeserie.get(0).values.size() -1) 
					writer.append(",");
			}
			// conclude the entry adding a \n
			writer.append("\n");
		}
		
		writer.flush();
		writer.close();
	}
	
	public class TimeInstant<T>{
		public Calendar time;
		public ArrayList<T> values;
		
		public TimeInstant(Calendar time, ArrayList<T> values){			
			// clone the calendar instance to avoid changes
			this.time = Calendar.getInstance();
			this.time.setTime(time.getTime());
			
			this.values = values;
		}
		
		public ArrayList<T> getValues(){
			return values;
		}
	}
}
