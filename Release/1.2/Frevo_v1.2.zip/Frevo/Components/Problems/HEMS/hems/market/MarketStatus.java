package hems.market;

public class MarketStatus {

	public double buyQuote;
	public double sellQuote;
	
	public MarketStatus(){
		// should be +inf and 0
		this.sellQuote = Double.MAX_VALUE;
		this.buyQuote = 0.0;
	}
	
	public MarketStatus(double b, double s){
		this.buyQuote = b;
		this.sellQuote = s;
	}
	
	public void setBuyQuote(double buyQuote){
		this.buyQuote = buyQuote;
	}
	
	public void setSellQuote(double sellQuote){
		this.sellQuote = sellQuote;
	}
	
	/**
	 * Clears the market status after the end of the auction
	 */
	public void clear(){
		this.sellQuote = Double.MAX_VALUE;
		this.buyQuote = 0.0;
	}
	
	@Override
	public String toString(){
		return "BIDQuote = "+this.buyQuote+", ASKQuote = "+this.sellQuote;
	}
}
