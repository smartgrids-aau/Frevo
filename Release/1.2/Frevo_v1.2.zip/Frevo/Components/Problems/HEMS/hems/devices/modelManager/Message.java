package hems.devices.modelManager;

import java.io.Serializable;
import java.util.ArrayList;

@SuppressWarnings("serial")
public class Message implements Serializable {
	private String name;		// Message name
	@SuppressWarnings("rawtypes")
	private ArrayList args;		// Payload
	
	@SuppressWarnings("rawtypes")
	public Message(String name, ArrayList args){
		this.name = name;
		this.args = args;
	}
	
	public String getName(){
		return name;
	}
	
	@SuppressWarnings("rawtypes")
	public ArrayList getArgs(){
		return args;
	}
}
