package hems.display;

import hems.Market;
import hems.Simulator;
import hems.devices.Agent;
import hems.devices.TraderWillingness;
import hems.devices.generators.weather.Weather;
import hems.devices.mainGrid.GridAgent;
import hems.devices.modelManager.RemoteManagerUanavailableException;
import hems.display.marketView.MarketView;
import hems.display.networkStatus.GridStatusPanel;
import hems.display.report.LoggerTimeserie;
import hems.display.report.ReportFrame;
import hems.display.report.SimulationStatusPanel;
import hems.market.MarketEval;
import hems.market.Transaction;
import hems.solvers.Solver;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;

import main.FrevoMain;

public class HEMSDisplay extends JFrame implements Runnable, WindowListener, ActionListener, ItemListener{
	private static final long serialVersionUID = 7548949644440576928L;

	private SimpleDateFormat format = new SimpleDateFormat("yyyy MMM dd HH:mm:ss");
	
	// Controls icons
	private ImageIcon play;
	private ImageIcon pause;
	private ImageIcon forward;
	
	// GUI components
	private JButton btnStartSim;
    private JButton btnNextSim;
    private JButton btnStopSim;
    private GridStatusPanel gridStatus;
	private SimulationStatusPanel simulationStatus;
	private JProgressBar progress;
	
	// Report frame
	private ReportFrame report;
	
	// GUI status
	private int status;
	private boolean terminate;
	
	// marketView stuff
	private JCheckBox enableMarketViewCB;
	private MarketView marketView;
	
	// show messages
	private JCheckBox showMainEventsCB;
	private boolean showNotifications;
	
	// Simulation state
	private Simulator simulator;
	private LoggerTimeserie logger;
		
	public HEMSDisplay( Calendar beginning,
						int simulationDuration,
						Solver solver,
						
						Weather weather, 
						
						int auctionIterations,
						Random randomGen,
						
						ArrayList<GridAgent> grids,
						ArrayList<Agent> prosumers
						){
		this.logger = new LoggerTimeserie();		
		
		// create a new simulation object
		this.simulator = new Simulator(beginning, simulationDuration, prosumers, grids, weather, solver, auctionIterations, randomGen);
		
		// **** Set JFrame stuff
		setTitle("HEMS: Home Energy Market Simulator");		
		setResizable(true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setPreferredSize(new Dimension(1200, 900));
		this.setMinimumSize(new Dimension(1200, 900));
		
		try {
			this.setIconImage(ImageIO.read(new File(FrevoMain.getInstallDirectory()+"/Components/Problems/HEMS/hems/hems_icon.png")));
		} catch (IOException e) {} // no icon found, no problem, go ahead
		
		addWindowListener(this);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.lightGray);
		panel.setLayout(new BorderLayout(5, 5));
		
		JScrollPane scroll = new JScrollPane(panel, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        this.getContentPane().add(scroll, BorderLayout.CENTER);		
		
		// create the top panel
		JPanel top = new JPanel();
		top.setLayout(new BoxLayout(top, BoxLayout.PAGE_AXIS));
		panel.add(top, BorderLayout.PAGE_START);
		
		// create the menu panel and add it to the top panel
		JPanel menu = new JPanel();
		menu.setLayout(new FlowLayout());
		// add the menu first and a separator then
		top.add(menu);
		top.add(new JSeparator(SwingConstants.HORIZONTAL));
		
		// fill the menu with control buttons for the simulation
		btnStartSim = new JButton("Start");
		btnStartSim.setPreferredSize(new Dimension(140,25));
		
		btnNextSim = new JButton("Next");
		btnNextSim.setPreferredSize(new Dimension(100,25));
		
		btnStopSim = new JButton("Stop");
		btnStopSim.setPreferredSize(new Dimension(100,25));
		
		menu.add(btnStopSim);
		menu.add(btnStartSim);
		menu.add(btnNextSim);
		
		// create the checkbox to enable/disable the marketView
		enableMarketViewCB = new JCheckBox("Market view");
		showMainEventsCB = new JCheckBox("Notify Main Events");
		
		JPanel options = new JPanel();
		options.setLayout(new FlowLayout());
		top.add(options);
		options.add(enableMarketViewCB);
		options.add(showMainEventsCB);
		top.add(new JSeparator(SwingConstants.HORIZONTAL));
		
		try {
			String path = "jar:file:" + FrevoMain.getInstallDirectory()	+ "/Libraries/jlfgr/jlfgr-1_0.jar/!" + "/";
			play = new ImageIcon(new URL(path + "toolbarButtonGraphics/media/Play24.gif"));
			forward = new ImageIcon(new URL(path + "toolbarButtonGraphics/media/FastForward24.gif"));
			pause = new ImageIcon(new URL(path + "toolbarButtonGraphics/media/Pause24.gif"));
			btnNextSim.setIcon(new ImageIcon(new URL(path + "toolbarButtonGraphics/media/StepForward24.gif")));
			btnStopSim.setIcon(new ImageIcon(new URL(path + "toolbarButtonGraphics/media/Stop24.gif")));
		} catch (MalformedURLException e1) {
			e1.printStackTrace();
		}
		
		// add the simulation elements
		gridStatus = new GridStatusPanel();
		simulationStatus = new SimulationStatusPanel(prosumers, logger);
		simulationStatus.setWindowSize(SimulationStatusPanel.HOUR_LENGHT);	// charts are shown within a 1 hour window
		
		JPanel simulationPanel = new JPanel();
		panel.add(simulationPanel);
		simulationPanel.setLayout(new BoxLayout(simulationPanel, BoxLayout.PAGE_AXIS));
		simulationPanel.add(gridStatus);
		simulationPanel.add(simulationStatus, BorderLayout.CENTER);
		
		// Create the progress bar
	    progress = new JProgressBar();
	    int progBeginning = (int) (beginning.getTimeInMillis() / 1000);
	    progress.setMinimum(progBeginning);
	    progress.setMaximum(progBeginning + simulationDuration);
	    progress.setStringPainted(true);
	    progress.setString(this.format.format(beginning.getTime()));
	    panel.add(progress, BorderLayout.SOUTH);
		
		// Event management
	    enableMarketViewCB.addItemListener(this);
	    showMainEventsCB.addItemListener(this);
		btnStartSim.addActionListener(this);
		btnNextSim.addActionListener(this);
		btnStopSim.addActionListener(this);
		
		// initialize the interface
		this.gridStatus.updateView(prosumers, grids);
		
		// setup the market view frame and pass it to the solver for prompting debugging messages
		marketView = new MarketView();
		
		// set the reference to the market view on the solver
		solver.setMarketView(marketView);
		
		// add window listener to the market view to capture closing events into the main window
		marketView.addWindowListener(new WindowListener(){
			@Override
			public void windowOpened(WindowEvent e) {}

			@Override
			public void windowClosing(WindowEvent e) {}

			@Override
			public void windowClosed(WindowEvent e) {
				// deselect checkbox to disable window
				enableMarketViewCB.setSelected(false);
				// set marketview invisible
				marketView.setVisible(false);
		    	marketView.setStatus(false);
			}

			@Override
			public void windowIconified(WindowEvent e) {}

			@Override
			public void windowDeiconified(WindowEvent e) {}

			@Override
			public void windowActivated(WindowEvent e) {}

			@Override
			public void windowDeactivated(WindowEvent e) {}
		});
		
		update();
		pack();
	}
	
	public void update(){
		switch(status){
			case 0: // init -> 
				gridStatus.clear();
				simulationStatus.clear();
				
				enableMarketViewCB.setEnabled(false);
				showMainEventsCB.setEnabled(false);
				btnStopSim.setEnabled(false);
				btnStartSim.setEnabled(true); btnStartSim.setText("Start"); btnStartSim.setIcon(play);
				btnNextSim.setEnabled(false);
				break;
			case 1:
				// simulation running				
				enableMarketViewCB.setEnabled(false);
				showMainEventsCB.setEnabled(false);
				btnStopSim.setEnabled(false);
				btnStartSim.setEnabled(true); btnStartSim.setText("Pause"); btnStartSim.setIcon(pause);
				btnNextSim.setEnabled(false);
				break;
			case 2:
				// paused	
				enableMarketViewCB.setEnabled(true);
				showMainEventsCB.setEnabled(true);
				btnStopSim.setEnabled(true);
				btnStartSim.setEnabled(true); btnStartSim.setText("Continue"); btnStartSim.setIcon(forward);
				btnNextSim.setEnabled(true);
				break;
			case 3:
				// simulation completed
				enableMarketViewCB.setEnabled(false);
				showMainEventsCB.setEnabled(false);
				btnStopSim.setEnabled(false);
				btnStartSim.setEnabled(false);
				btnNextSim.setEnabled(false);
				break;
		}
	}
	
	public void promptEventNotification(String message){
		if(showNotifications){
			JOptionPane.showMessageDialog(this, message);
		}
	}
	
	@Override
	public void run(){
		// set the reference to the display to update the GUI while simulating
		simulator.setDisplay(this);
		try{
			simulator.simulate();
			simulator.computeEvaluation();
			
			// if we reached the end of the simulation (not because of the user choice), show a message
			if(!terminate){
				this.status = 3; this.update();
				this.promptReportWindow();
			}
			
		}catch(RemoteManagerUanavailableException e){
			JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
			this.dispose();		// close the HEMS interface
			// leave the current thread terminate
		}
	}
		
	private void promptReportWindow(){
		
		String[] cumulativeReward = {"Cumulative reward", simulator.reward+" "+Market.moneySymbol};
		String[] gridEnergySold = {"Money earned from energy fed into the Grid", simulator.earningsFromGrid+" "+Market.moneySymbol};
		String[] gridEnergyCost = {"Cost of energy purchased from the Grid", simulator.costForGridEnergy+" "+Market.moneySymbol};
		String[] localGeneratorsEnergyCost = {"Cost of energy purchased from local generators", simulator.costForLocalEnergy+" "+Market.moneySymbol};
			
		
		String[] flexibleGenerators = {"Flexible generators", ""+simulator.flexibleGenerators};
		String[] flexibleLoads = {"Flexible loads", ""+simulator.flexibleLoads};
		String[] flexibleLoadsOperatedAtLeastOnce = {"Flexible loads operated at least once", simulator.flexibleLoadsOperatedAtLeastOnce+""};
		String[] flexibleLoadsWithMoreThanAStateOperated = {"Flexible loads with more than a state operated", ""+simulator.flexibleLoadsWithMoreThanAStateOperated};
		
		String[] violatingInflexibleASK = {"Times an inflexible ASK was not allocated", ""+simulator.unallocatedInflexibleASK};
		String[] violatingInflexibleBID = {"Times an inflexible BID was not allocated", ""+simulator.unallocatedInflexibleBID};
			
		String[] marketViolating = {"Offers violating NYSE policy", simulator.forbiddenMarket+""};
		String[] relMarketViolating = {"AVG distance from spread improvement", simulator.relForbiddenMarket+""};
		String[] irrationalOffers = {"Offers violating price sensitivity and reservation price ", simulator.forbiddenLosses+""};
		String[] relIrrationalBIDOffers = {"AVG distance from price sensitivity", ""+simulator.relBIDLosses};
		String[] relIrrationalASKOffers = {"AVG distance from reservation price", ""+simulator.relASKLosses};
		
		String[] violatedHardDeadlines = {"Violated hard deadlines", simulator.timesViolatingHardDeadline+" times"};
		String[] unpoweredControllerTimes = {"Unpowered controller when needed to trade", simulator.unpoweredController+" times"};
		
		String[] nonsensePriceTimes = {"Times the price does not reflect energy demand/availability", simulator.priceDoesNotReflectNeeds+" times"};
		String[] relNonsensePrice = {"AVG distance from needed price", simulator.relDoesNotReflectNeeds+""};
			
		String[] startDelay = {"AVG Waited time to start devices", simulator.avgWaitedTimeToStartDevice + " secs" + " (" + simulator.flexibleLoadsOperatedAtLeastOnce + ")"}; 
		String[] relative_startDelay = {"AVG Relative waited time to start devices", simulator.avgRelativeWaitedTimeToStartDevice + " %" + " (" + simulator.flexibleLoadsOperatedAtLeastOnce + ")"};
		
		String[] stateStartDelay = {"AVG Waited time to start intermediate states", simulator.avgWaitedTimeToStartIntermediateStates + " secs" + " (" + simulator.flexibleLoadsWithMoreThanAStateOperated+ ")"};										
		String[] relative_stateStartDelay = {"AVG Relative waited time to start intermediate states", simulator.avgRelativeWaitedTimeToStartIntermediateStates + " %" + "(" + simulator.flexibleLoadsWithMoreThanAStateOperated + ")"};
			
		String[] interruptions = {"AVG state-interruption time", simulator.avgInterruptionTimeWithinAState + " secs" + " (" + simulator.flexibleLoadsOperatedAtLeastOnce + ")"};
		String[] relativeInterruptions = {"AVG Relative state-interruption time", simulator.avgRelativeInterruptionTimeWithinAState + " %" + " (" + simulator.flexibleLoadsOperatedAtLeastOnce + ")" };
			
		String[] fitness = {"Fitness", ""+simulator.getFitness()};
			
		// build the report structure
		ArrayList<String[]> rep = new ArrayList<String[]>();
			
		rep.add(fitness);
		
		rep.add(gridEnergySold);
		rep.add(cumulativeReward);
		rep.add(gridEnergyCost);
		rep.add(localGeneratorsEnergyCost);
		
		rep.add(flexibleGenerators);
		rep.add(flexibleLoads);
		rep.add(flexibleLoadsOperatedAtLeastOnce);
		rep.add(flexibleLoadsWithMoreThanAStateOperated);
		
		rep.add(violatingInflexibleASK);
		rep.add(violatingInflexibleBID);
		
		rep.add(marketViolating);
		rep.add(relMarketViolating);
		rep.add(irrationalOffers);
		rep.add(relIrrationalBIDOffers);
		rep.add(relIrrationalASKOffers);
		
		rep.add(violatedHardDeadlines);
		rep.add(unpoweredControllerTimes);
		
		rep.add(nonsensePriceTimes);
		rep.add(relNonsensePrice);
		
		rep.add(startDelay);
		rep.add(relative_startDelay);
		
		rep.add(stateStartDelay);
		rep.add(relative_stateStartDelay);
		
		rep.add(interruptions);
		rep.add(relativeInterruptions); 
		
		double[][] minMaxPowerValues = logger.getMinMaxValue(SimulationStatusPanel.TimeserieID.POWER.ordinal());
		double[] averagePowerValues = logger.getAverageValue(SimulationStatusPanel.TimeserieID.POWER.ordinal());
		
		// Power tab = { 0:traded demand, 1: demand from local production, 2: traded fed into grid, 3: grid availability, 4: local production, 5: overall availability }
		// production = 0, demand = 1; min = 0, max = 1;
		double powerProductionPeak = minMaxPowerValues[4][1];
		double powerDemandPeak = minMaxPowerValues[0][1];
		String[] demandPeak = {"Peak power demand", powerDemandPeak+" W"};
		String[] averageDemand = {"Average power demand", averagePowerValues[0]+" W"};
		String[] loadFactor = {"Load factor [AVG/Peak]", powerDemandPeak > 0 ? (((averagePowerValues[0]/powerDemandPeak)*100)+" %") : "No state operations available" };
		
		rep.add(demandPeak);
		rep.add(averageDemand);
		rep.add(loadFactor);
		
		String[] productionPeak = {"Peak power production", powerProductionPeak+" W"};
		String[] averageProduction = {"Average power production", averagePowerValues[4]+" W"};
		
		rep.add(productionPeak);
		rep.add(averageProduction);
		
		report = new ReportFrame(rep);
		report.setVisible(true);
	}	
	
	// ----------------- Called by the simulator --------------------
	public void updateProgress(int progress, String message){
		this.progress.setValue(progress);
		this.progress.setString(message);
	}
	
	public void updateGridTopology(ArrayList<Agent> prosumers, ArrayList<GridAgent> gridConnections, ArrayList<Transaction> runningTransactions){
		this.gridStatus.updateGraph(prosumers, gridConnections, runningTransactions);
	}
	
	public void updateSimulationStatus(TimeInstant ti){
		simulationStatus.update(ti);
	}
	
	public void updateTradingWillingness(Calendar currentTime, HashMap<String, TraderWillingness> willingness){
		simulationStatus.updateWillingnessToTrade(currentTime, willingness);
		simulationStatus.updatePriceSensitivity(currentTime, willingness);
	}
	
	public void updateMarketQuality(MarketEval allocationStats){
		simulationStatus.updateMarketQuality(allocationStats);
	}
	// ----------------- -------------------- --------------------
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("Start")){
			// the simulation is started in pause mode to allow step-by-step advances
			simulator.pause();
			this.status = 2;
			this.update();	
			
			(new Thread(this)).start();			
			
		}else if(e.getActionCommand().equals("Pause")){
			this.status = 2;
			this.update();
			simulator.pause();
			
		}else if(e.getActionCommand().equals("Continue")){
			this.status = 1;
			this.update();
			simulator.unpause();
			
		}else if(e.getActionCommand().equals("Next")){
			simulator.next();
			
		}else if(e.getActionCommand().equals("Stop")){
			this.status = 0;
			this.update();
			simulator.stop();
			terminate = true;
			// terminate the jframe without exiting the main frevo app
			this.dispose();
		}
	}

	@Override
	public void windowActivated(WindowEvent arg0) {}

	@Override
	public void windowClosed(WindowEvent arg0) {
		// Stop simulation thread
		simulator.stop();
		// Destroy the market view if it exists
		// so as to avoid any related problem
		marketView.dispose();
		if(report != null){
			report.dispose();
		}
	}

	@Override
	public void windowClosing(WindowEvent arg0) {}

	@Override
	public void windowDeactivated(WindowEvent arg0) {}

	@Override
	public void windowDeiconified(WindowEvent arg0) {}

	@Override
	public void windowIconified(WindowEvent arg0) {}

	@Override
	public void windowOpened(WindowEvent arg0) {}

	@Override
	public void itemStateChanged(ItemEvent e) {
		if(e.getSource() == enableMarketViewCB){
			if (e.getStateChange() == ItemEvent.SELECTED) {
				marketView.setVisible(true);
				marketView.setStatus(true);
				// by enabling the market view the simulation thread will block on each iteration to show the current market view		 
		    } else {
		    	marketView.setVisible(false);
		    	marketView.setStatus(false);
		    	// by disabling the market view the simulation thread will not block anymore to show the current market view
		    }
		}else if(e.getSource() == showMainEventsCB){
			// enable notification upon occurrence of main events in the simulator
			if (e.getStateChange() == ItemEvent.SELECTED) {
				showNotifications = true;
			}else{
				showNotifications = false;
			}
		}
	}
}