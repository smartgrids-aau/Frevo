package hems.display.report;

import hems.devices.Agent;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class DiscomfortTab extends JPanel implements ItemListener{

	private JPanel cards;
	
	public DiscomfortTab(ArrayList<Agent> loads){
		
        JPanel comboBoxPane = new JPanel();
        
        String comboBoxItems[] = new String[loads.size()];
        // Get all names of the loads to create the containing combo box
        for(int i =0; i < loads.size(); i++){
        	comboBoxItems[i] = loads.get(i).getName();
        	
        }
        
        JComboBox cb = new JComboBox(comboBoxItems);
        cb.setEditable(false);
        cb.addItemListener(this);
        comboBoxPane.add(cb);
		
		// create the card panel
		cards = new JPanel(new CardLayout());
		
		// add a card per each device available
		for(int i = 0; i < loads.size(); i++){
			DiscomfortTable p = new DiscomfortTable();
			p.setName(loads.get(i).getName());
			
			cards.add(p, loads.get(i).getName());
			
			// add reference from the load to the respective discomfortTable
			loads.get(i).setTableReference(p);
		}
        
		this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
        this.add(comboBoxPane, BorderLayout.PAGE_START);
        this.add(cards, BorderLayout.CENTER);
	}
	
	@Override
	public void itemStateChanged(ItemEvent evt) {
        CardLayout cl = (CardLayout)(cards.getLayout());
        cl.show(cards, (String) evt.getItem());
    }
	
	public JPanel getVisibleCard(){
		 JPanel card = null;
		 
		 for(Component comp : cards.getComponents() ){
			 if(comp.isVisible()) {
				 card = (JPanel) comp;
			 }
		 }
		 return card;
	}
	
	private static void createAndShowGUI() {
        //Create and set up the window.
        JFrame frame = new JFrame("CardLayoutDemo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         
        //Create and set up the content pane.
        DiscomfortTab demo = new DiscomfortTab(new ArrayList<Agent>());
        frame.add(demo);
         
        //Display the window.
        frame.pack();
        frame.setVisible(true);
    }
	
	public static void main(String[] args) { 
         
        //Schedule a job for the event dispatch thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            @Override
			public void run() {
                createAndShowGUI();
            }
        });
    }

}
