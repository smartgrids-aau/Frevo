package hems.market.priceModel.timeseries;

import java.util.Calendar;

import hems.market.priceModel.PriceModel;

public class TimeseriePriceModel implements PriceModel{

	private Timeserie<Double> priceModel;
	
	/**
	 * Creates a price model given an external time serie
	 * @param priceModel
	 */
	public TimeseriePriceModel(Timeserie<Double> priceModel){
		this.priceModel = priceModel;
	}
	
	/**
	 * Creates a price model as a time serie
	 * @param beginning
	 */
	public TimeseriePriceModel(long beginning){
		priceModel = new Timeserie<Double>(beginning);
	}
	
	/**
	 * Adds an entry to the timeserie
	 * @param price
	 * @param duration
	 */
	public void addEntry(double price, long duration){
		priceModel.addEntry(price, duration);
	}
	
	@Override
	public double getPrice(Calendar time) {		
		//return priceModel.getValue(time.getTimeInMillis() / 1000);
		return priceModel.getValueStartingFromLastVisited(time.getTimeInMillis() / 1000);
	}

}
