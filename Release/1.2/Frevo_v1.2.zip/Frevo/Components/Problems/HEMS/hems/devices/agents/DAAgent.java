package hems.devices.agents;

import hems.Market;
import hems.devices.Agent;
import hems.devices.TraderWillingness;
import hems.devices.generators.GenerationModel;
import hems.devices.generators.weather.Weather;
import hems.devices.loads.NotAvailableForTradeException;
import hems.devices.loads.OperationModel;
import hems.market.IllegalOfferException;
import hems.market.MarketStatus;
import hems.market.Offer;

import java.util.ArrayList;
import java.util.Calendar;

public class DAAgent extends Agent{
	
	protected ArrayList<Double> nyseViolatingPrice;
	protected ArrayList<Double> needsViolatingPrice;
	
	public DAAgent(String name, double credit, OperationModel operationModel,
			GenerationModel generationModel) {
		super(name, credit, operationModel, generationModel);
		
		this.needsViolatingPrice = new ArrayList<Double>();
		this.nyseViolatingPrice = new ArrayList<Double>();
	}
	
	public DAAgent clone(){
		// build new device with same properties, but leaving out all performance measures
		DAAgent a = new DAAgent(this.name, this.credit, this.operationModel.clone(), this.generationModel.clone());
		a.idlePowerDemand = this.idlePowerDemand;
		
		return a;
	}
	
	/**
	 * Returns an offer given the current idle demand and local generation available to the device
	 * @param currentTime
	 * @param allocationTime
	 * @param weather
	 * @param marketStatus
	 * @param positionBIDOrderbook
	 * @param alreadyAllocatedIdlePower
	 * @return
	 * @throws IllegalOfferException
	 * @throws NotAvailableForTradeException
	 */
	public Offer getIdleDemandOffer(Calendar currentTime, Calendar allocationTime, Weather weather,
									MarketStatus marketStatus,
									double positionBIDOrderbook, double alreadyAllocatedIdlePower) 
											throws IllegalOfferException, NotAvailableForTradeException{
		Offer offer = null;
		
		// compute the demand for idle power
		int totalIdleDemand = getIdlePowerDemand(currentTime, allocationTime, weather);
		// do we still need to pursue idle demand?
		boolean necessity = totalIdleDemand > 0 &&				// there is idle demand 
							alreadyAllocatedIdlePower < 1.0;	// the idle demand was not yet fully allocated (< 100%)
		
		// -------
		TraderWillingness tw = new TraderWillingness(necessity ? 1.0 : 0.0,
													1.0,				// offerImportance,
													totalIdleDemand, 	// totalIdleDemand is idle demand
													totalIdleDemand, 	// amountToBuy is idle demand
													0,				 	// delayToleranceLeft is 0 secs
													0.0,			 	// relativeDelayToleranceLeft is 0%
													Market.limitPrice,	// priceSensitivity is limit price
													0,					// amountToSell is null
													Market.limitPrice);	// reservationPrice)
		
		double output = makePrice(currentTime, allocationTime, marketStatus, weather, 
									tw,
									
									positionBIDOrderbook, 
									alreadyAllocatedIdlePower, 
									
									1.0,  // best position in the ask orderbook
									1.0); // all ASK power allocated
		
		// ---------
		
		// the output of the ANN is 0-1 so we need to scale it to [-1, +1]
		double price = 2.0 * Market.limitPrice * output - Market.limitPrice;	// e.g. when [-1, +1] we have 2*1 * n - 1
		
		// ------ Validate offer
		if(price > Market.marketPriceThreshold){
			// BID
			if(necessity){
				// approve the offer, it's an IDLE-BID as needed
				offer = new Offer(totalIdleDemand, price, true, this, currentTime);
				// we use the initial amount, as in case it was already partially fulfilled, the leftover will be used to mark the new offer anyways
			}else{
				// BID rather than a NO-OP
				this.punishPriceNotReflectingNeeds(price, 1); this.punishOfferNotReflectingNeeds();
				// the agent should learn right away to provide a null price when he does not need idle power,
				throw new IllegalOfferException(" IDLE-BID rather than a NOOP");
			}
		}else if(price <  - Market.marketPriceThreshold){
			price = Math.abs(price);
			// ASK
			if(necessity){
				// ASK rather than a needed BID
				this.punishPriceNotReflectingNeeds(price, 2); this.punishOfferNotReflectingNeeds(); this.punishOfferNotReflectingNeeds();
				throw new IllegalOfferException(" IDLE-ASK rather than an IDLE-BID");
			}else{
				// ASK rather than a NO-OP
				this.punishPriceNotReflectingNeeds(price, 1); this.punishOfferNotReflectingNeeds();
				throw new IllegalOfferException(" IDLE-ASK rather than a NOOP");
			}
		}else{
			price = Math.abs(price);
			// NOOP
			if(necessity){
				// NO-OP rather than BID
				this.punishPriceNotReflectingNeeds(price, 1); this.punishOfferNotReflectingNeeds();
				throw new IllegalOfferException(" NOOP rather than an IDLE-BID");
			}else{
				// approve the noop offer
				throw new NotAvailableForTradeException(
						totalIdleDemand > 0 ? "All idle demand was allocated for the agent" :
							this.idlePowerDemand > 0 ?	("the local generation available ("+this.generationModel.getCurrentProduction(currentTime, weather)+"W) can cover the idle demand of ("+this.idlePowerDemand+"W)") : 
								"No idle demand"
				);
			}
		}			
		return offer;
	}
	
	/**
	 * Queries the controller and returns its offer
	 * @param simulationTime
	 * @param allocationTime
	 * @param weather
	 * @param tradingTendency
	 * @param amount
	 * @param delayToleranceLeft
	 * @param relativeDelayToleranceLeft
	 * @param marketStatus
	 * @param positionBIDOrderbook
	 * @param alreadyAllocatedBID
	 * @param positionASKOrderbook
	 * @param alreadyAllocatedASK
	 * @return
	 * @throws NotAvailableForTradeException
	 * @throws IllegalOfferException
	 */
	public Offer queryController(Calendar simulationTime, Calendar allocationTime, Weather weather,
								TraderWillingness willingness,
								MarketStatus marketStatus,
								double positionBIDOrderbook, double alreadyAllocatedBID,
								double positionASKOrderbook, double alreadyAllocatedASK)
										throws NotAvailableForTradeException, IllegalOfferException {
		Offer offer = null;			
		
		// ***  ask the neural controller to make a price ***
		double output = makePrice(simulationTime, allocationTime, 
								marketStatus, weather,
								willingness,
								positionBIDOrderbook, alreadyAllocatedBID, positionASKOrderbook, alreadyAllocatedASK);
			
		// the output of the ANN is 0-1 so we need to scale it to [-1, +1]
		double price = 2.0 * Market.limitPrice * output - Market.limitPrice;	// e.g. when [-1, +1] we have 2*1 * n - 1
		
		// Validate the offer based on the agent's willingness
		if(price > Market.marketPriceThreshold){ // 0 + threshold
			// *** BID
			// Validate offer according to the actual needs of the agent
			if(willingness.tradingTendency < 0.0){				
				// the device made a BID while it needs an ASK, interval distance is 2
				this.punishPriceNotReflectingNeeds(price, 2); 
				this.punishOfferNotReflectingNeeds(); this.punishOfferNotReflectingNeeds();
			
				throw new IllegalOfferException(this.name+": BID rather than ASK");			// throw an exception to prevent the propagation of the wrong offer
			}else if(willingness.tradingTendency == 0.0){
				// the device does not need to operate, interval distance is 1
				this.punishPriceNotReflectingNeeds(price, 1);
				this.punishOfferNotReflectingNeeds();
				
				throw new IllegalOfferException(this.name+": BID rather than NOOP");
				// TODO: this does not always mean it can't (e.g. non-user driven devices)
			}else{
				// approve the offer, it's a BID as needed
				offer = new Offer(willingness.amountToBuy, price, true, this, simulationTime, willingness.delayToleranceLeft);
			}
				
			// if the offer was approved we need to check if the price violates the agent's sensitivity
			if(price > this.operationModel.getPriceSensitivity(simulationTime)){ 
				this.addInsensitivePriceOffer(); 
			}
			this.trackPriceOffer(price, this.operationModel.getPriceSensitivity(simulationTime), true);
		}else if(price <  - Market.marketPriceThreshold){ // 0 - threshold
			// *** ASK
			price = Math.abs(price); // make the price positive
			// Validate price according to the actual needs of the aqent		
			if(willingness.tradingTendency > 0.0){
				// the device made an ASK offer while it does not need to sell energy, it does not have any
				this.punishPriceNotReflectingNeeds(price, 2);
				this.punishOfferNotReflectingNeeds(); this.punishOfferNotReflectingNeeds();
				// throw an exception to prevent the propagation of the wrong offer
				throw new IllegalOfferException(this.name+": ASK rather than BID");
			}else if(willingness.tradingTendency == 0.0){
				// the device does not have anything to sell
				this.punishPriceNotReflectingNeeds(price, 1); this.punishOfferNotReflectingNeeds();
				throw new IllegalOfferException(this.name+": ASK rather than NOOP");
			}else{
				// approve the offer, it's an ASK as needed
				offer = new Offer(willingness.amountToSell, price, false, this, simulationTime);
			}
			// if the price respected the needs, check if the generator is asking less than the cost
			if(price < this.generationModel.getReservationPrice(simulationTime)){ this.addInsensitivePriceOffer(); }
			// keep track of all offers to compute the penalty from insensitive ones, while keeping also good ones into account
			this.trackPriceOffer(price, this.generationModel.getReservationPrice(simulationTime), false);
		}else{	// NOOP, the trader does not want to trade
			price = Math.abs(price);
			// we have to make sure that the agent did actually not want to trade by checking its necessity to buy/sell
			if(willingness.tradingTendency == 0.0){
				throw new NotAvailableForTradeException("No demand/production to trade");
			}else if(willingness.tradingTendency < 0.0){
				// when energy is available it should be sold, but not necessarily
				if(this.generationModel.isAFlexibleService()){
					// flexible generator (e.g., battery), we respect the choice
					throw new IllegalOfferException("NOOP rather than flexible-ASK");
				}else{
					this.punishPriceNotReflectingNeeds(price, 1); this.punishOfferNotReflectingNeeds();
					throw new IllegalOfferException(this.name+": NOOP rather than inflexible-ASK");
				}
			}else{
				// the agent WOULD like to operate
				// the NULL price (or anyway a low price) is the only way agents have to OPT out of the auction
				// so as to postpone a needed trade to the future -> we should not always associate a penalty to this
				if(this.operationModel.isAFlexibleService()){
					throw new IllegalOfferException(this.name	+": NOOP rather than flexible-BID");
				}else{
					// an inflexible load should always pursue the operation
					this.punishPriceNotReflectingNeeds(price, 1);	this.punishOfferNotReflectingNeeds();
					throw new IllegalOfferException(this.name	+" NOOP rather than inflexible-BID");
				}
			}
		}
		
		// we have correctly formulated an offer which has to be accepted to operate
		unacceptedOffer = offer;
		return offer;
	}
	
	protected double makePrice(Calendar simulationTime, Calendar allocationTime, MarketStatus marketStatus, Weather weather, 
			TraderWillingness willingness,
			double positionBIDOrderbook, double alreadyAllocatedBID, double positionASKOrderbook, double alreadyAllocatedASK){

		double offerPrice = 0.0;

		ArrayList<Float> inputValues = new ArrayList<Float>();
		ArrayList<Float> outputValues = new ArrayList<Float>();
			
		// -------------- set the inputs for the Neural network --------------
		// SELLER'S inputs
		inputValues.add((float) (willingness.reservationPrice / Market.limitPrice));
		inputValues.add((float) (marketStatus.sellQuote / Market.limitPrice));
		inputValues.add((float) positionASKOrderbook);
		inputValues.add((float) alreadyAllocatedASK);
		
		// COMMON inputs		 
		double dayHour = simulationTime.get(Calendar.HOUR_OF_DAY) / 23;								// Midnight is 0.0, 11 pm is 1.0
		double month = simulationTime.get(Calendar.MONTH) / 11;										// January is 0.0, December is 1.0
		double weekday = simulationTime.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY ? 0.0 :		// Sunday
							simulationTime.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY ? 1.0 :	// Saturday
							0.5;
		
		inputValues.add((float) dayHour);
		inputValues.add((float) month);
		inputValues.add((float) weekday);
		
		inputValues.add((float) willingness.offerImportance);	// is the offer flexible? inflexible/idle = 1.0, flexible sell = 0.0, flexible buy = 0.0 (1st state), 0.5 (intermediate)
		inputValues.add((float) willingness.tradingTendency);	// when 1.0 BUY, when -1.0 SELL, when 0.0 NOOP
			
		// BUYER'S inputs
		inputValues.add((float) willingness.relativeDelayToleranceLeft);
		inputValues.add((float) (willingness.priceSensitivity/ Market.limitPrice));
		inputValues.add((float) (marketStatus.buyQuote / Market.limitPrice));
		inputValues.add((float) positionBIDOrderbook);
		inputValues.add((float) alreadyAllocatedBID);
			
		// OUTPUT
		outputValues = this.brain.getOutput(inputValues);
			
		offerPrice = outputValues.get(0);

		return offerPrice;
	}
	
	@Override
	public double computeFitness(double reward, 
								double gridEnergySold, double gridEnergyCosts, double localEnergyCosts,
								double relDevStart, double relStateStart, double relInterruption, 
								double unallocatedInflexibleBID, double unallocatedInflexibleASK,
								
								double violatingDeadline,
								double violatingMarket, double relForbiddenMarket,
								double violatingSensitivity, double relBIDLosses, double relASKLosses,
								double unpoweredController,
								double violatingNeeds, double relDoesNotReflectNeeds
								){
		
		// weight the importance of the completion of operations for the devices
		reward *= Market.rewardFactor;
		
		// The cost is what we are trying to minimize and it is given by:
		double cost = 
		Market.penaltyGridUse * gridEnergyCosts +								// Cost for the energy traded with the grid (both feed-in and purchased from there)
		// what happens when the grid price is low for over availability of energy and we have no PV? shouldn't we simply prefer that?
		
		localEnergyCosts + 														// Cost for the energy spent locally
		
		// ------------ Penalties on relative values
		(relDevStart > 0.0 ? Market.penaltyDelayedDeviceStart : Market.rewardDeviceStart)			// Cost for delaying the beginning of a device 
										* relDevStart +						
		
		(relStateStart > 0.0 ? Market.penaltyDelayedStateStart : Market.rewardStateStart)			// Cost for delaying the beginning of an intermediate state
										* relStateStart +					
		
		//(relInterruption > 0.0 ? Market.penaltyStateInterruption : 100)	* relInterruption +		// Cost for interrupting an atomic state
		Market.penaltyStateInterruption * relInterruption +
		
		// ------------ Penalties on number of misbehaviors
		Market.penaltyInflexibleOffers * unallocatedInflexibleBID +
		Market.penaltyInflexibleOffers * unallocatedInflexibleASK +
		
		Market.penaltyUnstarted * violatingDeadline + 							// Cost for not allocating at all a device (within a hard deadline)
		Market.penaltyViolatingMarket * relForbiddenMarket * violatingMarket +
		//Market.penaltyViolatingMarket * violatingMarket +						// Cost for making an offer which does not fulfill the market rules
		
		Market.penaltyViolatingSensitivity * relBIDLosses +
		Market.penaltyViolatingSensitivity * relASKLosses +
		//Market.penaltyViolatingSensitivity * violatingSensitivity +			// Cost for trading with losses
		
		Market.penaltyUnpoweredController * unpoweredController +				// Cost for interrupting the service when needed
		
		Market.penaltyUnnecessaryTrading 
									* relDoesNotReflectNeeds				// average distance from actually needed price 
									* violatingNeeds;						// times a price not reflecting the trading tendency was produced
		//Market.penaltyUnnecessaryTrading * violatingNeeds;
		
		return reward + 
		(Market.penaltyGridUse * gridEnergySold) 
		- cost;
	}
	
	// ----------------------------------- Methods to punish the agent for trading energy that is not necessary/available
	public void punishPriceNotReflectingNeeds(double offerPrice, int intervalDistanceFromNeededOffer){
		double distance = 0.0;
		
		// ------------- ASK --------- | --- NOOP --- | ------------ BID -------------> p
		// all price come already positive so it is like | --- NOOP --- | ---------- BID/ASK ----------> p	
		if(intervalDistanceFromNeededOffer == 1){
			distance = Math.abs(offerPrice - Market.marketPriceThreshold);			
		}else if(intervalDistanceFromNeededOffer == 2){
			distance = offerPrice + Market.marketPriceThreshold * 2;
		} // else distance = 0.0;
		
		//System.out.println(name+" offered "+offerPrice+" -> "+distance);
		this.needsViolatingPrice.add(distance);
	}	
	
	@Override
	public double getAverageDeviationFromNeeds() {
		double result = 0;
		for(int i = 0; i < this.needsViolatingPrice.size(); i++){
			result += this.needsViolatingPrice.get(i);
		}
		
		if(this.needsViolatingPrice.size() > 0) result /= (double) this.needsViolatingPrice.size();
		
		return result;
	}

	// ------------------------------------ Methods to punish the agent for making an offer violating the market policies
	public void trackMarketValidityOffer(double offerPrice, double bestOffer, boolean bid){
		double distance = 0.0;
		if(bid){
			distance = bestOffer - offerPrice;
		}else{
			distance = offerPrice - bestOffer;
		}
			
		this.nyseViolatingPrice.add( Math.abs(distance) );
	}

	@Override
	public double getAverageOfferMarketDeviation() {
		double result = 0;
		
		for(int i =0; i < this.nyseViolatingPrice.size(); i++){
			result += this.nyseViolatingPrice.get(i);
		}
			
		if(this.nyseViolatingPrice.size() > 0) result /= (double) this.nyseViolatingPrice.size();
		return result;
	}
}
