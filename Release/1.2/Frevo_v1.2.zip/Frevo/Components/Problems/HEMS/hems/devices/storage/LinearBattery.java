package hems.devices.storage;

public class LinearBattery extends Battery {

	/*
	 * Models the charge and discharge of a battery using a linear behavior function of time
	 */
	
	public LinearBattery(double nominalVoltage, double storageCapacity,
			double initialStateOfCharge, double chargingRate,
			double chargingEfficiency, double dischargingRate,
			double dischargingEfficiency) {
		super(nominalVoltage, storageCapacity, initialStateOfCharge, chargingRate,
				chargingEfficiency, dischargingRate, dischargingEfficiency);
		
	}
	
	public double charge(double current, double chargingResistance) throws HighBatteryCurrentException{
		if(current > this.storageCapacity * this.chargingRate)
			throw new HighBatteryCurrentException("Charging current is too high and might destroy the storage element");
		
		double increment = 0;
		
		// consider the charging efficiency to waste part of the charge
		increment = (current * this.chargingEfficiency) / getBatteryMaxCharge();
					
		// compute the percentage of increment for the state of charge
		this.stateOfCharge += increment;
		
		return increment;
	}
	
	public double discharge(double current, double dischargingResistance) throws HighBatteryCurrentException{
		if(current > this.storageCapacity * this.dischargingRate)
			throw new HighBatteryCurrentException("Discharging current is too high and might destroy the storage element");
		
		double decrement = 0;
		
		decrement = (current * this.dischargingEfficiency) / this.getBatteryMaxCharge();
		// compute the percentage of decrement for the state of charge
		this.stateOfCharge -= decrement;
		
		return decrement;
	}

}
