package hems.devices.mainGrid.capabilityModel;

import hems.devices.generators.capabilityModel.timebased.TimeBasedTradeableAmount;

import java.util.Calendar;
import java.util.List;

public class IntervalBasedCapability implements CapabilityModel {

	List<TimeBasedTradeableAmount> capability;
	
	public IntervalBasedCapability(List<TimeBasedTradeableAmount> capability){
		this.capability = capability;
	}
	
	@Override
	public int getCapability(Calendar time) {
		int amount = 0;
		for(TimeBasedTradeableAmount interval : capability){
			if(interval.coversThisTime(time)){
				return interval.getAmount();
			}
		}
		
		return amount;
	}

}
