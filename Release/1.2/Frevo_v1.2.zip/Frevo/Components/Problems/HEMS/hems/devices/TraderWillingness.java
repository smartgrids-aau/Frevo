package hems.devices;

public class TraderWillingness {
	
	public double tradingTendency;
	public double offerImportance;
	public int idlePowerDemand;
	
	public int amountToBuy;
	public int delayToleranceLeft;
	public double relativeDelayToleranceLeft;
	public double priceSensitivity;
	
	public int amountToSell;
	public double reservationPrice;
		

	public TraderWillingness(double tradingTendency, double offerImportance,
							int idlePowerDemand,
							int amountToBuy, int delayToleranceLeft, double relativeDelayToleranceLeft, double priceSensitivity,
							int amountToSell, double reservationPrice){
		this.tradingTendency = tradingTendency;
		this.offerImportance = offerImportance;
		this.idlePowerDemand = idlePowerDemand;
		this.amountToBuy = amountToBuy;
		this.delayToleranceLeft = delayToleranceLeft;
		this.relativeDelayToleranceLeft = relativeDelayToleranceLeft;
		this.priceSensitivity = priceSensitivity;
		
		this.amountToSell = amountToSell;
		this.reservationPrice = reservationPrice;
	}
}
