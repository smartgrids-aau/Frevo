package hems.devices.loads;

import java.util.ArrayList;
import java.util.Calendar;

public class OperationStats {
	
	private ArrayList<StateOperation> states;
	private StateOperation current;
	
	public OperationStats(){
		states = new ArrayList<StateOperation>();
	}
	
	public void addStateOperation(long firstOfferTime, 
									int deviceState,
									int startDelay,
									long startTime){
		this.current = new StateOperation(firstOfferTime, deviceState, startDelay, startTime);
		states.add(current);
	}
	
	public void addInterruption(int seconds){
		current.addInterruption(seconds);
	}
	
	public void concludeStateOperation(long lastSuccessfulRunTime, double reward){
		if(current != null){
			current.concludeStateOperation(lastSuccessfulRunTime, reward);
		}
	}
	
	public ArrayList<StateOperation> getAllStatesStats(){
		return states;
	}
	
	/**
	 * Returns the average delay over all intermediate states
	 * @return
	 */
	public double getAvgStartingDelayIntermediateStates(){
		double avgStartingDelay = 0.0;
		
		// make sure the device has at least two states
		if(states.size() > 1){
			
			// start from the second state
			for(int i = 1; i < states.size(); i++){
				avgStartingDelay += states.get(i).startDelay;
			}
			avgStartingDelay /= (states.size() - 1); // do not include the first state in the count
		}
		
		return avgStartingDelay;
	}

	
	/**
	 * Get average interruption delay for all states of the operation that were actually concluded
	 * @return
	 */
	public double getAvgInterruptionDelay(){
		double avgInterruptionDelay = 0.0;
		
		// compute the average over all device states that were completed
		int i = 0; boolean goAhead = true;
		for( ; goAhead && i < states.size(); ){
			
			// get the current state
			StateOperation o = states.get(i);
			
			if(o.concluded){
				avgInterruptionDelay += o.getAvgInterruptionTime();
				i++;
			}else{
				// get outta here
				goAhead = false;
			}
		}
		
		// avoid division by 0 and 1 (nonsense)
		if(i > 0) avgInterruptionDelay /= i;
		
		return avgInterruptionDelay;
	}
	
	// TEST
	public static void main(String [] args){
		OperationStats stats = new OperationStats();
		
		Calendar time = Calendar.getInstance();
		stats.addStateOperation(time.getTimeInMillis(), 0, 0, time.getTimeInMillis());
		stats.addInterruption(2);
		
		System.out.println(stats.current.deviceState+": "+stats.current.interruptions);
		
		stats.addStateOperation(time.getTimeInMillis(), 1, 0, time.getTimeInMillis());
		
		System.out.println(stats.current.deviceState+": "+stats.current.interruptions);
		
	}

	
}
