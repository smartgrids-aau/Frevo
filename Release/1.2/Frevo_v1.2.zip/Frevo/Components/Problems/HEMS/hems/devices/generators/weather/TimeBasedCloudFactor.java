package hems.devices.generators.weather;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class TimeBasedCloudFactor{
	private int start;
	private int end;
	private double cloudFactor;
	
	public TimeBasedCloudFactor(int startYearDay,
								int startHour,
								int startMins,
								int startSecs,
								
								double cloudFactor,
								
								int endYearDay,
								int endHour,
								int endMins,
								int endSecs){
		this.start = startSecs +
					startMins * 60 +
					startHour * 60 * 60 +
					startYearDay * 24 * 60 * 60;
		
		this.end = endSecs +
					endMins * 60 +
					endHour * 60 * 60 +
					endYearDay * 24 * 60 * 60;
		
		this.cloudFactor = cloudFactor;
	}
	
	public boolean coversThisTime(Calendar time){
		int current = time.get(Calendar.SECOND) +						//
						60 * time.get(Calendar.MINUTE) +				// 0-59
						60 * 60 * time.get(Calendar.HOUR_OF_DAY) +		// 0-23
						60* 60 * 24 * time.get(Calendar.DAY_OF_YEAR);	// first day is 1
		
		int yearLength = ((GregorianCalendar) time).isLeapYear(time.get(Calendar.YEAR)) ? 366 : 365 *
						24 * 60	// day in minutes 
						* 60;	// seconds in a minute
		
		return ((current - start + yearLength) % yearLength) < ((end - start + yearLength) % yearLength);
	}
	
	public double getCloudFactor(){
		return cloudFactor;
	}
}