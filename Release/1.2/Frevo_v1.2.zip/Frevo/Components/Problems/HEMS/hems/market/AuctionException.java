package hems.market;

public class AuctionException extends Exception {

	public AuctionException(String message) {
		super(message);
	}

	public AuctionException() {
		super();
	}

}
