package hems.devices.modelManager;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ModelManager implements Runnable{
	
	private static ModelManager manager;
	
	private static Socket socket;
	private static ObjectInputStream input;
    private static ObjectOutputStream output;
    private static boolean connState;
    
    private static ArrayList<String> availableFormats;
    private static boolean loadedModel;
    private static double startingProbability;
    
    private static Lock requestsLock;
    private static Semaphore responseSemaphore;
    
	public ModelManager(String host, int port) throws UnknownHostException, IOException{
		socket = new Socket(host, port);
		System.out.println("Connection to "+host+":"+port+" successful!");
        output = new ObjectOutputStream(socket.getOutputStream());
        input = new ObjectInputStream(socket.getInputStream());
        connState = true;
        
        requestsLock = new ReentrantLock();
        responseSemaphore = new Semaphore(0);
        
        availableFormats = null;
        loadedModel = false;
        startingProbability = 0.0;
	}
	
	public static ModelManager getOrCreateInstance(String host, int port) throws UnknownHostException, IOException{
		if(manager == null ||	// instantiated at the first simulation (by the parser)
				!connState){	// instantiated at the n simulation, after it previously crashed when the server got down
			manager = new ModelManager(host, port);
		}
		// start the model manager if everything worked fine
		new Thread(manager).start(); 
		return manager;
	}
	
	
	/*
	 * Do we need to terminate the socket or closing the 
	 * application is enough as the garbage collector will do the rest?
	public void disconnect(){
		try{
			socket.close();
		}catch(IOException e){}
		connState = false;
	}
	*/
	
	public void run(){
		Message m;
        try {
            while(true){
                // the stub is blocked on the socket waiting for message from server
                m = (Message) input.readObject();
                switch(m.getName()){
	            	case "ListFormats":
	            		availableFormats = new ArrayList<String>();
	            		for(Object f : m.getArgs() ) availableFormats.add((String) f);
	            		responseSemaphore.release();
	            		break;
	            	case "LoadModel":
	            		loadedModel = (boolean) m.getArgs().get(0);
	            		responseSemaphore.release();
	            		break;
	            	case "GetStartingProbability":
	            		startingProbability = (double) m.getArgs().get(0);
	            		responseSemaphore.release();
	            		break;
                }
            }
        } catch (IOException ex) {
            // someone close socket while I was waiting for messages
           connState = false;
        } catch (ClassNotFoundException ex) {
        	// Protocol error, impossible to deserialize the message content

        }

	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static double getStartingProbability(String model, Calendar time, int operationsInCurrentInterval) throws RemoteManagerUanavailableException{
		double result = 0.0;
		requestsLock.lock();
		if(connState){		
			try {
				ArrayList payload = new ArrayList();
				payload.add(model);
				payload.add(time);
				payload.add(operationsInCurrentInterval);
	
				output.writeObject(new Message("GetStartingProbability", payload));
				
				responseSemaphore.acquire();
				responseSemaphore.drainPermits();
				
				result = startingProbability;
			} catch (IOException e) {
				connState = false;
			} catch (InterruptedException e) {
				// the thread was terminated while waiting for a response to come
				connState = false;
			}
		}else{
			throw new RemoteManagerUanavailableException("Impossible to continue the simulation: remote server not reachable!\n"+
														"Please restart the simulation after making sure the connection is correctly established.");
		}
		requestsLock.unlock();
		return result;
	}
	
	public static boolean loadFormat(String position, String format){
		boolean result = false;
		requestsLock.lock();
		if(connState){
			try{
				ArrayList<String> payload = new ArrayList<String>();
				payload.add(position);
				payload.add(format);
				output.writeObject(new Message("LoadModel", payload));
				responseSemaphore.acquire();
				responseSemaphore.drainPermits();				
				
				result = loadedModel;
			}catch(IOException e){
				connState = false;
			} catch (InterruptedException e) {
				// the thread was terminated while waiting for a response to come
				connState = false;
			}
		}
		requestsLock.unlock();
		return result;
	}
	
	public static ArrayList<String> listAvailableFormats(){
		requestsLock.lock();
		// request list of available formats from the server
		if(availableFormats == null && connState){
			try {
				output.writeObject(new Message("ListFormats", null));
				responseSemaphore.acquire();
				responseSemaphore.drainPermits();
			} catch (IOException e) {
				connState = false;
			} catch (InterruptedException e) {
				// the thread was terminated while waiting for a response to come
				connState = false;
			}
		}
		requestsLock.unlock();
		return availableFormats;
	}

}
