package hems.display.report;

import hems.display.report.Report.ReportTable;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.filechooser.FileNameExtensionFilter;

public class ReportFrame extends JFrame {
	
	private JButton btnSaveReport;
	private Report report;
	
	public ReportFrame(ArrayList<String[]> values){
		setTitle("HEMS - Simulation report"); 
		setResizable(true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
		//this.setPreferredSize(new Dimension(600, 400));
		
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.PAGE_AXIS));
		this.add(panel);
		
		report = new Report();
		report.updateTable(values);
		
		btnSaveReport = new JButton("Save as CSV");
		btnSaveReport.setAlignmentX(CENTER_ALIGNMENT);
		btnSaveReport.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e){
				try{
					saveCSV();
				}catch(Exception ex){
					JOptionPane.showMessageDialog(rootPane, ex.getMessage(), "Inane warning", JOptionPane.WARNING_MESSAGE);
					//.showMessageDialog(this, ex.getMessage(), "Inane warning", JOptionPane.WARNING_MESSAGE);
				}
			}
		});	
		
		panel.add(btnSaveReport);
		panel.add(report);
		
		pack();
	}
	
	public void saveCSV() throws IOException{
		
		JFileChooser chooser = new JFileChooser();
		chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
		chooser.setAcceptAllFileFilterUsed(false);
		chooser.setFileFilter(new FileNameExtensionFilter("CSV File (.csv)", ".csv"));
		chooser.setSelectedFile(new File(System.getProperty("user.home")+"/report.csv"));
		
		int returnVal = chooser.showSaveDialog(this);
		if(returnVal == JFileChooser.APPROVE_OPTION){
			String filepath = chooser.getSelectedFile().getPath();
			FileWriter writer = new FileWriter(filepath);
			
			ReportTable reportTable = (ReportTable) this.report.getTable().getModel();
			
			// print column names
			for(int c = 0; c < reportTable.getColumnCount(); c++){
				writer.append(""+reportTable.getColumnName(c));
				if(c < reportTable.getColumnCount() - 1) writer.append(",");
			} writer.append("\n");
			
			// print report
			for(int r = 0; r < reportTable.getRowCount(); r++){
				for(int c = 0; c < reportTable.getColumnCount(); c++){
					writer.append(""+reportTable.getValueAt(r, c));
					
					if(c < reportTable.getColumnCount() - 1) writer.append(",");
				}
				writer.append("\n");
			}
			
			writer.flush();
			writer.close();	
		}
		
	}
	
	public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
			public void run() {
            	
            	ArrayList<String[]> prova = new ArrayList<String[]>();
            	String[] p1 = {"Prova 1", "Prova 1"};
            	prova.add(p1);
            	
            	String[] p2 = {"Prova 2", "Prova 2"};
            	prova.add(p2);
            	
            	ReportFrame report = new ReportFrame(prova);
            	report.setVisible(true);
            }
        });
    }

}
