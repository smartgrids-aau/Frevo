package hems.display.report;

import java.awt.GridLayout;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.table.AbstractTableModel;

public class Report extends JPanel {
	
	private JTable table;
	
	public Report(){
		super(new GridLayout(1,0));
		
		String[][] data = new String[0][0];
		
		AbstractTableModel model = new ReportTable(data);
	    table = new JTable(model);
	    //table.setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
        
	    table.setFillsViewportHeight(true);
        table.setEnabled(false);
        
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane);
	}	
	
	public JTable getTable(){
		return this.table;
	}
		
	public void updateTable(final ArrayList<String[]> values){
		
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				String[][] data = new String[values.size()][values.size() > 0 ? 2 : 0];
				
				int i=0;
				for(String[] entry : values){
					data[i][0] = entry[0];
					data[i][1] = entry[1];
					i++;
				}
				ReportTable wt = new ReportTable(data);
				table.setModel(wt);
				wt.fireTableDataChanged();
			}
	    });
		
	}
	
	class ReportTable extends AbstractTableModel {
		private String[] columnNames = {"Name", "Value"};
		private String[][] table = null;
		
		
		public ReportTable(String[][] table){
			this.table = table;
		}
		
		@Override
		public int getColumnCount() {
			return columnNames.length;
		}

		@Override
		public int getRowCount() {
			return table.length;
		}

		@Override
		public String getValueAt(int r, int c) {
			return table[r][c];
		}
		
		@Override
		public String getColumnName(int col) {
            return columnNames[col];
        }
		
		public void setName(String name, int r){
			table[r][0] = name;
		}
		
		public String[] getNames(){
			return columnNames;
		}
		
		@Override
		public Class getColumnClass(int col) {
            return getValueAt(0, col).getClass();
        }
	}
	
	 public static void main(String[] args) {
		 javax.swing.SwingUtilities.invokeLater(new Runnable() {
			 @Override
			public void run() {
				 JFrame frame = new JFrame("SimpleTableDemo");
				 frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

				 Report newContentPane = new Report();
				 newContentPane.setOpaque(true); //content panes must be opaque
				 frame.setContentPane(newContentPane);
				 frame.pack();
				 frame.setVisible(true);
			 } 
		 }); 
	 }
}