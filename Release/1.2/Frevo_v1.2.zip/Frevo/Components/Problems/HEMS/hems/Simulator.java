package hems;

import hems.devices.Agent;
import hems.devices.TraderWillingness;
import hems.devices.generators.weather.Weather;
import hems.devices.loads.StateBasedOperationModel;
import hems.devices.mainGrid.GridAgent;
import hems.devices.modelManager.RemoteManagerUanavailableException;
import hems.display.HEMSDisplay;
import hems.display.TimeInstant;
import hems.market.MarketEval;
import hems.market.Offer.OfferType;
import hems.market.Transaction;
import hems.solvers.Solver;
import hems.solvers.Solver.TradeResult;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Random;

public class Simulator {
	
	private SimpleDateFormat format = new SimpleDateFormat("yyyy MMM dd HH:mm:ss");
	private HEMSDisplay display;
	private PauseControl pc;
	private boolean terminate; 	// default = false
	private boolean next;
	
	private Calendar beginning;
	private Calendar currentTime;
	private int simulationDuration;
	
	private ArrayList<Agent> prosumers;
	private ArrayList<GridAgent> grids;
	private Weather weather;
	private Solver solver;
	private int auctionIterations;
	private Random randomGen;
	
	// -------------- Fitness operands ----------------------
	public double avgWaitedTimeToStartDevice = 0;				// average time waited before starting a device
	public double avgRelativeWaitedTimeToStartDevice = 0;
		
	public double avgWaitedTimeToStartIntermediateStates = 0;	// average time waited before starting an intermediate state
	public double avgRelativeWaitedTimeToStartIntermediateStates = 0;
		
	public double avgInterruptionTimeWithinAState = 0;			// average interruption delay
	public double avgRelativeInterruptionTimeWithinAState = 0;	
		
	public double costForGridEnergy = 0;				// power*t traded with grid agent
	public double costForLocalEnergy = 0;				// energy bought from PVs
	public double earningsFromGrid = 0.0;				// energy sold to grid
		
	public int timesViolatingHardDeadline = 0;		// power is not got within time window
	public int forbiddenMarket = 0;					// price < currentBestPrice
	public int forbiddenLosses = 0;					// price > sensitivity = LOSSES
	public int unpoweredController = 0;				// controller is not powered when needed
	public int priceDoesNotReflectNeeds = 0;		// price does not respect ANN input
	
	public double relForbiddenMarket = 0;
	public double relASKLosses = 0, relBIDLosses = 0;
	public double relDoesNotReflectNeeds = 0;
		
	public double reward = 0;
	public int flexibleLoads = 0;
	public int flexibleGenerators = 0;
	public int flexibleLoadsOperatedAtLeastOnce = 0;
	public int flexibleLoadsWithMoreThanAStateOperated = 0;
	
	public int unallocatedInflexibleASK = 0;
	public int unallocatedInflexibleBID = 0;
	// ------------------------------------------------------
	
	public Simulator(Calendar beginning, int simulationDuration,
			ArrayList<Agent> prosumers, ArrayList<GridAgent> grids, Weather weather, 
			Solver solver, int auctionIterations, 
			Random randomGen
			){
		this.beginning = beginning;
		this.simulationDuration = simulationDuration;
		currentTime = Calendar.getInstance();
		currentTime.setTime(beginning.getTime());
		
		this.prosumers = prosumers;
		this.grids = grids;
		this.weather = weather;
		this.solver = solver;
		this.auctionIterations = auctionIterations;
		this.randomGen = randomGen;
		
		pc = new PauseControl();
		terminate = false;
		next = false;
	}
	
	public void setDisplay(HEMSDisplay display){
		this.display = display;
	}
		
	public void simulate() throws RemoteManagerUanavailableException{
		
		// transactions running at the current time instant (initially empty)
		ArrayList<Transaction> runningTransactions = new ArrayList<Transaction>();
		// allocated demand and supply for each agent
		HashMap<Agent, int[]> allocatedAmount = new HashMap<Agent, int[]>();
		// devices allowed to run their controller
		HashSet<Agent> allowedToTrade = new HashSet<Agent>();
				
		double localEnergyCost = 0;
		int actual_localDemand = 0, traded_localDemand = 0; 
		int traded_demandFromLocalGeneration = 0; int traded_fedIntoGrid = 0;
		int actual_localProduction = 0; int actual_gridAvailability = 0;
		
		Calendar allocationTime = Calendar.getInstance();
		
		try {
			// run the simulation till the end of the duration or when the user clicks on stop
			while(! (terminate ||  ((currentTime.getTimeInMillis()/1000) - (beginning.getTimeInMillis()/1000) > this.simulationDuration))){
				// loop while !terminate && !timeOVer = ! (terminate || timeOVer)
						
				if(next){
					next = false;
					pause();
				} 
				// the simulation gets blocked here when paused, so a next causes the sim flow to continue from here
				pc.pausePoint();
						
				// 1. Update state
				allocationTime.setTime(currentTime.getTime()); allocationTime.add(Calendar.SECOND, 1); 	// allocating power for the next second
				
				if(this.display != null) display.updateProgress((int) (currentTime.getTimeInMillis() / 1000), this.format.format(currentTime.getTime()));

				//int actual_localDemand = 0;
				actual_localProduction = 0;
				// update time on the market (updates state of loads, noop for generators)
				for(Agent p : prosumers){
					// update status of the devices according to their last offer and its outcome on the market
					p.updateStatus(currentTime);
					// reset the allocated amount for the agent at the next time
					allocatedAmount.put(p, new int[2]);	// [0]: demand,  [1]: supply
							
					// compute actual consumption and production
					//actual_localDemand += ??
					actual_localProduction += p.getGenerationModel().getCurrentProduction(currentTime, weather);
				} 
						
				// loop on all grid connections to compute available power in the grid (that can be provided)
				actual_gridAvailability = 0; for(GridAgent ga : grids) actual_gridAvailability += ga.getGenerationModel().getCurrentProduction(currentTime, weather);
						
				// update graph view with the current status of the power grid
				if(this.display != null) display.updateGridTopology(prosumers, grids, runningTransactions); 
						
				// compute cost of energy within the market as average energy price among the running devices
				localEnergyCost = runningTransactions.size() > 0 ? 									// avoid division by 0 that would produce a NaN
										localEnergyCost /  runningTransactions.size() :				// when something is running it is given by the average energy price
											Utils.getAverageGridEnergyPrice(currentTime, grids);	// when nothing is running it equals the grid energy price
						
				// print stats on the charts
				if(this.display != null) 
					display.updateSimulationStatus(new TimeInstant(currentTime, 
														weather.getSunFactor(currentTime),
														
														Utils.getAverageGridEnergyPrice(currentTime, grids), 
														Utils.getAverageFITPrice(currentTime, grids),
																
														actual_gridAvailability,
														actual_localProduction, 
														localEnergyCost, 
														traded_localDemand,
														traded_demandFromLocalGeneration,
														traded_fedIntoGrid
						));
						
				// -----------------
				// For each agent retrieve the willingness to trade at the current simulation time, based on future demand and current production
				HashMap<String, TraderWillingness> traders_willingness = new HashMap<String, TraderWillingness>();
				
				// get willingness to trade at the current simulation time
				for(Agent p : prosumers) traders_willingness.put(p.getName(), p.getWillingnessToTrade(currentTime, allocationTime, weather));
							
				// update interface and timeseries logger
				if(this.display != null) display.updateTradingWillingness(currentTime, traders_willingness);
						
				// -----------------
				// 2.2 Simulate market-based allocation	---------------------------------------------------------------				
				TradeResult result = solver.simulateAuction(currentTime, allocationTime, weather, 
															localEnergyCost,
															auctionIterations, 
															randomGen, traders_willingness,
															grids, prosumers);
				// overwrite transactions to be implemented at the next time instant
				runningTransactions = result.approvedTransactions;		// filtered transactions
				allowedToTrade = result.participatingTraders;			// devices allowed to run their smart controller
					
				double actualOverallProfit = 0;
				double equilibriumOverallProfit = 0;
						
				// clean variables used for the current allocation
				traded_demandFromLocalGeneration = 0;
				traded_localDemand = 0;
				traded_fedIntoGrid = 0;
				localEnergyCost = 0;
				// loop on all transactions to manage device billing
				for(int i = 0; i < runningTransactions.size(); i++){
					// get transaction
					Transaction t = runningTransactions.get(i);
							
					double money = t.price * t.amount / (1000*3600);
					t.seller.getPaid(money);	t.buyer.charge(money);
							
					localEnergyCost += t.price;	// add up the unit price so as to average it and plot it at next time
							
					if(t.buyer.isLoad() && t.seller instanceof GridAgent){	// we are buying from the grid (GRID -> Load)
						t.buyer.getOperationModel().addGridCost(money);
						// overwrite existing entry with the new amount
						if(t.type.equals(OfferType.REGULAR)){
							int[] entry = allocatedAmount.get(t.buyer);
							entry[0] += t.amount;
							allocatedAmount.put(t.buyer, entry);
						}
						// keep track of involved demand
						traded_localDemand += t.amount;
					}
					else if(t.buyer.isLoad()){	// we are buying locally from a generator (PV -> Load)
						t.buyer.getOperationModel().addLocalMarketCost(money);
						t.seller.getGenerationModel().addEarningsFromLocalMarket(money);
						
						// overwrite existing entry with the new amount
						if(t.type.equals(OfferType.REGULAR)){
							int[] entry = allocatedAmount.get(t.buyer);
							entry[0] += t.amount;
							allocatedAmount.put(t.buyer, entry);
						}
						// for the generators we are interested in any kind of energy allocated: idle + regular, as they aim at selling it all
						int[] entrySeller = allocatedAmount.get(t.seller);
						entrySeller[1] += t.amount;
						allocatedAmount.put(t.seller, entrySeller);
						
						// keep track of demand
						traded_localDemand += t.amount;
						// add the self-consumption
						traded_demandFromLocalGeneration += t.amount;
					}
					else if(!t.buyer.isLoad() && !(t.buyer instanceof GridAgent)){	// the local generator is buying from somebody else (to cope with his idle power)
						// keep track of demand
						traded_localDemand += t.amount;
					}
					else if(t.buyer instanceof GridAgent){ 	// we are selling energy to the grid (LG -> GRID)
						t.seller.getGenerationModel().addEarningFromGrid(money);
						// keep track of power supplied by the generator
						int[] entrySeller = allocatedAmount.get(t.seller);
						entrySeller[1] += t.amount;
						allocatedAmount.put(t.seller, entrySeller);
						// keep track of power sold to the grid
						traded_fedIntoGrid += t.amount;
					}
							
					/*
					 * Computing the market allocation efficiency:
					 * 1. The profit of All traders that do not take part in a transaction is 0
					 * 2. Transactions of kind Grid -> Load have efficiency 1 because p and p* is the same
					 * 3. Transactions of kind PV -> Grid have efficiency 1 because p and p* is the same
					 * 4. Transactions of kind PV -> Load have efficiency dependent on p and p* 
					 */
					// get only PV -> Load kind of transactions
					if(t.buyer.getOperationModel() instanceof StateBasedOperationModel && ! (t.seller instanceof GridAgent)){
						actualOverallProfit += t.amount * t.buyer.getOperationModel().getBuyerProfit(currentTime, t.price) +
												t.amount * t.seller.getGenerationModel().getSellerProfit(currentTime, t.price);
								
						equilibriumOverallProfit += t.amount * t.buyer.getOperationModel().getBuyerProfit(currentTime, result.equilibriumPrice) +
													t.amount * t.seller.getGenerationModel().getSellerProfit(currentTime, result.equilibriumPrice);
					}
				}
					
				for(Agent p : prosumers){
					if(allowedToTrade.contains(p)){
						p.allowParticipationToNextDay(true);
					}else{
						p.allowParticipationToNextDay(false);
					}
							
					// agentWillingness = { trading tendency, amountToBuy, amountToSell, delayToleranceLeft, relativeDelayToleranceLeft, priceSensitivity, reservationPrice, idlePowerDemand }
					p.allowToRun(allocatedAmount.get(p)[0],									// demand allocated
								(int) traders_willingness.get(p.getName()).amountToBuy,		// requested in the market 
								currentTime);
							
					p.allowToSupply(allocatedAmount.get(p)[1],									// supply allocated
									(int) traders_willingness.get(p.getName()).amountToSell,	// capable to provide in the market
									currentTime);
				}
						
				MarketEval allocationStats = new MarketEval(currentTime);				
				if(equilibriumOverallProfit == 0.0) 
					allocationStats.marketEfficiency = 0.0;
				else  
					allocationStats.marketEfficiency = actualOverallProfit / equilibriumOverallProfit;
						
				//System.err.println("Actual: "+actualOverallProfit+", Equilibrium: "+equilibriumOverallProfit);
				if(this.display != null) display.updateMarketQuality(allocationStats);
						
				// Prepare for next state
				currentTime.add(Calendar.SECOND, 1);
			}
			
			// --------- Set the progress bar and update the interface
			if(this.display != null) display.updateProgress((int) (currentTime.getTimeInMillis() / 1000), this.format.format(currentTime.getTime()));

		} catch (InterruptedException e) {
			// the thread was interrupted while waiting on the semaphore and will now terminate
		}
	}
	
	public double getFitness(){
		// call the appropriate fitness computer based on the agent type
		return prosumers.size() > 0 ?
				prosumers.get(0).computeFitness(reward, earningsFromGrid, costForGridEnergy, costForLocalEnergy,
												flexibleLoadsOperatedAtLeastOnce > 0 ? (avgRelativeWaitedTimeToStartDevice / (double) flexibleLoadsOperatedAtLeastOnce) : 0.0 ,
												flexibleLoadsWithMoreThanAStateOperated > 0 ? (avgRelativeWaitedTimeToStartIntermediateStates / (double) flexibleLoadsWithMoreThanAStateOperated): 0.0,
												flexibleLoadsWithMoreThanAStateOperated > 0 ? (avgRelativeInterruptionTimeWithinAState / (double) flexibleLoadsWithMoreThanAStateOperated) : 0.0, 
												unallocatedInflexibleBID, unallocatedInflexibleASK,
												timesViolatingHardDeadline, 
												forbiddenMarket, relForbiddenMarket,
												forbiddenLosses, relBIDLosses, relASKLosses,
												unpoweredController, 
												priceDoesNotReflectNeeds, relDoesNotReflectNeeds)
				: 0.0 ;
	}
		
	
	public void computeEvaluation(){
				
		for(Agent p : prosumers){			
			// **** general agent performance ****
			forbiddenMarket += p.getInvalidMarketOffers();						// number of market violating offers
			forbiddenLosses += p.getInsensitivePriceOffers();					// number of price model violating offers
			unpoweredController += p.getTimesControllerWasNotPowered();			// times controller is not powered
			priceDoesNotReflectNeeds += p.getTimesOfferDoesNotReflectNeeds();	// times price does not reflect trading tendency
			
			// overall performances
			relForbiddenMarket += p.getAverageOfferMarketDeviation();
			relDoesNotReflectNeeds += p.getAverageDeviationFromNeeds();
			
			// **** operation model performance ****
			if(p.getOperationModel().isAFlexibleService()){
				flexibleLoads++;
				relBIDLosses += p.getRelativeInsensitiveBIDs();
				
				StateBasedOperationModel loadOperationModel = (StateBasedOperationModel) p.getOperationModel();
				
				if(loadOperationModel.hasRunAtLeastOnce()) 					flexibleLoadsOperatedAtLeastOnce++;
				if(loadOperationModel.hasRunAtLeastOnceAndMoreThanAState()) flexibleLoadsWithMoreThanAStateOperated++;
				
				avgRelativeWaitedTimeToStartDevice 				+= loadOperationModel.getAverageRelativeOverwaitedTimeToStartDevice();
				avgRelativeWaitedTimeToStartIntermediateStates	+= loadOperationModel.getAverageRelativeOverwaitedTimeToStartIntermediateStates();		// average relative time to start intermediate states
				avgRelativeInterruptionTimeWithinAState			+= loadOperationModel.getAverageRelativeInterruptionTime();								// average relative interruption time
	
			}else{
				unallocatedInflexibleBID += p.getOperationModel().getTimesInflexibleUnallocated();
			}
			costForGridEnergy 			+= p.getOperationModel().getGridEnergyCost();						// money resulting from purchases from the grid
			costForLocalEnergy			+= p.getOperationModel().getMoneySpentLocally();					// money resulting from purchases in the local market
			timesViolatingHardDeadline	+= p.getOperationModel().getTimesUnallocatedWithinHardDeadline();	// number of times the device decided to run and never managed to start
			reward						+= p.getOperationModel().getCumulativeReward();						// add up all utility delivered to users
			
			// **** generation model performance ****
			earningsFromGrid			+= p.getGenerationModel().getEarningFromGrid(); 
			
			// for inflexible devices get the times they did not allocate their power
			if( p.getGenerationModel().isAFlexibleService()){
				flexibleGenerators++;
				relASKLosses			+= p.getRelativeInsensitiveASKs();									// average deviation from sensitivity for flexible services
			}else{
				unallocatedInflexibleASK+= p.getGenerationModel().getTimesInflexibleUnallocated();
			}
		}
		
		// compute performance measure of price reflecting trading tendency and market status
		// generally, we should only consider devices which made at least an offer, otherwise a device that never runs is always better off
		if(prosumers.size() > 0){
			relForbiddenMarket		/= (double) prosumers.size();
			relDoesNotReflectNeeds	/= (double) prosumers.size();
		}
		
		// compute the average losses for the flexible agents (which should rationally select their price)
		if(flexibleGenerators>0)	relASKLosses /= (double) flexibleGenerators;
		if(flexibleLoads>0)			relBIDLosses /= (double) flexibleLoads;
		
		// compute the average over all actually operated loads
		if(flexibleLoadsOperatedAtLeastOnce > 0){
			avgRelativeWaitedTimeToStartDevice		/= (double) flexibleLoadsOperatedAtLeastOnce;
			avgRelativeInterruptionTimeWithinAState	/= (double) flexibleLoadsOperatedAtLeastOnce;
		}

		// only devices with more than a state operated are considered in the average time to start intermediate states
		if(flexibleLoadsWithMoreThanAStateOperated > 0){
			avgRelativeWaitedTimeToStartIntermediateStates /= (double) flexibleLoadsWithMoreThanAStateOperated;
		}
	
	}
	
	
	// --- Simulation controls ------------------------------------------------------------------------------
		public synchronized void pause(){
			pc.pause();
		}
		
		public synchronized void unpause(){
			pc.unpause();
		}
		
		public void stop(){
			terminate = true;
		}
		
		public void next(){
			next = true;
			unpause();
		}
		
		public class PauseControl {
		    private boolean needToPause;
		    
		    public PauseControl(){
		    	needToPause = false;
		    }

		    public synchronized void pausePoint() throws InterruptedException {
		        while (needToPause) {
		            wait();
		        }
		    }

		    public synchronized void pause() {
		        needToPause = true;
		    }

		    public synchronized void unpause() {
		        needToPause = false;
		        this.notifyAll();
		    }
		}
}
