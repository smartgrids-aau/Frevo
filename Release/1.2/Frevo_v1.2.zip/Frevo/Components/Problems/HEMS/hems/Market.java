package hems;

import hems.devices.Agent;
import hems.devices.generators.weather.Weather;
import hems.devices.mainGrid.GridAgent;
import hems.devices.modelManager.RemoteManagerUanavailableException;
import hems.display.HEMSDisplay;
import hems.solvers.Solver;

import java.awt.GraphicsEnvironment;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Random;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

import core.AbstractRepresentation;
import core.AbstractSingleProblem;

public class Market extends AbstractSingleProblem {
	
	protected HEMSDisplay display;
	
	protected SimpleDateFormat format = new SimpleDateFormat("yyyy MM dd HH:mm:ss");
	
	// *** Simulation settings
	protected Calendar simulationStartTime;			// start time
	protected int simulationDuration;				// simulation lenght
	protected int allocationTimeslotLenght;			// allocation length
	
	protected Random randomGen;
	protected int iterations;						// auction iterations
	
	// *** Agents (in their initial state)	
	public static int rewardFactor;						// weight for the reward given upon completion of an operation
	public static int penaltyGridUse;					// penalty for using the grid to exchange energy
	public static int penaltyUnstarted;					// discomfort created when a device is not allocated at all
	
	public static int penaltyDelayedDeviceStart;			// discomfort given by starting after waiting over the delay sensitivity (S_1)
	public static int rewardDeviceStart;					// discomfort given by starting after waiting over the delay sensitivity (S_1)
	
	public static int penaltyDelayedStateStart;			// discomfort given by starting a state after waiting over the delay sensitivity (S_2 .. S_n)
	public static int rewardStateStart;					// discomfort given by starting a state after waiting over the delay sensitivity (S_2 .. S_n)
	
	public static int penaltyStateInterruption;			// discomfort given by interrupting an atomic state (very high indeed)
	
	public static int penaltyViolatingMarket;			// discomfort given by violating the market policies
	public static int penaltyViolatingSensitivity;		// discomfort given by violating the sensitivity price (trading with losses)
	public static int penaltyUnpoweredController;		// discomfort given each and every time the agent needs to make an offer while the controller is not powered
	public static int penaltyUnnecessaryTrading;			// discomfort given by buying/selling energy while it is not available or necessary
	public static int penaltyInflexibleOffers;			// discomfort given by not selling/buying power needed for inflexible services
	
	protected Solver solver;
	
	public static double limitPrice;						// maximum price allowed from the market
	public static double marketPriceThreshold;
	public static String moneySymbol;						// symbol used to represent the money in the simulation
	public static String agentType;
	
	private static String initialScenarioPath;
	
	public static String modelManagerAddress;
	public static int modelManagerPort;
	
	protected void initSimulationSettings(){
		try {			
			// ----------------- Simulation settings
			this.simulationStartTime = Calendar.getInstance();		// time must be defined in the form yyyy MMM dd HH:mm:ss
			this.simulationStartTime.setTime(format.parse(getProperties().get("market_start_time").getValue()));			
			this.simulationDuration = Integer.parseInt(getProperties().get("simulation_duration").getValue());
			this.allocationTimeslotLenght = Integer.parseInt(getProperties().get("allocation_length").getValue());
			this.iterations = Integer.parseInt(getProperties().get("iterations").getValue());
			
			Market.moneySymbol = getProperties().get("money_symbol").getValue();
			Market.marketPriceThreshold = Double.parseDouble(getProperties().get("market_price_threshold").getValue());
			boolean allowGridToGridEnergyTrade =  Boolean.parseBoolean(getProperties().get("allow_grid_to_grid_energy_trade").getValue());
			
			Market.limitPrice = Double.parseDouble(getProperties().get("limit_price").getValue());	// get limit price for the market
			Market.agentType = getProperties().get("agent_type").getValue();
			
			// ------------------ Penalties
			Market.penaltyGridUse = Integer.parseInt(getProperties().get("penalty_grid_use").getValue());
			Market.rewardFactor = Integer.parseInt(getProperties().get("factor_rewarding_completed_operation").getValue());
			
			Market.penaltyDelayedDeviceStart = Integer.parseInt(getProperties().get("penalty_device_start_delay").getValue());
			Market.rewardDeviceStart = Integer.parseInt(getProperties().get("reward_device_start").getValue());
			
			Market.penaltyDelayedStateStart = Integer.parseInt(getProperties().get("penalty_state_start_delay").getValue());
			Market.rewardStateStart = Integer.parseInt(getProperties().get("reward_state_start").getValue());
			
			Market.penaltyStateInterruption = Integer.parseInt(getProperties().get("penalty_state_interruption").getValue());
			
			
			Market.penaltyUnstarted = Integer.parseInt(getProperties().get("penalty_unstarted").getValue());
			Market.penaltyViolatingMarket = Integer.parseInt(getProperties().get("penalty_violating_market").getValue());
			Market.penaltyViolatingSensitivity = Integer.parseInt(getProperties().get("penalty_violating_sensitivity").getValue());
			Market.penaltyUnpoweredController = Integer.parseInt(getProperties().get("penalty_unpowered_controller").getValue());
			Market.penaltyUnnecessaryTrading = Integer.parseInt(getProperties().get("penalty_unnecessary_trading").getValue());
			Market.penaltyInflexibleOffers = Integer.parseInt(getProperties().get("penalty_inflexible_offers").getValue());
			
			Market.initialScenarioPath = getProperties().get("settingsfile").getValue();
			
			Market.modelManagerAddress = getProperties().get("model_manager_address").getValue();
			Market.modelManagerPort = Integer.parseInt(getProperties().get("model_manager_port").getValue());
			
			// use the controlled random generator to provide reproducible results
			this.randomGen = getRandom();
			
			// instantiate the selected type of auction
			//this.solver = new UCDA(allowGridToGridEnergyTrade); 
			//this.solver = new CDA(allowGridToGridEnergyTrade, false);
			Class cl = Class.forName("hems.solvers."+getProperties().get("auction_type").getValue());
			Constructor con = cl.getConstructor(boolean.class);
			this.solver = (Solver) con.newInstance(allowGridToGridEnergyTrade);
			
		} catch (ParseException e) {e.printStackTrace();
		} catch (Exception e) {	e.printStackTrace(); }
	}
	
	// ***********************************************************************
	@Override
	protected double evaluateCandidate(AbstractRepresentation candidate) {
		// load simulation settings 
		initSimulationSettings();		
		
		// load scenario only at the beginning to avoid repeating the disk reading overhead
		ArrayList<Agent> prosumers = new ArrayList<Agent>();
		ArrayList<GridAgent> gridConnections = null;
		Weather weather = null;
		try {
			Parser.loadScenario(initialScenarioPath);
			gridConnections = Parser.getGridConnections(initialScenarioPath);
			prosumers.addAll(Parser.getLoads(initialScenarioPath));
			prosumers.addAll(Parser.getGenerators(initialScenarioPath));
			weather = Parser.getWeatherModel(initialScenarioPath, simulationStartTime);
		} catch (IOException e) {
			if(GraphicsEnvironment.isHeadless()){
				System.out.println("Impossible to retrieve the chosen scenario: "+e.getMessage());
				System.exit(0);
			}else{
				JOptionPane.showMessageDialog(null, "Impossible to retrieve the chosen scenario:\n"+e.getMessage(), "Inane error", JOptionPane.ERROR_MESSAGE);
			}
		} catch (org.json.simple.parser.ParseException e) {
			if(GraphicsEnvironment.isHeadless()){
				System.out.println("Error while parsing scenario description: "+e.getMessage());
				System.exit(0);
			}else{
				JOptionPane.showMessageDialog(null, "Error while parsing scenario description:\n"+e.getMessage(), "Inane error", JOptionPane.ERROR_MESSAGE);
			}
		} catch (Exception e) {
			if (GraphicsEnvironment.isHeadless()) {
				System.out.println(e.getStackTrace());
				System.exit(0);
			} else {
				JOptionPane.showMessageDialog(null, e.getStackTrace(), "Inane error", JOptionPane.ERROR_MESSAGE);
			}
		}
				
		Calendar beginning = Calendar.getInstance(); beginning.setTime(this.simulationStartTime.getTime());	// set the initial simulation time
				
		for(Agent p : prosumers){
			p.injectBrain(candidate);
			p.setRandomGen(randomGen);
			p.allowParticipationToNextDay(true); 	// at the beginning all agents are assumed to be able to trade their energy
		}
		for(GridAgent gridAgent : gridConnections) gridAgent.setRandomGen(randomGen);
		
		Simulator simulator = new Simulator(beginning, simulationDuration, prosumers, gridConnections, weather, solver, this.iterations, randomGen);
		try{
			simulator.simulate();
			simulator.computeEvaluation();
		}catch(RemoteManagerUanavailableException e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
		
		return simulator.getFitness();
	}
	
	@Override
	public void replayWithVisualization(AbstractRepresentation candidate) {
		initSimulationSettings();
		
		// ask the user if he wants to do the experiment on the same scenario used to learn the controllers or rather another one
		int reply = JOptionPane.showConfirmDialog(null, "Do you want to run the same scenario used for training the controllers?", "Select a scenario", JOptionPane.YES_NO_OPTION);
		
		String scenarioPath = getProperties().get("settingsfile").getValue();
		if (reply == JOptionPane.NO_OPTION) {	
			// load a different scenario
			JFileChooser fileChooser = new JFileChooser();
			fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
			fileChooser.setAcceptAllFileFilterUsed(false);
			fileChooser.setFileFilter(new FileNameExtensionFilter("Scenario files (*.json)", "json"));
			
			int returnVal = fileChooser.showOpenDialog(null);
			if(returnVal == JFileChooser.APPROVE_OPTION) {
				System.out.println("Loading scenario "+fileChooser.getSelectedFile().getPath());
				scenarioPath = fileChooser.getSelectedFile().getPath();
			}else{
				// Nothing to do, the user pressed cancel!!
				return;
			}
		}
		
		// --------------
		ArrayList<Agent> prosumers = new ArrayList<Agent>();
		ArrayList<GridAgent> gridConnections = null;
		Weather weather = null;
		try {
			Parser.loadScenario(scenarioPath);
			gridConnections = Parser.getGridConnections(scenarioPath);
			prosumers.addAll( Parser.getLoads(scenarioPath) );
			prosumers.addAll( Parser.getGenerators(scenarioPath) );
			weather = Parser.getWeatherModel(scenarioPath, simulationStartTime); 
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Impossible to retrieve the chosen scenario:\n"+e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
			return;
		} catch (org.json.simple.parser.ParseException e) {
			//e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Error while parsing scenario description:\n"+e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
			return;
		} catch (Exception e) {
			//e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
			return;
		}
		
		// set the initial time (copy to avoid modifying the initial version)
		Calendar beginning = Calendar.getInstance(); beginning.setTime(this.simulationStartTime.getTime());
		
		// create trading agents out of a trained controller
		for(Agent p : prosumers){
			p.injectBrain(candidate);
			p.setRandomGen(randomGen);
			
			// initially all devices are assumed to be powering their controller
			p.allowParticipationToNextDay(true);
		}
		
		for(GridAgent gridAgent : gridConnections) gridAgent.setRandomGen(randomGen);
	    
		// start the experiment visualization
		display = new HEMSDisplay(beginning, this.simulationDuration, this.solver, weather, this.iterations, randomGen, gridConnections, prosumers);
    	display.setVisible(true);
	}
	
	@Override
	public double getMaximumFitness() {
		return Double.MAX_VALUE;
	}
}