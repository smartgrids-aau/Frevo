package hems.display;

import java.util.Calendar;

public class TimeInstant {
	
	public Calendar date;
	public double sunFactor;
	public double gridEnergyCost;
	public double actualGridAvailability;
	public double fitEnergyCost;
	public double actualLocalProduction;
	public double localEnergyCost;
	
	public double tradedLocalDemand;
	public double tradedDemandFromLocalGeneration;
	public double tradedPowerFedIntoGrid;
	
	public TimeInstant(Calendar date, 
						double sunFactor, 
						double gridEnergyCost,
						double fitEnergyCost,
						
						double actualGridAvailability,
						double actualLocalProduction, 
						
						double localEnergyCost, 
						
						double tradedLocalDemand, 
						double tradedDemandFromLocalGeneration, 
						double tradedPowerFedIntoGrid){
		this.date = date;
		this.sunFactor = sunFactor;
		this.gridEnergyCost = gridEnergyCost;
		this.fitEnergyCost = fitEnergyCost;
		
		this.actualGridAvailability = actualGridAvailability;
		this.actualLocalProduction = actualLocalProduction;
		
		this.localEnergyCost = localEnergyCost;
		
		this.tradedLocalDemand = tradedLocalDemand;
		this.tradedDemandFromLocalGeneration = tradedDemandFromLocalGeneration;
		this.tradedPowerFedIntoGrid = tradedPowerFedIntoGrid;
	}
	
	

}
