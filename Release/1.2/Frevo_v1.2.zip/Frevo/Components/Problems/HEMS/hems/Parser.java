package hems;

import hems.Debugger;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import hems.devices.Agent;
import hems.devices.agents.ClockAgent;
import hems.devices.agents.DAAgent;
import hems.devices.agents.TruthTellingDAAgent;
import hems.devices.generators.EmptyGenerationModel;
import hems.devices.generators.GenerationModel;
import hems.devices.generators.Generator;
import hems.devices.generators.capabilityModel.timebased.TimeBasedGenerator;
import hems.devices.generators.capabilityModel.timebased.TimeBasedTradeableAmount;
import hems.devices.generators.photovoltaics.ModeledPV;
import hems.devices.generators.weather.IntervalBasedWeather;
import hems.devices.generators.weather.TimeBasedCloudFactor;
import hems.devices.generators.weather.TimeserieWeather;
import hems.devices.generators.weather.Weather;
import hems.devices.loads.DeviceStateModel;
import hems.devices.loads.EmptyOperationModel;
import hems.devices.loads.OperationModel;
import hems.devices.loads.StateBasedOperationModel;
import hems.devices.loads.TimeBasedConsumer;
import hems.devices.loads.UsageModel;
import hems.devices.mainGrid.GridAgent;
import hems.devices.mainGrid.capabilityModel.CapabilityModel;
import hems.devices.mainGrid.capabilityModel.IntervalBasedCapability;
import hems.devices.mainGrid.capabilityModel.TimeserieCapability;
import hems.devices.modelManager.ModelManager;
import hems.market.priceModel.PriceModel;
import hems.market.priceModel.StaticPriceModel;
import hems.market.priceModel.tariffbased.Tariff;
import hems.market.priceModel.tariffbased.TariffPriceModel;
import hems.market.priceModel.timeseries.Timeserie;
import hems.market.priceModel.timeseries.TimeseriePriceModel;

public class Parser {
	
	private static HashMap<String, JSONObject> scenarios = new HashMap<String, JSONObject>();
	private static JSONParser jsonParser = new JSONParser();
	
	/*
	private static HashMap<String, ArrayList<GridAgent>> loadedGridConnections = new HashMap<String, ArrayList<GridAgent>>();
	private static HashMap<String, ArrayList<Agent>> loadedLoads = new HashMap<String, ArrayList<Agent>>();
	private static HashMap<String, ArrayList<Agent>> loadedGenerators = new HashMap<String, ArrayList<Agent>>();
	*/
	
	public synchronized static void loadScenario(String filepath) throws IOException, ParseException{
		if(! scenarios.containsKey(filepath)){
			scenarios.put(filepath, (JSONObject) jsonParser.parse(new FileReader(filepath)));
		}
	}
	
	private synchronized static JSONObject getOrLoadScenario(String filepath) throws FileNotFoundException, IOException, ParseException{
		JSONObject scenario = null;
		
		if(scenarios.containsKey(filepath)){
			scenario = scenarios.get(filepath);
		}else{
			scenarios.put(filepath, (JSONObject) jsonParser.parse(new FileReader(filepath)));
			scenario = scenarios.get(filepath);
		}
		
		return scenario;
	}
	
	private static Agent createAgent(String name, double credit, OperationModel om, GenerationModel gm){
		Agent agent = null;
		switch(Market.agentType){
			case "TruthTellingDAAgent":
				agent = new TruthTellingDAAgent(name, credit, om, gm);
				break;
				
			case "DAAgent":
				agent = new DAAgent(name, credit, om, gm);
				break;
				
			case "ClockAgent":
				agent = new ClockAgent(name, credit, om, gm);
				break;
		}
		return agent;
	}
	
	/**
	 * Returns a list of agents managing the connection with the main grid
	 * @return
	 * @throws Exception 
	 */
	public synchronized static ArrayList<GridAgent> getGridConnections(String filepath) throws Exception{
		
		//if(!loadedGridConnections.containsKey(filepath)){
			JSONObject scenario = getOrLoadScenario(filepath);//scenarios.get(filepath);
			
			ArrayList<GridAgent> gridConnections = new ArrayList<GridAgent>();
			
			JSONArray grids = (JSONArray) scenario.get("grid_connections");
			
			for(int i = 0; i < grids.size(); i++){
				// get the current grid
				Map gridObject = (Map) grids.get(i);
				
				String name = (String) gridObject.get("name");
				Double credit = (Double) gridObject.get("credit");
				
				// *** get the price model for the grid agent ***
				PriceModel priceSensitivity = null;
				PriceModel reservationPrice = null;
				Map priceModelMap = (Map) gridObject.get("price-model");
				try{ reservationPrice = getPriceModel(priceModelMap.get("tariff"));	}catch(NullPointerException e) { throw new Exception(name+" misses a reservation price model");	}
				try{ priceSensitivity = getPriceModel(priceModelMap.get("feed-in")); }catch(NullPointerException e) { throw new Exception(name+" misses a reservation price model");	}
				
				// *** get the capability model for the agent ***
				Map capModel = (Map) gridObject.get("capability-model");
				
				gridConnections.add(new GridAgent(name,
												credit,
												new TimeBasedConsumer(priceSensitivity, getCapabilityModel(capModel.get("power-capability"))),
												new GenerationModel(reservationPrice, new TimeBasedGenerator(getCapabilityModel(capModel.get("power-availability"))))));
			}	
			/*
			loadedGridConnections.put(filepath, gridConnections);
		}
		return loadedGridConnections.get(filepath);
		*/
		
		return gridConnections;
	}
	
	// ----------------------------------------------------------------------------------------
	
	public synchronized static ArrayList<Agent> getLoads(String filepath) throws Exception{		
		//if(!loadedLoads.containsKey(filepath)){
			ArrayList<Agent> loads = new ArrayList<Agent>();
			
			JSONObject scenario = getOrLoadScenario(filepath);//scenarios.get(filepath);
			
			Map market = (Map) scenario.get("market");
			
			JSONArray devs = (JSONArray) scenario.get("loads");
			Map appsObject, payloadObject;
			String name;
			Double credit;
			boolean deferrable;
			
			String type;
			Agent l; UsageModel usage; StateBasedOperationModel m;
			for(int i=0; i < devs.size(); i++){
				DeviceStateModel dm = new DeviceStateModel();
				appsObject = (Map) devs.get(i);
				
				name = (String) appsObject.get("name");	
				credit = (Double) appsObject.get("credit");	// initial credit given by the "user"
				
				// ------ the load has a smart controller, get its consumption when defined ------
				int idle = 0;
				try{
					idle = ((Long) appsObject.get("idle")).intValue();
				}catch(Exception e){	/* NO-OP -> the load has no idle consumption */	}
				
				// ------ ------ the hard deadline is also optional ------ ------
				boolean firstOfferExpiration = false;
				int expirationDeadline = 0;
				try{
					expirationDeadline = ((Long) appsObject.get("offer_expiration")).intValue();
					// Set the first offer expiration to true as we have expressed a deadline
					firstOfferExpiration = true;
				}catch(Exception e){	/* NO-OP -> the load has no hard deadline */	}
				// ------ ------ ------ ------ ------ ------ ------ ------ ------
				
				type = (String) appsObject.get("type");
				deferrable = (boolean) appsObject.get("deferrable");
				payloadObject = (Map) appsObject.get("payload");
				
				// POSSIBLE TYPES OF DEVICES - GREEDY/RANDOM, MODELED
				// RANDOM: powerProfile, priceSensitivity, willingness, decay
				// MODELED: powerProfile, priceSensitivity, willingness(timeOfUse), decay(timeOfUse)
				switch(type){			
					case "RANDOM":
						/*
						 * The Random device has: dm, sensitivity, willingness, decay
						 */
						JSONArray powerProfileArray = (JSONArray) payloadObject.get("power");
						for(int j=0; j<powerProfileArray.size(); j++){
							List<Long> entry = (List<Long>) powerProfileArray.get(j);
							if(deferrable){
								dm.addState(entry.get(0).intValue(), entry.get(1).intValue(), entry.get(2).intValue());
							}else{
								dm.addState(entry.get(0).intValue(), entry.get(1).intValue());	// inflexible devices do not model the delay sensitivity (0 anyway)
							}
						}
						
						// build a usage model
						usage = new UsageModel(); usage.buildRandom((Double) payloadObject.get("willingness"), (Double) payloadObject.get("willingness_decay"));
						// build a state-based operation model
						if(deferrable){
							PriceModel pm;
							try{ pm = getPriceModel(payloadObject.get("sensitivity"));
							}catch(NullPointerException e) { throw new Exception(name+" misses a price model"); }
							m = new StateBasedOperationModel(pm, dm, usage);	// flexible service
							m.setAsFlexible();
						}else{
							m = new StateBasedOperationModel(new StaticPriceModel(Market.limitPrice), dm, usage);
							// inflexible service (baseload) -> sensitivity = limitprice
						}
						// set the hard deadline if necessary
						if(firstOfferExpiration) m.buildCriticalLoad(expirationDeadline);
						// create the agent
						l = createAgent(name, credit, m, new EmptyGenerationModel(new StaticPriceModel(Market.limitPrice))); //new Agent(name, credit, m, new EmptyGenerationModel(new StaticPriceModel(Market.limitPrice)));
						// set the consumption of the smart controller						
						l.setIdleConsumption(idle);
						// add the load agent
						loads.add(l);
						break;
						
					case "MODELED":
						String profileType = (String) payloadObject.get("profile-type");
						String position;
						switch(profileType){
							// LOOKUP: the power profile and the usage model are described by a lookup table
							case "LOOKUP":
								// get the file with the power profile and the usage profile
								position = (String) payloadObject.get("profile-position");
								JSONObject profileObject = null;
								try{
									profileObject = (JSONObject) jsonParser.parse(new FileReader(position));
								}catch(FileNotFoundException fe){
									throw new Exception("Impossible to find "+position);
								}
								JSONArray powerArray = (JSONArray) profileObject.get("power");
								JSONArray usageArray = (JSONArray) profileObject.get("usage");
								JSONArray decayArray = (JSONArray) profileObject.get("willingness_decay");
								
								if(usageArray.size() != decayArray.size()) 
									throw new Exception("Usage profile and decay profile for "+name+" have different size!");
							
								for(int j=0; j<powerArray.size();j++){
									List<Long> entry = (List<Long>) powerArray.get(j);
									if(deferrable){
										dm.addState(entry.get(0).intValue(), entry.get(1).intValue(), entry.get(2).intValue());
									}else{
										dm.addState(entry.get(0).intValue(), entry.get(1).intValue());
									}
								}
								double[] usageProfile = new double[usageArray.size()];
								for(int j=0; j<usageProfile.length;j++) usageProfile[j] = (Double) usageArray.get(j);
								double[] willingnessDecayProfile = new double[decayArray.size()];
								for(int j=0; j<willingnessDecayProfile.length;j++) willingnessDecayProfile[j] = (Double) decayArray.get(j);
								
								// build a usage model
								usage = new UsageModel(); usage.buildLookup(usageProfile, willingnessDecayProfile);
								// build a state-based operation model
								if(deferrable){
									PriceModel pm;
									try{ pm = getPriceModel(payloadObject.get("sensitivity"));
									}catch(NullPointerException e) { throw new Exception(name+" misses a price model"); }								
									m = new StateBasedOperationModel(pm, dm, usage);	// flexible service
									m.setAsFlexible();
								}else{
									m = new StateBasedOperationModel(new StaticPriceModel(Market.limitPrice), dm, usage);					
									// inflexible service (baseload) -> sensitivity = limitprice
								}
								// set the hard deadline if necessary
								if(firstOfferExpiration) m.buildCriticalLoad(expirationDeadline);
								// create the agent
								l = createAgent(name, credit, m, new EmptyGenerationModel(new StaticPriceModel(Market.limitPrice))); //new Agent(name, credit, m, new EmptyGenerationModel(new StaticPriceModel(Market.limitPrice)));
								// set the consumption of the smart controller						
								l.setIdleConsumption(idle);
								// add the load agent
								loads.add(l);	
								break;
							
							// MODEL: could be a neural network, bayesian network, whatever helps us getting the probability of an appliance to start in a specific time
							// a standard interface to handle this kind of models should be discussed and adopted
							case "MODEL":
								// retrieve the power profile for the device
								JSONArray powerProfile = (JSONArray) payloadObject.get("power");
								for(int j=0; j<powerProfile.size();j++){
									List<Long> entry = (List<Long>) powerProfile.get(j);
									if(deferrable){
										dm.addState(entry.get(0).intValue(), entry.get(1).intValue(), entry.get(2).intValue());
									}else{
										dm.addState(entry.get(0).intValue(), entry.get(1).intValue());
									}
								}
								
								// retrieve the usage model for the device
								position = (String) payloadObject.get("profile-position");	// remote position of the model
								String format = (String) payloadObject.get("format"); 		// Format can be a bayesian-network an ANN, etc.
								// if a modeled device is given we need first to look for the plugin allowing us to handle the model
								ModelManager manager;
								try{
									// create a model manager for the first load for which is needed and reuse the same for all others
									manager = ModelManager.getOrCreateInstance(Market.modelManagerAddress, Market.modelManagerPort);
									
									//manager.loadFormat(position, format);	// How important is that the remote model is correctly loaded?
									if(!manager.loadFormat(position, format)) 
										throw new Exception("Usage model for "+name+" was not loaded, check the server");
									if(!manager.listAvailableFormats().contains(format)) 
										throw new Exception("The format "+format+" is not supported!!\n"+manager.listAvailableFormats().toString());
								}catch(UnknownHostException e){ 
									throw new Exception("Impossible to connect to "+Market.modelManagerAddress+":"+Market.modelManagerPort); 
								}
								
								// -- build a usage model --
								usage = new UsageModel(); usage.buildModeled(manager, position);	// pass the reference to the model manager
								// build a state-based operation model
								if(deferrable){
									PriceModel pm;
									try{ pm = getPriceModel(payloadObject.get("sensitivity"));
									}catch(NullPointerException e) { throw new Exception(name+" misses a price model"); }								
									m = new StateBasedOperationModel(pm, dm, usage);	// flexible service
									m.setAsFlexible();
								}else{
									// inflexible service (baseload) -> sensitivity = limitprice
									m = new StateBasedOperationModel(new StaticPriceModel(Market.limitPrice), dm, usage);
								}
								// set the hard deadline if necessary
								if(firstOfferExpiration) m.buildCriticalLoad(expirationDeadline);
								// create the agent 
								l = createAgent(name, credit, m, new EmptyGenerationModel(new StaticPriceModel(Market.limitPrice))); //new Agent(name, credit, m, new EmptyGenerationModel(new StaticPriceModel(Market.limitPrice)));
								// set the consumption of the smart controller
								l.setIdleConsumption(idle);
								// add the load agent
								loads.add(l);
								break;
						}
						break;
				}
			}
		/*
			loadedLoads.put(filepath, loads);
		}		
		return loadedLoads.get(filepath);
		*/
		return loads;
	}
	
	public synchronized static ArrayList<Agent> getGenerators(String filepath) throws Exception{
		//if(!loadedGenerators.containsKey(filepath)){
		
			ArrayList<Agent> generators = new ArrayList<Agent>();
			
			JSONObject scenario = getOrLoadScenario(filepath);//scenarios.get(filepath);
			
			// Parse the producers
			JSONArray producers = (JSONArray) scenario.get("producers");
			
			for(int i=0; i < producers.size(); i++){
				Map prodObject = (Map) producers.get(i);
				
				String name = (String) prodObject.get("name");
				String prodType = (String) prodObject.get("type");
				boolean deferrable = false; // by default energy sold by generators cannot be posponed over time, but there are exceptions (e.g. batteries)
				// leave the deferrability as optional for generators, it might be annoying to define it each time
				try{ deferrable = (boolean) prodObject.get("deferrable"); }catch(Exception e){}
				
				// the generator has a smart controller, get its consumption when defined
				int idle = 0; try{ idle = ((Long) prodObject.get("idle")).intValue(); }catch(Exception e){ System.err.println(e); }
				// get also the initial credit if specified
				double credit = 0;	try{ credit = (Double) prodObject.get("credit"); }catch(Exception e){}
				// get the reservation price model for the generator
				PriceModel reservationPriceModel;
				try{ reservationPriceModel = getPriceModel(prodObject.get("price-model"));
				}catch(NullPointerException e) { throw new Exception(name+" misses a price model"); }
				
				Map payload = (Map) prodObject.get("payload");
				// create a generator according to the specified type
				Generator g = null;
				switch(prodType){
					case "MODELED-PV":
						g = new ModeledPV((Double) payload.get("peakPower"),
											(Double) payload.get("efficiency"),
											(Double) payload.get("latitude"),
											(Double) payload.get("longitude"),
											(Double) payload.get("height"),
											(Double) payload.get("size"));
						break;
					
					case "MEASURED-PV":					
						g = new TimeBasedGenerator(getCapabilityModel(payload));
						break;						
					
					case "MODELED-WINDGEN":
						// TODO: the wind generator is not yet available -> ASK Manfred please!!!
						break;
					
					case "MEASURED-WINDGEN":
						g = new TimeBasedGenerator(getCapabilityModel(payload));
						break;
				}
				GenerationModel gm = new GenerationModel(reservationPriceModel, g); 	// generation model
				if(deferrable) gm.setAsFlexible();
				
				Agent lg = createAgent(name, credit, new EmptyOperationModel(), gm);
				/*
				Agent lg = new Agent(name, credit, 
									new EmptyOperationModel(),							// empty consumer model
									gm);
				*/
				lg.setIdleConsumption(idle);					
				generators.add(lg);
			}
			
		/*	
			loadedGenerators.put(filepath, generators);			
		}
		return loadedGenerators.get(filepath);
		*/
		return generators; 
	}
	
	private static PriceModel getPriceModel(Object model) throws Exception{
		PriceModel priceModel = null;
		
		if(model instanceof Map){
			Map payload = (Map) model;
			
			// check the price type
			String type = (String) payload.get("type");
			
			switch(type){
				case "time-intervals":
					JSONArray intervals = (JSONArray) payload.get("intervals");
					priceModel = new TariffPriceModel(getEnergyTariffs(intervals));
					break;
					
				case "external-timeserie":
					String position = (String) payload.get("position");
					priceModel = new TimeseriePriceModel(getTimeserieFromFile(position));
					break;
			}
		}else{
			// we have a static / predefined price model
			priceModel = new StaticPriceModel((Double) model);
		}
		
		return priceModel;
	}
	
	public static Timeserie<Double> getTimeserieFromFile(String filePath) throws Exception{
		// Implement method to load a timeserie from an external file
		// the timeserie can be used to define a price model for a load/generator, a tariff or a capability model
		// as well as a timeserie modeling weather conditions, power production from renewable sources, as well as actual consumption of devices
		
		Timeserie<Double> result = null;
		
		Map timeserieObject = null;
		try{ timeserieObject = (Map) jsonParser.parse(new FileReader(filePath));
		}catch(FileNotFoundException fe){ throw new Exception("Impossible to find the timeserie at "+filePath);	}
		
		// Get fields from timeserie file
		long beginning = 0;
		// try to get the beginning as unix timestamp in seconds
		try{ beginning = (long) timeserieObject.get("beginning");
		}catch(ClassCastException e){
		// otherwise the user has set a date time as a string, which we need to parse
			SimpleDateFormat format = new SimpleDateFormat("yyyy MM dd HH:mm:ss");
			Calendar b = Calendar.getInstance();
			b.setTime(format.parse(timeserieObject.get("beginning").toString()));
			beginning = b.getTimeInMillis() / 1000;
		}
		// create the timeserie
		result = new Timeserie<Double>(beginning);
		
		JSONArray timeserieData = (JSONArray) timeserieObject.get("data");
		// populate the timeserie
		for(int j=0; j<timeserieData.size(); j++){
			List<Number> interval = (List<Number>) timeserieData.get(j);
			
			result.addEntry(interval.get(0).doubleValue(), // Value
							interval.get(1).longValue() ); // interval length			
		}
		
		return result;
	}
	
	private static CapabilityModel getCapabilityModel(Object model) throws Exception{
		CapabilityModel result = null;
		
		Map payload = (Map) model;
		
		// check the price type
		String type = (String) payload.get("type");
		
		switch(type){
			case "time-intervals":
				JSONArray intervals = (JSONArray) payload.get("intervals");
				result = new IntervalBasedCapability(getPowerCapability(intervals));
				break;
				
			case "external-timeserie":
				String position = (String) payload.get("position");
				result = new TimeserieCapability(getTimeserieFromFile(position));
				break;
		}
		
		return result;
	}
	
	/**
	 * Parses a json field representing energy tariffs as list of time intervals
	 * @param tariffs
	 * @return
	 */
	private static ArrayList<Tariff> getEnergyTariffs(JSONArray tariffs){
		ArrayList<Tariff> plan = new ArrayList<Tariff>();
		
		for(int i=0; i < tariffs.size(); i++){
			Map dict = (Map) tariffs.get(i);
			
			String name = (String) dict.get("name");
			List<Long> tstart = (List<Long>) dict.get("start");
			List<Long> tend = (List<Long>) dict.get("end");
			Double cost = (Double) dict.get("cost");
			
			Debugger.println("Tariff: "+name+" start ("+tstart.get(0)+", "+tstart.get(1)+")"+", end ("+tend.get(0)+", "+tend.get(1)+"), cost : "+cost);
			
			plan.add(new Tariff(name,
								tstart.get(0).intValue(),
								tstart.get(1).intValue(),
								tend.get(0).intValue(),
								tend.get(0).intValue(),
								cost));
		}
		
		return plan;
	}
	
	/**
	 * Parses a json field representing power capability as list of time intervals
	 * @param plan
	 * @return
	 */
	private static ArrayList<TimeBasedTradeableAmount> getPowerCapability(JSONArray plan){
		ArrayList<TimeBasedTradeableAmount> capability = new ArrayList<TimeBasedTradeableAmount>();
		
		for(int i = 0; i < plan.size(); i++){
			Map dict = (Map) plan.get(i);	
			List<Long> tstart = (List<Long>) dict.get("start");
			List<Long> tend = (List<Long>) dict.get("end");
			int amount = ((Long) dict.get("amount")).intValue();
			
			Debugger.println("Power capability: start ("+tstart.get(0)+", "+tstart.get(1)+")"+", end ("+tend.get(0)+", "+tend.get(1)+"), amount : "+amount);
			
			capability.add(new TimeBasedTradeableAmount(tstart.get(0).intValue(),
												tstart.get(1).intValue(),
												tend.get(0).intValue(),
												tend.get(1).intValue(),
												amount));
		}
		
		return capability;
	}
	
	
	public synchronized static Weather getWeatherModel(String filepath, Calendar simulationBeginning) throws Exception{
		
		JSONObject scenario = getOrLoadScenario(filepath);
		Weather result = null;
		
		Map w = null;
		try{ w = (Map) scenario.get("weather");	
		}catch(Exception e){
			throw new Exception("Weather model missing in the chosen scenario!");
		}
		
		// check the model type
		String type = (String) w.get("type");
		
		switch(type){
			case "time-intervals":
				JSONArray intervals = (JSONArray) w.get("intervals");
				result = new IntervalBasedWeather(getWeatherIntervals(intervals, simulationBeginning));
				break;
				
			case "external-timeserie":
				String position = (String) w.get("position");
				result = new TimeserieWeather(getTimeserieFromFile(position));
				break;
		}
		
		return result;
	}
	
	private static ArrayList<TimeBasedCloudFactor> getWeatherIntervals(JSONArray intervals, Calendar simulationBeginning){
		ArrayList<TimeBasedCloudFactor> weatherModel = new ArrayList<TimeBasedCloudFactor>();
		
		for(int i = 0; i < intervals.size(); i++){
			Map dict = (Map) intervals.get(i);
			List<Long> tstart = (List<Long>) dict.get("start");
			List<Long> tend = (List<Long>) dict.get("end");
			double cloudFactor = (Double) dict.get("cloud-factor");
			
			Debugger.println("Weather interval: start("+tstart.get(0)+", "+tstart.get(1)+", "+tstart.get(2)+", "+tstart.get(3)+", "+tstart.get(4)+")"+
												", end("+tend.get(0)+", "+tend.get(1)+", "+tend.get(2)+", "+tend.get(3)+", "+tend.get(4)+"), cloud-factor: "+cloudFactor);
			
			//new GregorianCalendar(year, month, dayOfMonth, hourOfDay, minute, second)
			// the gregorian calendar wants to get a 0-11 for the month so we need to do -1
			int startYearDay = new GregorianCalendar(simulationBeginning.get(Calendar.YEAR), 
														tstart.get(0).intValue() -1,
														tstart.get(1).intValue(),
														tstart.get(2).intValue(),
														tstart.get(3).intValue(),
														tstart.get(4).intValue()).get(Calendar.DAY_OF_YEAR);
			int endYearDay = new GregorianCalendar( simulationBeginning.get(Calendar.YEAR),
														tend.get(0).intValue() -1,
														tend.get(1).intValue(),
														tend.get(2).intValue(),
														tend.get(3).intValue(),
														tend.get(4).intValue() ).get(Calendar.DAY_OF_YEAR);
			
			weatherModel.add(new TimeBasedCloudFactor(	startYearDay, 				// startYearDay,
														tstart.get(2).intValue(),	//startHour,
														tstart.get(3).intValue(),	//startMins,
														tstart.get(4).intValue(),	//startSecs,
														cloudFactor,
														endYearDay,					//endYearDay,
														tend.get(2).intValue(),		//endHour,
														tend.get(3).intValue(),		//endMins,
														tend.get(4).intValue()		//endSecs
														));
		}
		
		return weatherModel;
	}
}