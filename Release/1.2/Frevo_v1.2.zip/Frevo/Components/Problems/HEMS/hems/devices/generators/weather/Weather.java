package hems.devices.generators.weather;

import java.util.Calendar;

public interface Weather {
	
	public double getSunFactor(Calendar time);
	public double getCloudFactor(Calendar time);
}
