package hems.devices.generators.weather;

import hems.market.priceModel.timeseries.Timeserie;

import java.util.Calendar;

public class TimeserieWeather implements Weather{

	private Timeserie<Double> tsCloudFactor;
	
	public TimeserieWeather(Timeserie<Double> tsCloudFactor){
		this.tsCloudFactor = tsCloudFactor;
	}
	
	@Override
	public double getSunFactor(Calendar time) {
		return 1.0 - this.getCloudFactor(time);
	}

	@Override
	public double getCloudFactor(Calendar time) {
		return tsCloudFactor.getValueStartingFromLastVisited(time.getTimeInMillis() / 1000);
	}

}
