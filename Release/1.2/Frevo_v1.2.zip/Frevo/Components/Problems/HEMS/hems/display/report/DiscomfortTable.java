package hems.display.report;

import hems.Market;

import java.awt.GridLayout;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingUtilities;
import javax.swing.table.AbstractTableModel;

public class DiscomfortTable extends JPanel{
	
	private JTable table;
	
	public DiscomfortTable(){
		
		super(new GridLayout(1,0));
		
		String[][] data = new String[0][0];
		
		AbstractTableModel model = new DiscomfortDataTable(data);
	    table = new JTable(model);
	    
	    table.setFillsViewportHeight(true);
        table.setEnabled(false);
        
        JScrollPane scrollPane = new JScrollPane(table, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        add(scrollPane);
		
	}
	
	public String[] getColumnNames(){
		return ((DiscomfortDataTable) table.getModel()).getColumnNames();
	}
	
	public String[][] getDataTable(){
		return ((DiscomfortDataTable) table.getModel()).getData();
	}
	
	public void updateTable(final ArrayList<String[]> values){
		
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				String[][] data = new String[values.size()][values.size() > 0 ? 7 : 0];
				
				int i=0;
				for(String[] entry : values){
					data[i][0] = entry[0];
					data[i][1] = entry[1];
					data[i][2] = entry[2];
					data[i][3] = entry[3];
					data[i][4] = entry[4];
					data[i][5] = entry[5];
					data[i][6] = entry[6];
					i++;
				}
				DiscomfortDataTable wt = new DiscomfortDataTable(data);
				table.setModel(wt);
				wt.fireTableDataChanged();
			}
	    });
		
		
	}
	
	
	class DiscomfortDataTable extends AbstractTableModel {
		private String[] columnNames = { "State", "First offer", "Start time", "Actual duration (secs)", "Start delay (secs)", "State interruptions [secs]", "Reward ["+Market.moneySymbol+"]"};
		private String[][] table = null;
		
		
		public DiscomfortDataTable(String[][] table){
			this.table = table;
		}
		
		public DiscomfortDataTable(int r, int c) {
			table = new String[r][c];
		}
		
		public String[] getColumnNames(){
			return columnNames;
		}
		
		public String[][] getData(){
			return table;
		}
		
		@Override
		public int getColumnCount() {
			return columnNames.length;
		}

		@Override
		public int getRowCount() {
			return table.length;
		}

		@Override
		public Object getValueAt(int r, int c) {
			return table[r][c];
		}
		
		@Override
		public String getColumnName(int col) {
            return columnNames[col];
        }
	}
	

	 public static void main(String[] args) {
		 javax.swing.SwingUtilities.invokeLater(new Runnable() {
			 @Override
			public void run() {
				 JFrame frame = new JFrame("SimpleTableDemo");
				 frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

				 DiscomfortTable newContentPane = new DiscomfortTable();
				 newContentPane.setOpaque(true); //content panes must be opaque
				 frame.setContentPane(newContentPane);
				 frame.pack();
				 frame.setVisible(true);
			 } 
		 }); 
	 }
}
