package hems.solvers;

import hems.Debugger;
import hems.devices.Agent;
import hems.devices.mainGrid.GridAgent;
import hems.market.Offer;
import hems.market.Offer.OfferType;
import hems.market.Transaction;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;

public abstract class DASolver extends Solver{

	public DASolver(boolean allowGridToGridEnergyTrade) {
		super(allowGridToGridEnergyTrade);

	}
	
	/**
	 * Returns matched transactions, an approximation of the equilibrium price, 
	 * as well as the list of agents who have fully allocated their idle power and their operational power.
	 * @param buyOffers
	 * @param sellOffers
	 * @param participatingTraders
	 * @param unelegibleTraders, agents with all allocated power (sold or bought)
	 * @return
	 */
	protected MatcherResult match(
								ArrayList<Offer> buyOffers, ArrayList<Offer> sellOffers, 
								HashSet<Agent> participatingTraders,
								HashSet<Agent> temporarilyUnelegibleTraders){		
		
		ArrayList<Transaction> matches = new ArrayList<Transaction>();	// temporary matches
		
		ArrayList<Offer> rejectedBIDs = new ArrayList<Offer>();			// keep track of rejected matches
		
		double auctionPrice = 0;
		
		if(!buyOffers.isEmpty() && !sellOffers.isEmpty()){
			// get the best BIDS (0 best, last is worst)
			Collections.sort(buyOffers, new Offer.OrderPriceDesc());	// Highest buy price first (idle > inflexible > flexible)
			Offer bid = buyOffers.get(0);
			
			// get the best ASKS (0 best, last is worst)
			Collections.sort(sellOffers, new Offer.OrderPriceAsc());	// Lowest Sell price first
			Offer ask = sellOffers.get(0);
			
			Debugger.println("\t-- Looking for matches --- B.len="+buyOffers.size()+" S.len="+sellOffers.size());
				String s = ""; for(Offer o : sellOffers) s += o.agent.getName()+"("+o.price+"), ";
				String b = ""; for(Offer o : buyOffers) b += o.agent.getName()+"("+o.price+"), ";
				Debugger.println("\t\t Sellers: "+s);
				Debugger.println("\t\t Buyers: "+b);
				
			boolean terminate = false;
			
			// main condition to run an auction is that the asked price is lower than the bidded one
			while(ask.price <= bid.price && !terminate){
				
				int amount = 0;
				OfferType type = OfferType.REGULAR; // generally we deal regular offers (to operate)
				
				// allow all connections except those of kind Grid1->Grid2 when required by the user
				boolean connectionAllowed = true;
				if((ask.agent instanceof GridAgent) && (bid.agent instanceof GridAgent)){
					connectionAllowed = allowGridToGridEnergyTrade;
				}
						
				// prevent speculating agents to trade their own energy -> i.e. grid2grid loop
				if(!ask.agent.equals(bid.agent) && connectionAllowed){
					buyOffers.remove(0);
					sellOffers.remove(0);
					
					if(ask.amount < bid.amount){
						// the picked ask offer is not sufficient to satisfy the demand (bid offer)
						if((bid.agent instanceof GridAgent && this.allowGridfragmentation) ||	 // the energy fed into the grid can always be a subset of the max capability (in so doing the grid eats all available power that loads might need to operate)
								this.allowBIDfragmentation){	// if allowed also other bids can be divided
							// split the bid so as to cover the best offer and aim for other matches for the leftover
							Offer remainder = new Offer(bid.amount - ask.amount, bid.price, true, bid.agent, bid.timestamp, bid.delayTolerance);
							remainder.iteration = bid.iteration;
							
							if(bid.isIdle()){
								type = OfferType.IDLE;		// mark the transaction type
								remainder.setIdleOffer();
							}
							buyOffers.add(0, remainder);	// add leftover BID to orderbook
							
							amount = ask.amount;			// pending amount is the ASK amount
							
							// the whole supply was matched, put the generator in the list of unelegible traders
							temporarilyUnelegibleTraders.add(ask.agent);
						}else{
							// skip the current BID and go to the next one if there exists, terminate otherwise
							rejectedBIDs.add(bid);
							
							// re-add the current ASK to the top of the orderbook to be used at the next cycle
							sellOffers.add(0, ask);
						}
						
						
					}else if(ask.amount > bid.amount){
						// split the ask offer so as to cover other loads
						Offer remainder = new Offer(ask.amount - bid.amount, ask.price, false, ask.agent, ask.timestamp, ask.delayTolerance);
						remainder.iteration = ask.iteration;
						sellOffers.add(0, remainder);	// add leftover ASK to orderbook
	
						amount = bid.amount;			// pending amount is the BID amount
						
						// the whole BID demand was covered, put the load in the list of unelegible traders based on the offer type
						if(bid.isIdle()){
							type = OfferType.IDLE;		// mark the transaction type
							participatingTraders.add(bid.agent);	// enough power to run at next the controller next time
						}else{
							temporarilyUnelegibleTraders.add(bid.agent);		// enough power to operate at next time
							//System.out.println("Fully allocated (A>B): "+bid.agent.getName()+", "+bid.amount);
						}
							
					}else{
						amount = bid.amount;
						
						// both the demand and the supply were used completely, put both traders in the list of unelegible traders
						// but only if the buyer was not an idle
						if(bid.isIdle()){
							type = OfferType.IDLE;
							participatingTraders.add(bid.agent);
						}else{
							temporarilyUnelegibleTraders.add(bid.agent);
							//System.out.println("Fully allocated (A==B): "+bid.agent.getName()+", "+bid.amount);
						}
						// the seller can't be an idle offer, idle is only for buyers, so we add it anyway
						temporarilyUnelegibleTraders.add(ask.agent);
					}
				
					// Match the two offers into a transaction if we actually found a match, else go ahead to the next pair
					if(amount > 0){
						Debugger.println("\t Added a temporary transaction for "+ask.agent.getName()+" -> "+bid.agent.getName()+" for "+amount);
						Transaction t = new Transaction(ask.agent, bid.agent, amount, type);
						
						// **** Pricing mechanism ****
						
						// 1. Set the grid price for transactions with the grid
						if(t.seller instanceof GridAgent){
							// -- use the energy tariff
							t.setPrice(ask.price);
						}else if(t.buyer instanceof GridAgent){
							// -- use the feed-in tariff
							t.setPrice(bid.price);
						}else{
							// -- it must be a local transaction (local generator -> load)	
							// the auctionPrice is updated at each transaction so as to progressively converge to the equilibrium price
							auctionPrice = (ask.price + bid.price) / 2.0;
							
							// discriminatory auctions (e.g. CDA) will consider only the current pair, which we set hereby
							t.setPrice(auctionPrice);
							// uniform-price auctions will only consider the the value of auctionPrice at the end of the trading day
							// and will rewrite this value accordingly
						}
						
						matches.add(t);
						
						// the auctionPrice is updated at each transaction so as to progressively converge to the equilibrium price
						// auctionPrice = (ask.price + bid.price) / 2.0;
					}
					
				}
				
				// prepare for next loop if possible
				if(!buyOffers.isEmpty() && !sellOffers.isEmpty()){
					bid = buyOffers.get(0);
					ask = sellOffers.get(0);
				}else{
					terminate = true;
					// get out and return
				}
				
			}
			
		}
		
		// don't forget to add all reject offers, as they are still concurring in the orderbook
		buyOffers.addAll(rejectedBIDs);
		
		return new MatcherResult(buyOffers, sellOffers,	// recycle the current orderbook for future iterations
								matches, auctionPrice,
								participatingTraders,
								temporarilyUnelegibleTraders);
	}

}
