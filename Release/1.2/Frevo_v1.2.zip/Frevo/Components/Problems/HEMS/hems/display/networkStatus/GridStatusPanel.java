package hems.display.networkStatus;

import hems.devices.Agent;
import hems.devices.mainGrid.GridAgent;

import java.awt.Dimension;
import java.util.ArrayList;
import java.util.HashSet;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JPanel;

import hems.market.Transaction;

public class GridStatusPanel extends JPanel{
	
	private TradersView networkView;
	private Wallet wallet;
	
	public GridStatusPanel(){
		this.setBorder(BorderFactory.createTitledBorder("Grid status"));
		
		networkView = new TradersView();
		networkView.setMinimumSize(new Dimension(750,290));
		
		wallet = new Wallet();
		wallet.setMinimumSize(new Dimension(300,290));
		
		this.setLayout(new BoxLayout(this, BoxLayout.LINE_AXIS));
		this.add(networkView.graphView);
		this.add(wallet);
	}
	
	/**
	 * Clear the network view after a stop. It removes all edges from the network.
	 */
	public void clear(){
		this.networkView.clearEdges();
	}
	
	/**
	 * Creates a new network view based on the given agents
	 * It can be used to prepare the view at startup
	 * @param agents
	 */
	public void updateView(ArrayList<Agent> prosumers, ArrayList<GridAgent> gridConnections){
		this.networkView.update(prosumers, gridConnections); 		
		this.wallet.updateTable(prosumers, gridConnections);
		this.validate();
		this.repaint();
	}
	
	/**
	 * Update the graph using the given transactions
	 * This method can be used during the simulation
	 * @param transactions
	 */
	public void updateGraph(ArrayList<Agent> prosumers, ArrayList<GridAgent> gridConnections, ArrayList<Transaction> transactions){
		this.networkView.update(prosumers, gridConnections, transactions);
		wallet.updateTable(prosumers, gridConnections);
		this.validate();
		this.repaint();
	}
	
	

}
