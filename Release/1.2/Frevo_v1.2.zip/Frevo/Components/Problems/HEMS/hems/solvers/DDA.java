package hems.solvers;

import hems.Debugger;
import hems.Market;
import hems.devices.Agent;
import hems.devices.TraderWillingness;
import hems.devices.agents.DAAgent;
import hems.devices.generators.weather.Weather;
import hems.devices.loads.NotAvailableForTradeException;
import hems.devices.mainGrid.GridAgent;
import hems.market.IllegalOfferException;
import hems.market.MarketStatus;
import hems.market.Offer;
import hems.market.Transaction;
import hems.market.Offer.OfferType;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Random;

public class DDA extends DASolver{

	public DDA(boolean allowGridToGridEnergyTrade) {
		super(allowGridToGridEnergyTrade);
	}
	
	public TradeResult simulateAuction(Calendar currentTime, Calendar allocationTime, Weather currentWeather, 
			double localPrice,
			int iterations, Random randomGen, HashMap<String, TraderWillingness> willingnessToTrade,
			ArrayList<GridAgent> grids,	ArrayList<Agent> prosumers
			){
		
		// Order book collecting the believed agents' price
		ArrayList<Offer> buyOffers = new ArrayList<Offer>();
		ArrayList<Offer> sellOffers = new ArrayList<Offer>();
				
		// Collection of real offers (using the agents' private values)
		ArrayList<Offer> privateBuyOffers = new ArrayList<Offer>();
		ArrayList<Offer> privateSellOffers = new ArrayList<Offer>();
				
		// current best price in the market: to be shared among the traders
		MarketStatus marketStatus = new MarketStatus(0.0, Market.limitPrice);
				
		// devices who got successfully matched (temporarily)
		HashSet<Agent> temporarilyFullyAllocatedTraders = new HashSet<Agent>();
			
		// devices who got successfully the energy needed to run the smart controller at next time instant
		HashSet<Agent> participatingTraders = new HashSet<Agent>();
				
		// devices that do-not-want/cannot run at the next time instant, so they are unwilling to trade
		HashSet<Agent> unwillingTraders = new HashSet<Agent>();
				
		// temporary structure where matched offers are gathered
		ArrayList<Transaction> pendingTransactions = new ArrayList<Transaction>();
				
		// result of the auction using the truth-telling offers
		MatcherResult equilibriumResult = null;
				
		// *** Collect offers from all agents to compute the equilibrium price ***
		for(Agent a : prosumers){ 
			if(a.isRunningItsController()){
				TraderWillingness agentWillingness = willingnessToTrade.get(a.getName());
				if(agentWillingness.tradingTendency > 0.0){ // BUY
					privateBuyOffers.add(new Offer((int) agentWillingness.amountToBuy, a.getOperationModel().getPriceSensitivity(currentTime), true, a, currentTime) );
				}else if(agentWillingness.tradingTendency < 0.0){ // SELL
					privateSellOffers.add(new Offer((int) agentWillingness.amountToSell, a.getGenerationModel().getReservationPrice(currentTime), false, a, currentTime) );
				}
			}
		}
				
		// *** Collect offers from the grid agents ***
		for(GridAgent grid : grids){
			// get a BID offer from the grid
			Offer gridBID = grid.getBIDOffer(currentTime, allocationTime, currentWeather);
			if(gridBID.amount > 0){
				buyOffers.add(gridBID);
				privateBuyOffers.add(new Offer(gridBID.amount, gridBID.price, true, grid, currentTime));
			}
					
			// get an ASK offer from the grid
			Offer gridASK = grid.getASKOffer(currentTime, allocationTime, currentWeather);
			if(gridASK.amount > 0){
				sellOffers.add(gridASK);
				privateSellOffers.add(new Offer(gridASK.amount, gridASK.price, true, grid, currentTime));
			}
		}
		
		
		// match all truth-telling offers to compute the equilibrium price
		equilibriumResult = match(privateBuyOffers, privateSellOffers, new HashSet<Agent>(), new HashSet<Agent>());
		//equilibriumResult.auctionPrice is the expected equilibrium price
				
		// Get a shallow copy to avoid changing the order also on the interface
		ArrayList<DAAgent> prosumersCopy = new ArrayList<DAAgent>(); 
		for(Agent a : prosumers) prosumersCopy.add((DAAgent) a);
				
		try{
			// run the trading day over durationless iterations (or trading rounds)
			for(int i = 0; i < iterations; i++){
						
				// recycle and try to improve the current status
				marketStatus = this.updateMarketStatus(marketStatus, buyOffers, sellOffers);
						
				// shuffle the agents to give them same chances to trade (for first) over time
				Collections.shuffle(prosumersCopy, randomGen);
						
				for(DAAgent a : prosumersCopy){

					TraderWillingness agentWillingness = willingnessToTrade.get(a.getName());
							
					// only devices whose controller is currently running should be asked to make an offer for the future time instant
					if(a.isRunningItsController()){
						
						participatingTraders.add(a); // force the agent to be queried at each timestamp (no idle power)
						
						/*
						// *** Collect all inflexible offers to manage the idle state of devices (baseline) ***
						try{
							// prevent the system from bothering devices that declared to have no idle or can self-power at next time instant
							if(	!participatingTraders.contains(a)){ // agents who do not need to buy idle power for their controller
											
								Offer offer = a.getIdleDemandOffer(currentTime, allocationTime, currentWeather, marketStatus, 
																	getPositionBIDOrderbook(a, buyOffers, OfferType.IDLE), 
																	getPercentageAllocatedBIDPower(a, pendingTransactions, a.getIdlePowerDemand(), OfferType.IDLE) );
								offer.setIdleOffer();	// mark the offer to avoid replacing it by mistake
								offer.iteration = i;
																
								promptMarketMessage(a.getName()+": "+offer.price+" Euros/KWh\n"+
													"Market(B:"+ marketStatus.buyQuote + ", A:" + marketStatus.sellQuote + "), "+
													"PosBID("+getPositionBIDOrderbook(a, buyOffers, OfferType.IDLE)+"),"+
													"AllBID("+getPercentageAllocatedBIDPower(a, pendingTransactions, a.getIdlePowerDemand(), OfferType.IDLE)+")");
										
								// update the market status if necessary
								if(	offer.price > marketStatus.buyQuote ){
									marketStatus.buyQuote = offer.price;
									// clean previous idle offers if there are
									buyOffers = this.updateBIDOrderbook(buyOffers, a, OfferType.IDLE, offer);
									promptMarketMessage(a.getName()+" made a IDLE-BID offer ("+offer.amount+"W, "+offer.price+Market.moneySymbol+") improving the current market state ("+marketStatus.buyQuote+")");
								}
							}
									
						}catch(IllegalOfferException ex){
							// the agent returned a price that makes no sense for a BID
							promptMarketMessage(a.getName()+ex.getMessage()+"\n"+
											"Market(B:"+ marketStatus.buyQuote + ", A:" + marketStatus.sellQuote + "), "+
											"PosBID("+getPositionBIDOrderbook(a, buyOffers, OfferType.IDLE)+"),"+
											"AllBID("+getPercentageAllocatedBIDPower(a, pendingTransactions, a.getIdlePowerDemand(), OfferType.IDLE)+")");
						}catch (NotAvailableForTradeException e) {
							participatingTraders.add(a);
							promptMarketMessage(a.getName()+" can not trade:\n"+e.getMessage());
						}
						*/		
						// -----------------------------------------------------
								
						// *** Collect regular offers to buy and sell energy ***
						try{
							// ask the agent to make an offer iff he is willing to trade and has not already allocated all available demand/production
							if(!temporarilyFullyAllocatedTraders.contains(a)		// agents with already all allocated power 
									&& !unwillingTraders.contains(a)){				// agents who do not need to buy/sell power
										
								Offer offer = a.queryController(currentTime, allocationTime, currentWeather,
																agentWillingness,
																marketStatus, 
																getPositionBIDOrderbook(a, buyOffers, OfferType.REGULAR), 
																getPercentageAllocatedBIDPower(a, pendingTransactions, (int) agentWillingness.amountToBuy, OfferType.REGULAR), 
																getPositionASKOrderbook(a, sellOffers), getPercentageAllocatedASKPower(a, pendingTransactions, (int) agentWillingness.amountToSell) );
								offer.iteration = i;
										
								promptMarketMessage(a.getName()+": "+(offer.isBIDtype?"BID":"ASK")+" (B:"+agentWillingness.amountToBuy+",S:"+agentWillingness.amountToSell+") "+offer.price+" Euros/KWh\n"+
													"Market(B:"+ marketStatus.buyQuote + ", A:" + marketStatus.sellQuote + "), " +
													"Willingness("+agentWillingness.tradingTendency+"), RelToleranceLeft("+agentWillingness.relativeDelayToleranceLeft+")\n"+
													"BIDPos("+getPositionBIDOrderbook(a, buyOffers, OfferType.REGULAR)+"%), "
															+ "AllBID("+getPercentageAllocatedBIDPower(a, pendingTransactions, (int) agentWillingness.amountToBuy, OfferType.REGULAR)+"%),"+
													"ASKPos("+getPositionASKOrderbook(a, sellOffers)+"%), "
															+ "AllASK("+getPercentageAllocatedASKPower(a, pendingTransactions, (int) agentWillingness.amountToSell) +"%)");
									
								/* NYSE policy: spread reduction rule
								 * 		BID.p > status.BID
								 *  	ASK.p < status.ASK
								 *  
								 *  The policy is a price improvement rule that constraints acceptable offers in the orderbook
								 *  The agents should improve their ranking in the orderbook iff:
								 *  	- there is margin for offers (the status is not the market limit)
								 *  	- there is at least another agent in the counterpart orderbook (any demand/supply offer in the orderbook), such that it makes sense to improve the price
								 *  If these conditions do not hold, it is impossible to improve the agent's condition, and he should receive no penalty for the offer
								 */
								if(offer.isBIDtype){	// ** BID Offer **
									
									a.trackMarketValidityOffer(offer.price, marketStatus.buyQuote, true);
									
									// Each agent can offer a BID in (Market.marketPriceThreshold, Market.limitPrice]
									if(marketStatus.buyQuote == Market.limitPrice && offer.price == Market.limitPrice  
											){ // the market does not provide a margin to improve the price, we need to accept the offer anyway
										promptMarketMessage(a.getName()+" made a BID offer ("+offer.amount+"W, "+offer.price+Market.moneySymbol+") while best is ("+marketStatus.buyQuote+")");
												
										// clean previous offers if there are
										buyOffers = this.updateBIDOrderbook(buyOffers, a, OfferType.REGULAR, offer);
												
									}else if(	offer.price > marketStatus.buyQuote){	
										// the offer improves the market
										promptMarketMessage(a.getName()+" made a BID offer ("+offer.amount+"W, "+offer.price+Market.moneySymbol+") improving the current market state ("+marketStatus.buyQuote+")");
										Debugger.println("\t\t\t Adding the BID offer ("+offer.amount+", "+offer.price+", "+a.getName()+") ");
										// update the market status accordingly
										marketStatus.buyQuote = offer.price;
										// clean previous offers if there are
										buyOffers = this.updateBIDOrderbook(buyOffers, a, OfferType.REGULAR, offer);
									}else{
										// add a penalty to the generator
										a.addInvalidMarketOffer();
										Debugger.println("\t The offer "+offer.agent.getName()+" BID("+offer.price+") does not improve the market");
										promptMarketMessage(a.getName()+" made a NYSE violating BID: "+offer.price+" while bestBID="+marketStatus.buyQuote);
									}
											
								}else{	// ** ASK Offer **
									
									a.trackMarketValidityOffer(offer.price, marketStatus.sellQuote, false);
									
									// Each agent can offer an ASK in (Market.marketPriceThreshold, Market.limitPrice]
									if(	offer.price <= marketStatus.sellQuote){		// the constraint is relaxed <= for the sellers (the more the better)
										// the offer improves the market
										promptMarketMessage(a.getName()+" made an ASK offer ("+offer.amount+"W, "+offer.price+Market.moneySymbol+") improving the current market state ("+marketStatus.sellQuote+")");
										Debugger.println("\t\t\t Adding the ASK offer ("+offer.amount+", "+offer.price+", "+a.getName()+") ");
										// update the market status accordingly
										marketStatus.sellQuote = offer.price;
										// check if the offer was already existing from a previous iteration, so as to replace it in case
										sellOffers = this.updateASKOrderbook(sellOffers, a, offer);
									}else{
										// add a penalty to the generator
										a.addInvalidMarketOffer();
										Debugger.println("\t The offer "+a.getName()+" ASK("+offer.price+") does not improve the market");
										promptMarketMessage(a.getName()+" made a NYSE violating ASK: "+offer.price+" while bestASK="+marketStatus.sellQuote);
									}
								}
							}
						}catch(IllegalOfferException ex){
							// the agent made a BID/ASK while no demand/offer is available
							promptMarketMessage(ex.getMessage());
						} catch (NotAvailableForTradeException e) {
							// add the generator among the ones that do not want to operate for this time instant so as to avoid they get bothered again at the next iteration
							unwillingTraders.add(a);
							Debugger.println(e.getMessage());
							promptMarketMessage(a.getName()+" can not trade:\n"+e.getMessage());
						}
					}else{	// the controller is not running
						// add a penalty for the agent in case he actually wanted to trade
						if(agentWillingness.tradingTendency != 0.0){
							// if the agent would have been interested in trading and could not because he is not reachable
							a.addTimeControllerWasNotPowered();
						}
						promptMarketMessage(a.getName()+" can not trade: the controller is not running");
					}
				}
				
				// display all changes on the market view if it exists and is visible
				if(marketView != null && marketView.isMarketViewAvailable()){
					marketView.updateTable(i,
											participatingTraders, unwillingTraders, temporarilyFullyAllocatedTraders,
											marketStatus, 
											buyOffers, sellOffers, pendingTransactions);
					marketView.endIteration();
				}
			}
			
			// ------------------------
			// What if we remove all demand offers which exceed the overall supply available?
			// This should mitigate the fragmentation of supply avoiding the problem at the source
			int overallSupply = 0; for(Offer o : sellOffers) overallSupply += o.amount;
			for(int o = 0; o < buyOffers.size(); ){
				Offer of = buyOffers.get(o);
				if(	! (of.agent instanceof GridAgent)
						&& of.amount > overallSupply){
					unwillingTraders.add(of.agent);		// the agent cannot trade at the current time
					buyOffers.remove(o);
					promptMarketMessage(of.agent.getName()+" can not trade: the requested demand exceeds available supply");
				}
				else o++;
			}
			// ------------------------
			
			// **** End of the trading day (Clearing the market, formulating the price and committing the transactions) ****
			MatcherResult result = match(buyOffers, sellOffers, participatingTraders, temporarilyFullyAllocatedTraders);
			participatingTraders = result.participatingTraders;
			temporarilyFullyAllocatedTraders = result.temporarilyFullyAllocatedTraders;
			ArrayList<Transaction> newMatches = result.matched;
			
			// add all gathered matches for the current iteration to the pending transactions
			pendingTransactions.addAll(newMatches);
			
			// For transactions not involving the Grid agent, set the price closest to the equilibrium at the end of the iterations
			for(int m=0; m<newMatches.size(); m++){
				Transaction t = newMatches.get(m);
				// set the k-price iff the grid is not among the trading agent for the transaction
				if(!(t.seller instanceof GridAgent) && !(t.buyer instanceof GridAgent)){
					t.setPrice(result.auctionPrice);
				}
			}
			
			// display the final state of the market (end of the trading day)
			if(marketView != null && marketView.isMarketViewAvailable()){
				marketView.updateTable(-1,
										participatingTraders, unwillingTraders, temporarilyFullyAllocatedTraders,
										marketStatus, 
										result.buyOffers, 
										result.sellOffers, 
										pendingTransactions);
				marketView.endIteration();
			}
					
		}catch(InterruptedException e){
			// the simulation thread was stopped while waiting for input on the market view			
		}
		
		// filter transactions
		FilterResult fr = this.filterTransactions(pendingTransactions, participatingTraders, temporarilyFullyAllocatedTraders);
				
		// return the filtered result
		return new TradeResult(fr.approvedTransactions,
								fr.participatingTraders,
								fr.allowedToStart,
								equilibriumResult != null ? equilibriumResult.auctionPrice : 0);		
	}

}
