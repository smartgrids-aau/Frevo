package hems.devices.mainGrid.capabilityModel;

import hems.market.priceModel.timeseries.Timeserie;

import java.util.Calendar;

public class TimeserieCapability implements CapabilityModel{

	private Timeserie<Double> capabilityModel;
	
	public TimeserieCapability(Timeserie<Double> capabilityModel){
		this.capabilityModel = capabilityModel;
	}
	
	@Override
	public int getCapability(Calendar time) {
		return capabilityModel.getValueStartingFromLastVisited(time.getTimeInMillis() / 1000).intValue();
	}

}
