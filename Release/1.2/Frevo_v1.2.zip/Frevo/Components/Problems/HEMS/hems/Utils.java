package hems;

import hems.devices.mainGrid.GridAgent;

import java.util.ArrayList;
import java.util.Calendar;

public class Utils {

	
	public static double getAverageGridEnergyPrice(Calendar currentTime, ArrayList<GridAgent> grids){
		double avg = 0.0;
		
		for(GridAgent ga : grids){
			avg += ga.getGenerationModel().getReservationPrice(currentTime);
		}
		
		// avoid divisions by 0 (NA) and 1 (useless)
		if(grids.size() > 1) avg /= grids.size();
		
		return avg;
	}
	
	public static double getAverageFITPrice(Calendar currentTime, ArrayList<GridAgent> grids){
		double avg = 0.0;
		
		for(GridAgent ga : grids){
			avg += ga.getOperationModel().getPriceSensitivity(currentTime);
		}
		
		// avoid divisions by 0 (NA) and 1 (useless)
		if(grids.size() > 1) avg /= grids.size();
		
		return avg;
	}
}
