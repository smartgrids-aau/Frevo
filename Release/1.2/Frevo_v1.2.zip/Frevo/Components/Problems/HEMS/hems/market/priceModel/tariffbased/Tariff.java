package hems.market.priceModel.tariffbased;

import java.util.Calendar;

public class Tariff {
	
	// Attributes
	private String name;
	private int start;
	private int end;
	private double cost;
	
	public Tariff(String name, int startHour, int startMins, int endHour, int endMins, double cost){
		this.name = name;
		this.start = (60 * startHour) + startMins;
		this.end = (60 * endHour) + endMins;
		this.cost = cost;
	}
	
	public boolean isInTariff(Calendar time){
		int current = (60 * time.get(Calendar.HOUR_OF_DAY)) + time.get(Calendar.MINUTE);
		boolean condition = ((current - start + 24*60) %  (24*60)) < (end - start + 24*60) % (24*60);
		
		return condition;
	}
	
	public double getCost(){
		return cost;
	}
	
	@Override
	public String toString(){
		return "Name: "+name+", Start: "+start+", End: "+end+", Cost: "+cost;
	}

}
