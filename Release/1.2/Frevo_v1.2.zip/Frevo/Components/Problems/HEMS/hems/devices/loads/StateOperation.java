package hems.devices.loads;

import java.util.ArrayList;

public class StateOperation {
	
	public int deviceState;
	public long firstOfferTime;
	
	public long stateBeginningTime;
	public int operationDuration;
	public int startDelay;
	public ArrayList<Integer> interruptions;
	
	public double reward;
	public boolean concluded;
	
	public StateOperation(long firstOfferTime,	// time the devices has decided to run this state
						int deviceState,	// device state
						int startDelay,		// actual delay between the first offer time and the start time 
						long startTime){	// time the state started
		
		this.interruptions = new ArrayList<Integer>();
		
		this.firstOfferTime = firstOfferTime;
		this.deviceState = deviceState;
		
		this.startDelay = startDelay;
		this.stateBeginningTime = startTime;
		
		this.reward = 0;
		this.concluded = false;
	}
	
	/**
	 * Sets the duration in seconds for the state
	 * @param currentTime
	 */
	public void concludeStateOperation(long lastSuccessfulRunTime, double reward){
		// the duration is given as the difference between the timestamp of OFF->ON edge
		// and the time of the OFF->ON edge.
		// however lastSuccessfulRunTime is the time of the last successfully run state value
		// so it does not represent the edge and we need to add +1 to get to the final timestamp
		this.operationDuration = (int) (lastSuccessfulRunTime / 1000  -  this.stateBeginningTime / 1000) + 1;
		this.reward = reward;
		this.concluded = true;
	}
	
	public void addInterruption(int seconds){
		interruptions.add(seconds);
	}
	
	/**
	 * Returns the average of the relative interruption time, i.e. the interruption time is normalized to the interuption sensitivity if exists
	 * @param interruptionSensitivity
	 * @return
	 */
	public double getAvgRelativeInterruptionTime(int interruptionSensitivity){
		double relativeInterruptionTime = 0.0;
		
		for(int i : interruptions){
			relativeInterruptionTime += i;
		}
		
		// avoid divisions by 0 and 1 (non sense)
		if (interruptions.size() > 1) relativeInterruptionTime /= (double) interruptions.size();
		
		// TODO: define what we mean by interruption sensitivity
		// compute the relative value iff it is not 0
		if(interruptionSensitivity > 0) relativeInterruptionTime /= (double) interruptionSensitivity;
		
		return relativeInterruptionTime;
	}
	
	/**
	 * Returns the average time the state was interrupted
	 * @return
	 */
	public double getAvgInterruptionTime(){
		double interruptionTime = 0.0;
		
		for(int i : interruptions){
			interruptionTime += i;
		}
		
		return interruptions.size() > 0 ? 
				interruptionTime / interruptions.size() : 0.0;
	}

}
