package hems.devices.generators;

import java.util.Calendar;

import hems.devices.generators.weather.Weather;
import hems.market.priceModel.PriceModel;

public class EmptyGenerationModel extends GenerationModel{

	public EmptyGenerationModel(PriceModel reservationPrice) {
		super(reservationPrice, null);
		
	}
	
	public EmptyGenerationModel clone(){
		return new EmptyGenerationModel(this.reservationPrice);
	}

	public double getCurrentProduction(Calendar date, Weather weather){
		return 0;
	}
}
