package hems.market.priceModel.timeseries;


import hems.Parser;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/*
 * This class defines a timeserie as a heterogeneous-resolution (edge-based) collection of intervals
 */
public class Timeserie<T> {
	
	// beginning of the interval
	private long beginning;
	private List<TimeValue<T>> timeserie;
	
	private int lastVisitedIndex;
	private long lastVisitedOffset;
	
	public Timeserie(long beginning){
		timeserie = new ArrayList<TimeValue<T>>();
		this.beginning = beginning;
		
		// keep track of last visited interval to speed up search
		lastVisitedIndex = 0;
		lastVisitedOffset = this.beginning;
	}
	
	/**
	 * Add an entry to the timeserie, the maximum number of entries is Integer.MAX_VALUE
	 * that is -2,147,483,647 and +2,147,483,647 (inclusive)
	 * Considering a 1Hz resolution for 1 year measurement we would have 31,536,000 samples
	 * which is very much lower the bounds (which actually would be enough to store 68 years),
	 * The timeserie is anyway expected to store edges:
	 * i.e., considerable changes on the value (depending on set quantization size), 
	 * rather than as a dummy time-triggered manner
	 * 
	 * @param price
	 * @param duration
	 */
	public void addEntry(T value, long length){
		timeserie.add(new TimeValue<T>(value, length));
	}
	
	/**
	 * Returns the value of the time interval in which the given time is contained
	 * @param time
	 * @return
	 */
	public T getValue(long time){
		T result = null;
		long offset = this.beginning;
		boolean getOut = false;
		
		for(int i = 0; !getOut && i < timeserie.size(); i++){
			
			TimeValue<T> entry = timeserie.get(i);
			
			// we are in the interval
			if(offset + entry.getLength() > time){
				result = entry.getValue();
				getOut = true;
			}else{
				// go ahead
				offset += entry.getLength();
			}
		}
		
		// TODO: should we throw an exception indicating that the time is not in any of the intervals?
		return result;
	}
	
	/**
	 * Same as getValue, but this method keeps track of the previously visited interval
	 * as it is rather likely that we are values from the timeline over time and not every time from the beginning
	 * nevertheless, in case of non-ordered calls to the method, it forces a continuous restarting of the search
	 * which makes it like getValue
	 * @param time
	 * @return
	 */
	public T getValueStartingFromLastVisited(long time){
		T result = null;
			
		// does it makes sense to scroll towards the future
		if(lastVisitedOffset > time){	
			// time is actually not in the future but in the past, we need to redo the whole scrolling from scratch
			lastVisitedOffset = this.beginning;
			lastVisitedIndex = 0;
		}
		boolean getOut = false; // loop till the right interval, then getout
		
		// first checks if the current time is included in lastVisitedOffset + length
		// otherwise go till the end of the timeserie
		for( ; !getOut && lastVisitedIndex < timeserie.size(); ){
			TimeValue<T> entry = timeserie.get(lastVisitedIndex);
				
			// we are in the interval
			if(lastVisitedOffset + entry.getLength() > time){
				// we found the right interval, keep track of it
				result = entry.getValue();
				getOut = true;
				//System.out.println("Current time: "+time+" found in "+lastVisitedIndex+" spanning till "+(lastVisitedOffset+entry.getLength())+" ("+lastVisitedOffset+","+entry.getLength()+")");
			}else{
				//System.out.println("Current time: "+time+" not found in: "+lastVisitedIndex+" spanning till "+(lastVisitedOffset+entry.getLength())+" ("+lastVisitedOffset+","+entry.getLength()+")");
				// go ahead
				lastVisitedOffset += entry.getLength();
				lastVisitedIndex++;
			}
		}		
		
		// TODO: should we throw an exception indicating that the time is not in any of the intervals?
		return result;
	}
	
	@SuppressWarnings("hiding")
	public class TimeValue<T>{
		
		private long length;
		// value, kept constant over the current interval
		private T value;
		
		public TimeValue(T value, long length){
			this.value = value;
			this.length = length;
		}
		
		public long getLength(){
			return length;
		}
		
		public T getValue(){
			return value;
		}
		
	}
	
	public static void main(String [] args) throws Exception{
		
		SimpleDateFormat format = new SimpleDateFormat("yyyy MM dd HH:mm:ss");
		
		Calendar beginning = Calendar.getInstance();
		try {
			beginning.setTime(format.parse("2013 01 01 07:51:00"));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		/*
		Timeserie<Double> timeserie = new Timeserie<Double>(beginning.getTimeInMillis() / 1000);
		timeserie.addEntry(0.0, 10);
		timeserie.addEntry(250.0, 50);
		timeserie.addEntry(0.0, 3600);
		*/
		
		// always be careful with the timezones of the dates, the file uses a unix timestamp in local time, as well as the string given to FREVO
		Timeserie<Double> timeserie = Parser.getTimeserieFromFile("/Users/andreamonacchi/Desktop/test_timeserie2.json");
		
		
		for(int i = 0; i < 500; i++){
			System.out.println(format.format(beginning.getTime())+" ("+i+"): "+timeserie.getValueStartingFromLastVisited(beginning.getTimeInMillis() / 1000));//timeserie.getValue(beginning.getTimeInMillis() / 1000));
			beginning.add(Calendar.SECOND, 1);
			
		}
		
	}
	
}
