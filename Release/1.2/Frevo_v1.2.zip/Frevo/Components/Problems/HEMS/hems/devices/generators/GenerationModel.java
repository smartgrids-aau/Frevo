package hems.devices.generators;

import hems.devices.generators.weather.Weather;
import hems.market.priceModel.PriceModel;

import java.util.Calendar;

public class GenerationModel implements Cloneable {
	protected PriceModel reservationPrice;
	protected Generator generator;
	protected boolean serviceFlexibility;	// models the flexibility of the service wrt being shifted over time
	
	protected double earningsFromGrid;
	protected double earningsFromMarket;
	
	// *** Fitness value ***
	protected int timesInflexiblePowerWasNotAllocated;
	
	public GenerationModel(PriceModel reservationPrice, Generator generator){
		this.reservationPrice = reservationPrice;
		this.generator = generator;
		
		earningsFromGrid = 0.0;
		earningsFromMarket = 0.0;
		timesInflexiblePowerWasNotAllocated = 0;
	}
	
	public GenerationModel clone(){
		GenerationModel gm = new GenerationModel(this.reservationPrice, this.generator);
		if(this.isAFlexibleService()) gm.setAsFlexible();
		return gm;
	}
	
	public boolean isAFlexibleService(){
		return this.serviceFlexibility;
	}
	
	public void setAsFlexible(){
		this.serviceFlexibility = true;
	}
	
	public void addTimeInflexibleUnallocated(){
		timesInflexiblePowerWasNotAllocated++;
	}
	
	public int getTimesInflexibleUnallocated(){
		return this.timesInflexiblePowerWasNotAllocated;
	}
	
	public double getCurrentProduction(Calendar date, Weather weather){
		return this.generator.getCurrentProduction(date, weather);
	}
	
	public double getReservationPrice(Calendar allocationTime){
		return this.reservationPrice.getPrice(allocationTime);
	}
	
	public double getSellerProfit(Calendar currentTime, double actualPrice){
		return actualPrice - this.reservationPrice.getPrice(currentTime);
	}
	
	public void addEarningFromGrid(double money){
		earningsFromGrid += money;
	}
	
	public double getEarningFromGrid(){
		return earningsFromGrid;
	}
	
	public void addEarningsFromLocalMarket(double money){
		earningsFromMarket += money;
	}
	
	public double getEarningFromLocalMarket(){
		return earningsFromMarket;
	}	
}
