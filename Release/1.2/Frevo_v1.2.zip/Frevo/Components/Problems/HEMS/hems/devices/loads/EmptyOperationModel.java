package hems.devices.loads;

import java.util.Calendar;

import hems.devices.generators.weather.IntervalBasedWeather;
import hems.market.priceModel.PriceModel;
import hems.market.priceModel.StaticPriceModel;

public class EmptyOperationModel extends OperationModel{

	public EmptyOperationModel() {
		super(new StaticPriceModel(0.0));
	}

	@Override
	public void updateStatus(Calendar currentTime) {
		// DO NOTHING
		
	}

	@Override
	public int getDelaySensitivity() {
		return 0;
	}

	@Override
	public int getFutureDemand(Calendar simulationTime, Calendar allocationTime) {
		return 0;
	}

	@Override
	public void allowToRun(int amount, Calendar simulationTime) {
		// DO NOTHING
		
	}

	@Override
	public OperationModel clone() {
		return new EmptyOperationModel();
	}

	@Override
	public int getPowerDemand() {
		return 0;
	}

	@Override
	public double getAverageInterruptionTime() {
		return 0;
	}

	@Override
	public double getAverageRelativeInterruptionTime() {
		return 0;
	}

	@Override
	public double getAverageRelativeWaitedTimeToStartIntermediateStates() {
		return 0;
	}

	@Override
	public double getAverageWaitedTimeToStartIntermediateStates() {
		return 0;
	}

	@Override
	public double getAverageRelativeTimeToStartDevice() {
		return 0;
	}

	@Override
	public double getAverageWaitedTimeToStartDevice() {
		return 0;
	}

	@Override
	public boolean isRunning() {
		return false;
	}

	@Override
	public boolean isWithinHardDeadline(Calendar simulationTime) {
		return true;
	}

	@Override
	public double getCumulativeReward() {
		return 0;
	}
}
