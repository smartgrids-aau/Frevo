package hems.devices.storage;

public class LeadAcidBattery extends Battery{

	public LeadAcidBattery(double nominalVoltage, double storageCapacity,
			double initialStateOfCharge, double chargingRate,
			double chargingEfficiency, double dischargingRate,
			double dischargingEfficiency) {
		super(nominalVoltage, storageCapacity, initialStateOfCharge, chargingRate,
				chargingEfficiency, dischargingRate, dischargingEfficiency);
		
	}
/*
	public double charge(double current, double chargingResistance) throws HighBatteryCurrentException{
		if(current > this.storageCapacity * this.chargingRate)
			throw new HighBatteryCurrentException("Charging current is too high and might destroy the storage element");
		
		this.stateOfCharge = this.stateOfCharge
	}
	
	public double discharge(double current, double dischargingResistance) throws HighBatteryCurrentException{
		if(current > this.storageCapacity * this.dischargingRate)
			throw new HighBatteryCurrentException("Discharging current is too high and might destroy the storage element");
		
		
	}
	
	private double getBeta(){
		return this.stateOfCharge / this.storageCapacity;
	}
*/	
}
