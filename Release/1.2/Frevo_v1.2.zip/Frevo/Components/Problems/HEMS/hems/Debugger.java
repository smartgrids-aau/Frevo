package hems;

public class Debugger {
	
	private static boolean verbose = false;		// change to hide messages
	
	public static boolean debugLoad = false;
	
	public static synchronized void println(String message){
		if(verbose){
			System.out.println(message);
		}
		
	}
	
	public static synchronized void printLoadInfo(String message){
		if(debugLoad) System.out.println(message);
	}
	
	public static synchronized void printlnErr(String message){
		if(verbose){
			System.err.println(message);
		}
	}
	
	public static synchronized void print(String message){
		if(verbose){
			System.out.print(message);
		}
	}
}
