package hems.devices.loads;

public class NotAvailableForTradeException extends Exception{

	public NotAvailableForTradeException(String message) {
		super(message);
	}

	public NotAvailableForTradeException() {
		super();
	}
}