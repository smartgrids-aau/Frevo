package hems.market;

public class IllegalOfferException extends AuctionException {

	public IllegalOfferException(String message) {
		super(message);
	}

	public IllegalOfferException() {
		super();
	}

}
