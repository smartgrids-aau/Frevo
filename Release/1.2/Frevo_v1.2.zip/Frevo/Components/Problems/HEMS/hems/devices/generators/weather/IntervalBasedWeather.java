package hems.devices.generators.weather;

import hems.Debugger;
import hems.Parser;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

public class IntervalBasedWeather implements Weather{ 
	
	// Volatility: 
	//				volatility of the weather between measurements (daily or every n hours)
	// Cloud factor:
	//				probability of getting clouds, smog, pollution, volcanos from Iceland, etc.
	
	private List<TimeBasedCloudFactor> weatherModel;
	
	public IntervalBasedWeather(List<TimeBasedCloudFactor> weatherModel){
		this.weatherModel = weatherModel;
	}

	@Override
	public double getSunFactor(Calendar time) {
		return 1.0 - this.getCloudFactor(time);
	}

	@Override
	public double getCloudFactor(Calendar time) {
		double cloudFactor = 1.0;
		
		for(TimeBasedCloudFactor interval : weatherModel){
			if(interval.coversThisTime(time)){
				return interval.getCloudFactor();
			}
		}
		
		Debugger.println("\t\t Weather error: cloud-Factor = "+cloudFactor);
		return cloudFactor;
	}
	
	public static void main(String [] args) throws Exception{
		SimpleDateFormat format = new SimpleDateFormat("yyyy MM dd HH:mm:ss");
		
		Calendar beginning = Calendar.getInstance();
		beginning.setTime(format.parse("2013 01 01 07:58:00"));
		
		Weather weather = Parser.getWeatherModel("/Users/andreamonacchi/Desktop/hems_scenario_loads_generators.json", beginning);
		
		boolean edge = false;
		for(int i = 0; i < 600; i++){
			
			System.out.println(format.format(beginning.getTime())+" ("+i+"): "+weather.getCloudFactor(beginning));
			// we are not in a solstice or an equinox
			if(beginning.get(Calendar.DAY_OF_MONTH) != 20){
				if(edge && beginning.get(Calendar.MINUTE) == 0){
					beginning.add(Calendar.HOUR, 22);
					beginning.add(Calendar.MINUTE, 55);
					edge = false;
				}else{
					beginning.add(Calendar.DATE, 1);
				}				
			}
			else if(beginning.get(Calendar.DAY_OF_MONTH) == 20 && beginning.get(Calendar.HOUR_OF_DAY) == 23 &&
					(beginning.get(Calendar.MONTH) == 5 || beginning.get(Calendar.MONTH) == 8 || beginning.get(Calendar.MONTH) == 2 || beginning.get(Calendar.MONTH) == 11) ){
				if(edge){
					beginning.add(Calendar.SECOND, 1);
				}else if(beginning.get(Calendar.MINUTE) == 59){
					edge = true;
					beginning.add(Calendar.SECOND, 55);
				}else{
					beginning.add(Calendar.MINUTE, 1);
				}
			}
			else{
				beginning.add(Calendar.HOUR_OF_DAY, 1);
			}
			
		}
	}
}
