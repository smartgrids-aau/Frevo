package hems.devices.mainGrid.capabilityModel;

import java.util.Calendar;

public interface CapabilityModel {
	public int getCapability(Calendar time);
}
