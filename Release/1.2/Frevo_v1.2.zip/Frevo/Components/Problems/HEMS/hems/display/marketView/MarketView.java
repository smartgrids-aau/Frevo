package hems.display.marketView;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.table.AbstractTableModel;

import hems.devices.Agent;
import hems.market.MarketStatus;
import hems.market.Offer;
import hems.market.Transaction;

public class MarketView extends JFrame implements ActionListener, ItemListener{

	private static final long serialVersionUID = -6516408711038822951L;
	
	private JButton nextIterationBtn;
	private boolean enabledView = false;	
	private Semaphore toBeIterated;
	private Lock lock_availableView;

	private JLabel iterationCount;
	
	private JCheckBox verboseCbx;
	private Lock lock_verboseMessaging;
	private boolean enabledMessaging = false; 
	
	private JList<String> participatingAgents;
	private JScrollPane scrollpa;
	private JList<String> unwillingAgents;
	private JScrollPane scrolluw;
	private JList<String> temporarilyAllocatedAgents;
	private JScrollPane scrollts;
	
	private JLabel marketStatus;
	
	private final String[] columns_buyOffers = {"Buyer", "Amount", "Unit price", "Delay tolerance", "Added at", "Type"};
	private JTable buyOffers;
	
	private final String[] columns_sellOffers = {"Seller", "Amount", "Unit price", "Type"};
	private JTable sellOffers;
	
	private final String[] columns_matchedOffers = {"Seller", "Buyer", "Amount", "Unit price", "Type"};
	private JTable matchedOffers;
	
	public MarketView(){
		toBeIterated = new Semaphore(0, true);
		lock_availableView = new ReentrantLock();
		lock_verboseMessaging = new ReentrantLock();
		
		setTitle("Market View");
		setResizable(true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
		this.setPreferredSize(new Dimension(800, 700));
		
		// ** Command buttons **
		iterationCount = new JLabel("");
		nextIterationBtn = new JButton("Next Iteration");
		nextIterationBtn.setAlignmentX(Component.RIGHT_ALIGNMENT);
		nextIterationBtn.setEnabled(false);
		nextIterationBtn.addActionListener(this);
		
		// ** Options panel **
		JPanel options = new JPanel();
		options.setLayout(new FlowLayout());
		verboseCbx = new JCheckBox("Show verbose messaging");
		verboseCbx.addItemListener(this);
		options.add(verboseCbx);		
		
		// ** Orderbook **
		// Buy offers
		buyOffers = new JTable(new Table(columns_buyOffers, new Object[0][0]));
		buyOffers.setFillsViewportHeight(true);
		buyOffers.setEnabled(false);
		//buyOffers.setBorder(BorderFactory.createTitledBorder("Buy offers"));
		
		// Sell offers
		sellOffers = new JTable(new Table(columns_sellOffers, new Object[0][0]));
		sellOffers.setFillsViewportHeight(true);
		sellOffers.setEnabled(false);
		//sellOffers.setBorder(BorderFactory.createTitledBorder("Sell offers"));
		
		// Matched transactions
		matchedOffers = new JTable(new Table(columns_matchedOffers, new Object[0][0]));
		matchedOffers.setFillsViewportHeight(true);
		matchedOffers.setEnabled(false);
		//matchedOffers.setBorder(BorderFactory.createTitledBorder("Pending transactions"));
		
		// ********* Layout setup *********
		JPanel panel = new JPanel();
		this.add(panel);
		panel.setLayout(new BoxLayout(panel, BoxLayout.PAGE_AXIS));
		
		// add command
		JPanel commands = new JPanel();
		panel.add(commands);
		
		// iteration counter
		JPanel iterationCountPanel = new JPanel();
		iterationCountPanel.setLayout(new FlowLayout());
		iterationCountPanel.add(new JLabel("Iteration: "));
		iterationCountPanel.add(iterationCount);
		
		commands.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.weightx = 0.5;
		
		commands.add(iterationCountPanel, c);
		commands.add(nextIterationBtn, c);
		
		// traders status
		JPanel tradersStatusPanel = new JPanel();
		tradersStatusPanel.setLayout(new BoxLayout(tradersStatusPanel, BoxLayout.LINE_AXIS));//new FlowLayout());
		//tradersStatusPanel.setPreferredSize(new Dimension(700, 120));
		
		participatingAgents = new JList<String>(  new String[0] );
		participatingAgents.setLayoutOrientation(JList.VERTICAL);
		scrollpa = new JScrollPane();
		scrollpa.setViewportView(participatingAgents);
		scrollpa.setBorder(BorderFactory.createTitledBorder("Has idle power"));
		scrollpa.setPreferredSize(new Dimension(140,150));
		tradersStatusPanel.add(scrollpa);
		
		unwillingAgents = new JList<String>( new String[0] );
		unwillingAgents.setLayoutOrientation(JList.VERTICAL);
		scrolluw = new JScrollPane();
		scrolluw.setViewportView(unwillingAgents);
		scrolluw.setBorder(BorderFactory.createTitledBorder("Unwilling to trade"));
		scrolluw.setPreferredSize(new Dimension(140,150));
		tradersStatusPanel.add(scrolluw);
		
		temporarilyAllocatedAgents = new JList<String>(  new String[0] );
		temporarilyAllocatedAgents.setLayoutOrientation(JList.VERTICAL);
		scrollts = new JScrollPane();
		scrollts.setViewportView(temporarilyAllocatedAgents);
		scrollts.setBorder(BorderFactory.createTitledBorder("Fully allocated"));
		scrollts.setPreferredSize(new Dimension(140,150));
		tradersStatusPanel.add(scrollts);
		
		// market status
		JPanel marketStatusPanel = new JPanel();
		marketStatusPanel.setLayout(new FlowLayout());
		marketStatusPanel.add(new JLabel("Market status: "));
		marketStatus = new JLabel("");
		marketStatusPanel.add(marketStatus);
		
		// add options
		panel.add(new JSeparator(SwingConstants.HORIZONTAL));
		panel.add(options);
		panel.add(new JSeparator(SwingConstants.HORIZONTAL));
		panel.add(tradersStatusPanel);
		panel.add(marketStatusPanel);
		panel.add(new JSeparator(SwingConstants.HORIZONTAL));
		
		// add tables
		/*
		JPanel b = new JPanel(); b.add(new JScrollPane(buyOffers)); b.setBorder(BorderFactory.createTitledBorder("Buy offers"));
		JPanel s = new JPanel(); s.add(new JScrollPane(sellOffers)); s.setBorder(BorderFactory.createTitledBorder("Sell offers"));
		JPanel p = new JPanel(); p.add(new JScrollPane(matchedOffers)); p.setBorder(BorderFactory.createTitledBorder("Pending transactions"));
		panel.add(b); panel.add(s);	panel.add(p);
		*/
		
		panel.add(new JScrollPane(buyOffers));
		panel.add(new JScrollPane(sellOffers));
        panel.add(new JScrollPane(matchedOffers));
		
		pack();
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("Next Iteration")){
			// run next iteration
			startIteration();
		}
	}
	
	// -------------------------------------------------------------------------------------------------------
	/**
	 * This method is called by the solver to check if a view exists and should be kept up to date
	 * In this way when using evaluate candidate nobody will have had created the market view
	 * and therefore it won't be updated
	 * @return
	 */
	public boolean isMarketViewAvailable(){
		boolean isAvailable = false;
		// check if the interface was enabled on the display
		lock_availableView.lock();
		isAvailable = enabledView;
		lock_availableView.unlock();
		return isAvailable;
	}
	
	public void setStatus(boolean status){
		lock_availableView.lock();
		enabledView = status;
		lock_availableView.unlock();
		
		// we need to make sure the simulation thread is unlocked in case it was blocked
		if(toBeIterated.hasQueuedThreads()){
			// release the waiting simulation thread
			toBeIterated.release();
		}
	}
	
	// -------------------------------------------------------------------------------------------------------
	
	public boolean isMarketMessagingEnabled(){
		boolean isEnabled = false;
		
		lock_verboseMessaging.lock();
		isEnabled = enabledMessaging;
		lock_verboseMessaging.unlock();
		
		return isEnabled;
	}
	
	public void showAlert(String msg){
		JOptionPane.showMessageDialog(this, msg);
	}
	
	// -------------------------------------------------------------------------------------------------------	
	private void startIteration(){
		nextIterationBtn.setEnabled(false);
		// unlock the simulator thread
		toBeIterated.release();
	}
		
	public void endIteration() throws InterruptedException{
		
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				nextIterationBtn.setEnabled(true);
			}
		});
		
		// lock the simulator thread
		toBeIterated.acquire();
	}
	
	@Override
	public void itemStateChanged(ItemEvent e) {
		
		if(e.getSource() == verboseCbx){
			if (e.getStateChange() == ItemEvent.SELECTED) {
				lock_verboseMessaging.lock();
				// messages to be shown
				this.enabledMessaging = true;
				lock_verboseMessaging.unlock();
		    } else {
		    	lock_verboseMessaging.lock();
		    	// messages should not be shown
		    	this.enabledMessaging = false;
		    	lock_verboseMessaging.unlock();
		    }
		}
	}
	
	public void updateTable(final int iteration, 
							
							final HashSet<Agent> participatingTraders, final HashSet<Agent> unwillingTraders, final HashSet<Agent> temporarilyFullyAllocated,
							
							final MarketStatus status, 
							
							final ArrayList<Offer> buyOffersData, final ArrayList<Offer> sellOffersData, final ArrayList<Transaction> matchedOffersData){
		
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				
				// update the iteration count
				if(iteration >= 0) iterationCount.setText(""+iteration);
				else iterationCount.setText("Auction END");
				
				String[] pt = new String[participatingTraders.size()]; 
				int j = 0; for(Agent a : participatingTraders){
					pt[j] = a.getName();
					j++;
				}
				participatingAgents.setListData( pt );
				scrollpa.revalidate();	scrollpa.repaint();
				
				String[] uw = new String[unwillingTraders.size()]; 
				j = 0; for(Agent a : unwillingTraders){
					uw[j] = a.getName();
					j++;
				}
				unwillingAgents.setListData( uw );
				scrolluw.revalidate(); scrolluw.repaint();
				
				String[] ta = new String[temporarilyFullyAllocated.size()]; 
				j = 0; for(Agent a : temporarilyFullyAllocated){
					ta[j] = a.getName();
					j++;
				}
				temporarilyAllocatedAgents.setListData( ta );
				scrollts.revalidate(); scrollts.repaint();
				
				// update the market status
				marketStatus.setText("B:"+status.buyQuote+", A:"+status.sellQuote);
				
				// update the orderbook
				Object[][] bids = new Object[buyOffersData.size()][buyOffersData.size() > 0 ? columns_buyOffers.length : 0];
				Object[][] asks = new Object[sellOffersData.size()][sellOffersData.size() > 0 ? columns_sellOffers.length : 0];
				Object[][] matches = new Object[matchedOffersData.size()][matchedOffersData.size() > 0 ? columns_matchedOffers.length : 0];
				
				//Collections.sort(buyOffersData, new Offer.OrderPriceDesc()); useless!
				SimpleDateFormat format = new SimpleDateFormat("yyyy MMM dd HH:mm:ss");
				
				// fill the tables according to the given data
				for(int i = 0; i < buyOffersData.size(); i++){
					bids[i][0] = buyOffersData.get(i).agent.getName();
					bids[i][1] = buyOffersData.get(i).amount;
					bids[i][2] = buyOffersData.get(i).price;
					bids[i][3] = buyOffersData.get(i).delayTolerance;
					bids[i][4] = format.format(buyOffersData.get(i).timestamp.getTime())+"_"+buyOffersData.get(i).iteration;
					bids[i][5] = buyOffersData.get(i).getTypeAsString();
				}
				Table b = new Table(columns_buyOffers, bids);
				buyOffers.setModel(b);
				b.fireTableDataChanged();
				
				for(int i = 0; i < sellOffersData.size(); i++){
					asks[i][0] = sellOffersData.get(i).agent.getName();
					asks[i][1] = sellOffersData.get(i).amount;
					asks[i][2] = sellOffersData.get(i).price;
					asks[i][3] = sellOffersData.get(i).getTypeAsString();
				}
				Table s = new Table(columns_sellOffers, asks);
				sellOffers.setModel(s);
				s.fireTableDataChanged();
				
				for(int i = 0; i < matchedOffersData.size(); i++){
					matches[i][0] = matchedOffersData.get(i).seller.getName();
					matches[i][1] = matchedOffersData.get(i).buyer.getName();
					matches[i][2] = matchedOffersData.get(i).amount;
					matches[i][3] = matchedOffersData.get(i).price;
					matches[i][4] = matchedOffersData.get(i).type;
				}
				Table m = new Table(columns_matchedOffers, matches);
				matchedOffers.setModel(m);
				m.fireTableDataChanged();
				
			}
	    });
		
		// stop the simulation thread here until the button next iteration is pressed
	}

	
	class Table extends AbstractTableModel {

		private static final long serialVersionUID = -3033760460531030787L;

		private String[] columnNames;
		private Object[][] table = null;
		
		
		public Table(String[] columnNames, Object[][] table){
			this.columnNames = columnNames;
			this.table = table;
		}
		
		public Table(String[] columnNames, int r, int c) {
			this.columnNames = columnNames;
			table = new Object[r][c];
		}
		
		@Override
		public int getColumnCount() {
			return columnNames.length;
		}

		@Override
		public int getRowCount() {
			return table.length;
		}

		@Override
		public Object getValueAt(int r, int c) {
			return table[r][c];
		}
		
		@Override
		public String getColumnName(int col) {
            return columnNames[col];
        }

		@Override
		public void setValueAt(Object obj, int r, int c) {
			table[r][c] = this.getColumnClass(c).cast(obj);
		}
		
		@Override
		public Class getColumnClass(int col) {
            return getValueAt(0, col).getClass();
        }
	}	
	
	// TEst
	public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
			public void run() {
            	//MarketView view = MarketView.getInstance();
            	MarketView view = new MarketView();
            	view.setVisible(true);
            }
        });
    }
}
