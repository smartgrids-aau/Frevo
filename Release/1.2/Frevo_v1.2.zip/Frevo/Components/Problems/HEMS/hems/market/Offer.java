package hems.market;

import hems.devices.Agent;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;

public class Offer implements Comparable<Offer>{
	
	public int iteration;		// arrival iteration
	public Calendar timestamp;	// arrival timestamp
	public int amount;			// power (requested)
	public double price;		// unit price (euro KWh)
	
	public boolean isBIDtype;	// true = bid, false = ask
	
	public Agent agent;
	
	public int delayTolerance;	// max amount of time before the value drops (left time)
	
	// protected
	public enum OfferType{
		IDLE, REGULAR;
		static public final Integer lenght = 1 + REGULAR.ordinal();
	}
	
	protected String[] types = {"IDLE", "REGULAR"};
	
	protected OfferType offerType;
	
	/**
	 * Creates an offer for a flexible device
	 * @param amount
	 * @param price
	 * @param type
	 * @param agent
	 * @param timestamp
	 */
	public Offer(int amount, double price, boolean type, Agent agent, Calendar timestamp){
		this.amount = amount;
		this.price = price;
		
		this.isBIDtype = type;
		this.agent = agent;
		
		this.timestamp = Calendar.getInstance();	// using the simulationTime object might create problems, let's clone it
		this.timestamp.setTimeInMillis(timestamp.getTimeInMillis());
		
		this.offerType = OfferType.REGULAR;
	}
	
	/**
	 * Creates an offer for a flexible device
	 * @param amount
	 * @param price
	 * @param type
	 * @param agent
	 * @param timestamp
	 * @param delayTolerance
	 */
	public Offer(int amount, double price, boolean type, Agent agent, Calendar timestamp, int delayTolerance){
		this.amount = amount;
		this.price = price;
		
		this.isBIDtype = type;
		this.agent = agent;
		
		this.timestamp = Calendar.getInstance();	// using the simulationTime object might create problems, let's clone it
		this.timestamp.setTimeInMillis(timestamp.getTimeInMillis());
		
		this.offerType = OfferType.REGULAR;
		
		// -------------------------------------------
		this.delayTolerance = delayTolerance;
	}
	
	public void decreaseTolerance(){
		this.delayTolerance--;
	}
	
	public OfferType getOfferType(){
		return offerType;
	}

	public String getTypeAsString(){
		return types[offerType.ordinal()];
	}
	
	public boolean isRegular(){
		return this.offerType == OfferType.REGULAR;
	}
	
	public boolean isIdle(){
		return this.offerType == OfferType.IDLE;
	}
	
	public void setIdleOffer(){
		this.offerType = OfferType.IDLE;
	}
	
	/**
	 * Return a negative if the object is less than the given, zero if equal and a positive integer if greater than the given
	 * Compares two offers by their price (1st key), time (2nd) and iteration (3rd key)
	 */
	@Override
	public int compareTo(Offer o) {
		int compare = 0;
		
		// return a value indicating the difference of price
		if(this.price > o.price){
			compare = 1;
		}
		else if(this.price < o.price){
			compare = -1;
		}
		else{
			compare = 0;
		}
		return compare;
	}
	
	public static int compareUsingFurtherKeys(Offer a, Offer b){
		int compare = 0;
		// older offers first
		if(a.timestamp.getTimeInMillis() < b.timestamp.getTimeInMillis()){
			compare = 1;
		}else if(a.timestamp.getTimeInMillis() > b.timestamp.getTimeInMillis()){
			compare = -1;
		}else{
			// offers from older iterations first
			if(a.iteration > b.iteration){
				compare = 1;
				//System.out.println(a.iteration+" < "+b.iteration);
			}else if(a.iteration < b.iteration){
				compare = -1;
				//System.out.println(a.iteration+" > "+b.iteration);
			}else{
				compare = 0;
				//System.out.println(a.iteration+" == "+b.iteration);
			}
		}
		return compare;
	}
	
	public static class OrderPriceDesc implements Comparator<Offer>{
		@Override
		public int compare(Offer a, Offer b) {
			int compare = (int) Math.signum(a.compareTo(b)) * (-1);
			
			if(compare == 0){
				compare = compareUsingFurtherKeys(a, b);
			}
			
			return compare;
		}
	}
	
	public static class OrderPriceAsc implements Comparator<Offer>{
		@Override
		public int compare(Offer a, Offer b) {
			int compare = (int) Math.signum(a.compareTo(b));

			if(compare == 0){
				compare = compareUsingFurtherKeys(a, b);
			}
			
			return compare;
		}
	}	
	
	public static void main (String[] args){
		SimpleDateFormat format = new SimpleDateFormat("yyyy MM dd HH:mm:ss");
		Calendar atime = Calendar.getInstance();
		Calendar btime = Calendar.getInstance();
		try { 
			atime.setTime(format.parse("2013 01 01 07:51:00"));
			btime.setTime(format.parse("2013 01 01 07:51:00"));
		} catch (ParseException e) { e.printStackTrace(); }
		Offer a = new Offer(5, 0.5,true, null, atime);
		a.iteration = 1;
		Offer b = new Offer(5, 0.5,true, null, btime);
		b.iteration = 3;
		
		System.out.println(a.compareTo(b));
		
		ArrayList<Offer> orderbook = new ArrayList<Offer>();
		orderbook.add(a);
		orderbook.add(b);
		
		System.out.println("Ordering DESC, like in BID orderbook");
		Collections.sort(orderbook, new Offer.OrderPriceDesc());
		for(Offer o : orderbook){
			System.out.println("- "+format.format(o.timestamp.getTime())+"_"+o.iteration+":"+o.amount+","+o.price);
		}
		System.out.println("Ordering ASC, like in ASK orderbook");
		Collections.sort(orderbook, new Offer.OrderPriceAsc());
		for(Offer o : orderbook){
			System.out.println("- "+format.format(o.timestamp.getTime())+"_"+o.iteration+":"+o.amount+","+o.price);
		}
	}
}