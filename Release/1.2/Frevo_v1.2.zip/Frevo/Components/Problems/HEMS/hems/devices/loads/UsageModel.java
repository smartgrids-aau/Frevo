package hems.devices.loads;

import hems.devices.modelManager.ModelManager;
import hems.devices.modelManager.RemoteManagerUanavailableException;

import java.util.Calendar;

public class UsageModel {
	
	// ---- Appliance usage profile ----
	protected int operationsInCurrentInterval;
	protected long currentIntervalBeginning;
		
	// Random devices have a use probability that decays after operating the device
	protected double useProbability; 
	protected double willingnessDecay;
		
	// Modeled lookup devices have a timeOfUseProbability with a time-specific decay
	protected double[] timeOfUseProbability;
	protected double[] timeOfUseWillingnessDecay;
	
	protected ModelManager modelManagerReference;
	protected String modelRemotePosition;
	
	protected enum DevType{
		GREEDY, 
		RANDOM,
		LOOKUP, MODELED;
		static public final Integer lenght = 1 + MODELED.ordinal();
	}
	
	protected DevType deviceType;
	
	// ******************************************** Methods ***************************************************
	public UsageModel(){
		this.operationsInCurrentInterval = 0;

	}
	
	public UsageModel clone(){
		UsageModel copy = new UsageModel();
		
		copy.useProbability = this.useProbability;
		copy.willingnessDecay = this.willingnessDecay;
		
		copy.timeOfUseProbability = this.timeOfUseProbability;
		copy.timeOfUseWillingnessDecay = this.timeOfUseWillingnessDecay;
		
		copy.deviceType = this.deviceType;
		
		return copy;
	}
	
	// ********* Builders for specific device types
	@Deprecated
	public void buildGreedy(){
		deviceType = DevType.GREEDY;
		useProbability = 1.0;
	}
	
	public void buildRandom(double useProbability, double willingnessDecay){
		deviceType = DevType.RANDOM;
		this.useProbability = useProbability;
		this.willingnessDecay = willingnessDecay;
	}

	public void buildLookup(double[] timeOfUseProbability, double[] timeOfUseWillingnessDecay) throws  ProfileErrorException{
		deviceType = DevType.LOOKUP;
		this.timeOfUseProbability = timeOfUseProbability;
		this.timeOfUseWillingnessDecay = timeOfUseWillingnessDecay;
				
		// check if the power profile has a correct structure
		if(timeOfUseProbability.length != 24			// hourly-daily 
				&& timeOfUseProbability.length != 96	// quartely-daily
				&& timeOfUseProbability.length != 168 	// hourly-weekly
				&& timeOfUseProbability.length != 672	// quarterly-weekly
				&& timeOfUseProbability.length != 8760)	// hourly-yearly
			throw new ProfileErrorException("Error! The lenght ("+timeOfUseProbability.length+") does not correspond to any allowed profile structure.");
	}
	
	// Gets an object connecting the profile to the simulator
	public void buildModeled(ModelManager reference, String modelRemotePosition){
		deviceType = DevType.MODELED;
		this.modelManagerReference = reference;
		this.modelRemotePosition = modelRemotePosition;
	}
	
	// ********* Update interval at each iteration
	public void updateInterval(Calendar currentTime){
		// ---- Update the current time interval under which the device is operating to update its willingness to start ----
		/* smart way to check the edge between one hour and the next
		if(this.currentInterval != currentTime.get(Calendar.HOUR_OF_DAY)) this.operationsInCurrentInterval = 0;		// clean operations for the interval that just concluded
		this.currentInterval = currentTime.get(Calendar.HOUR_OF_DAY);												// set the current time interval
		*/
		long current = currentTime.getTimeInMillis() / 1000;
		
		// at the beginning of the simulation the currentIntervalBeginning is not initialised and therefore refer to 1970 (starting epoch)
		// which will force the reset of operations in the first interval and the initialization of the device willingness
		
		switch(deviceType){
			case GREEDY:
				// hourly-based reset
				if(current - currentIntervalBeginning > 3600){
					this.operationsInCurrentInterval = 0;
					this.currentIntervalBeginning = current;
				}
				break;
				
			case RANDOM:
				// hourly-based reset
				if(current - currentIntervalBeginning > 3600){
					this.operationsInCurrentInterval = 0;
					this.currentIntervalBeginning = current;
				}
				break;
				
			case LOOKUP:
				// hourly-daily, hourly-weekly, hourly-yearly
				if(timeOfUseProbability.length == 24 || timeOfUseProbability.length == 168 || timeOfUseProbability.length == 8760){
					if(current - currentIntervalBeginning > 3600){
						this.operationsInCurrentInterval = 0;
						this.currentIntervalBeginning = current;
					}
				}// quarterly-daily, quarterly-weekly
				else if(timeOfUseProbability.length == 96 || timeOfUseProbability.length == 672){
					if(current - currentIntervalBeginning > 900){
						this.operationsInCurrentInterval = 0;
						this.currentIntervalBeginning = current;
					}
				}	
				break;
				
			case MODELED:
				// let's assume only hourly based models for now please
				if(current - currentIntervalBeginning > 3600){
					this.operationsInCurrentInterval = 0;
					this.currentIntervalBeginning = current;
				}
				break;
				
		}
	}
	
	/**
	 * Get the willingness to start an operation for the device over the current hour interval and given the previous operations in the same interval
	 * @param allocationTime
	 * @return probability to start
	 * @throws RemoteManagerUanavailableException 
	 */
	public double getInstantaneousWillingnessToStart(Calendar allocationTime) throws RemoteManagerUanavailableException{
		double willingnessToStart = 0.0;
		
		// for MODELED devices
		if(deviceType == DevType.LOOKUP){
			switch(timeOfUseProbability.length){
			case 24:
				int h = allocationTime.get(Calendar.HOUR_OF_DAY);
				// discount the willingness to the number of times already started for the same time interval (hour)
				willingnessToStart = timeOfUseProbability[h] * Math.pow(timeOfUseWillingnessDecay[h], operationsInCurrentInterval);
				// when 0, willingness = timeOfUseProbability[h]
				// when >0, willingness = timeOfUseProbability[h] * (willingnessDecay[h] ** operations)	
				
				willingnessToStart = 1.0 - Math.pow(1.0 - willingnessToStart, 1.0/3600.0);
				break;
			}
		}else if(deviceType == DevType.MODELED){
			// retrieve probability to start over the whole interval
			willingnessToStart = modelManagerReference.getStartingProbability(this.modelRemotePosition, allocationTime, operationsInCurrentInterval);
			//System.out.print("Received = "+willingnessToStart);
			// compute the willingness to start at the next timestamp
			willingnessToStart = 1.0 - Math.pow(1.0 - willingnessToStart, 1.0/3600.0);
			//System.out.println(", w*= "+willingnessToStart);
		}else{
			// non-MODELED devices have a useProbability defined at construction time
			// discount the willingness with the number of times already started during the same time interval (hours)
			willingnessToStart = this.useProbability * Math.pow(willingnessDecay, operationsInCurrentInterval);
			// when 0, willingness = useProbability
			// when >0, willingness = useProbability * (decay ** operations)
			willingnessToStart = 1.0 - Math.pow(1.0 - willingnessToStart, 1.0/3600.0);
		}
		
		return willingnessToStart;
	}
	
	public void addConcludedOperationForCurrentInterval(){
		this.operationsInCurrentInterval++;
	}

}
