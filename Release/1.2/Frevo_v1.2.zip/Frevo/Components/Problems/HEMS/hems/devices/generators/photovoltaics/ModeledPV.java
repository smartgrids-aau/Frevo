package hems.devices.generators.photovoltaics;

import hems.Debugger;

import java.util.Calendar;
import java.util.GregorianCalendar;

import hems.devices.generators.Generator;
import hems.devices.generators.weather.IntervalBasedWeather;
import hems.devices.generators.weather.Weather;

public class ModeledPV implements Generator {
	
	protected double latitude;
	protected double longitude;
	protected double size;		// size of the power plant
	protected double height;		// height above the see level
	protected double efficiency;	// efficiency of the plant
	
	protected double peakPower;

	public ModeledPV(double peakPower, double efficiency, double latitude, double longitude, double height, double size) {
		
		this.peakPower = peakPower;
		
		this.efficiency = efficiency;
		this.latitude = latitude;
		this.longitude = longitude;
		this.height = height;
		this.size = size;
	}
	
	@Override
	public double getCurrentProduction(Calendar date, Weather weather) {
		// This simple model of photovoltaic plant returns its production using predefined values
		double PVOutputPower = 0.0;
		double squareMeters = peakPower / (SolarCalculations.Wpeak_Intensity * efficiency);
        
		// get the sun angle
		AzimuthZenithAngle sun = PSA.calculateSolarPosition((GregorianCalendar) date, latitude, longitude);		
		double zenitAngle = sun.getZenithAngle();
		//System.out.println("Angle: "+zenitAngle);
	    
		double intensity = 0.0;
	    if(zenitAngle < 90)	intensity = SolarCalculations.getSolarIntensity(zenitAngle, height);
	    
	    // the sun factor is inversely to the amount of clouds
		//double sunFactor = 1.0 - weather.getCloudFactor(date);
	    double sunFactor = weather.getSunFactor(date);
		
		PVOutputPower = squareMeters * intensity  * efficiency * sunFactor;
		
		//System.out.println("PVOutput "+PVOutputPower);
		Debugger.println("\t\t PV production: Angle = "+zenitAngle+", Power = "+PVOutputPower);
		
		return PVOutputPower;
	}
}
