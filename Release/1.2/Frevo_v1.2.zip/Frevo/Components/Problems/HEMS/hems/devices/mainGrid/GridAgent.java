package hems.devices.mainGrid;

import hems.devices.Agent;
import hems.devices.generators.GenerationModel;
import hems.devices.generators.weather.Weather;
import hems.devices.loads.OperationModel;
import hems.devices.loads.TimeBasedConsumer;
import hems.market.Offer;

import java.util.Calendar;

public class GridAgent extends Agent{
	private double offeredASKPrice;
	private double offeredBIDPrice;
	
	public GridAgent(String name, double credit, 
			OperationModel operationModel,
			GenerationModel generationModel
			) {
		
		super(name, credit, operationModel, generationModel);
		
	}
	
	public Offer getASKOffer(Calendar simulationTime, Calendar allocationTime, Weather weather){
		
		this.offeredASKPrice = generationModel.getReservationPrice(allocationTime);
		
		return new Offer(
				(int) generationModel.getCurrentProduction(allocationTime, weather),
				offeredASKPrice,
				false,									// offer = ASK
				this,									// GridAgent
				simulationTime);						// arrival is currentSimTime
	}
	
	public Offer getBIDOffer(Calendar simulationTime, Calendar allocationTime, Weather weather){
	
		this.offeredBIDPrice = operationModel.getPriceSensitivity(allocationTime);
		
		int demand = 0;
		
		if(operationModel instanceof TimeBasedConsumer){
			demand = (int) ((TimeBasedConsumer) operationModel).getFutureDemand(simulationTime, allocationTime);
		}
		
		return new Offer(
				demand,
				offeredBIDPrice,
				true,
				this,
				simulationTime);
	}
	
	public GridAgent clone(){
		return new GridAgent(name, credit, 
							operationModel.clone(),
							generationModel);
	}
	
	// Grid connections are always able to put offers, as there will for sure be a smart meter
	public boolean isRunningItsController(){
		return true;
	}

	
	@Override
	public double computeFitness(double reward, double gridEnergySold,
			double gridEnergyCosts, double localEnergyCosts,
			double relDevStart, double relStateStart, double relInterruption,
			double unallocatedInflexibleBID, double unallocatedInflexibleASK,
			double violatingDeadline, double violatingMarket,
			double relForbiddenMarket, double violatingSensitivity,
			double relBIDLosses, double relASKLosses,
			double unpoweredController, double violatingNeeds,
			double relDoesNotReflectNeeds) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double getAverageOfferMarketDeviation() {
		return 0;
	}

	@Override
	public double getAverageDeviationFromNeeds() {
		return 0;
	}	
}
