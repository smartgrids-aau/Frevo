package SSEA2D;

import java.awt.Color;
import java.awt.GridLayout;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import main.FrevoMain;
import odk.lang.FastMath;

import org.dom4j.Document;
import org.dom4j.DocumentFactory;
import org.dom4j.Element;
import org.dom4j.Node;

import utils.NESRandom;
import utils.StatKeeper;
import core.AbstractMethod;
import core.AbstractRanking;
import core.AbstractRepresentation;
import core.ComponentType;
import core.ComponentXMLData;
import core.ProblemXMLData;
import core.XMLFieldEntry;
import frevoutils.JGridMap.Display;
import frevoutils.JGridMap.JGridMap;

/**
 * The class SSEA2D (Spatially Structured Evolutionary Algorithm 2D) is a
 * evolutionary algorithm that considers only the neighbors of every
 * representation to decide if the representation remains in the next
 * generation, mutates, creates an offspring with another representation or is
 * replaced by a totally new representation. The representations are arranged in
 * a two dimensional grid, where every representation has 8 neighbors.
 * 
 * @author Thomas Dittrich
 * 
 */
public class SSEA2D extends AbstractMethod {

	/**
	 * length of the population field. The population field is a square. So the
	 * number of representations is POPULATIONFIELDSIZE^2
	 */
	public int POPULATIONFIELDSIZE;
	/**
	 * number of representations in the population
	 */
	public int POPULATIONSIZE;
	/**
	 * mode how the neighborhood of a member is defined
	 */
	public int NEIGHBOURHOODMODE;
	/**
	 * number of generations
	 */
	private int GENERATIONS;
	/**
	 * interval between two intermediate saves
	 */
	private int SAVEINTERVAL;

	/**
	 * defines the shape of the curve which represents the correlation between
	 * the rank of the fitness in the Neighborhood and the severity of the
	 * mutation. This curve has the formula f=100*r^a. Where f is the severity
	 * of mutation, a is MUTATIONSEVERITYCURVE and r is the rank of the fitness
	 * in the neighborhood divided by the number of neighbors
	 */
	public int NUMBEROFNEIGHBORS;
	/**
	 * defines how many Members are elite. The percentage of elite-members is
	 * probably not that high because if a member is elite is not calculated
	 * over the whole field but only in his neighborhood. And so it is possible,
	 * that a member is above this percentage in the neighborhood of one of his
	 * neighbours but not in his own
	 */
	public float PERCENTELITE;
	/**
	 * defines how many Generations an elite-member must exist
	 */
	public int MINIMUMLIFETIMEELITE;
	/**
	 * defines the severity of the mutation</br> 0 ...... representation does
	 * not change</br>100 .. a totally new representation is generated
	 */
	public int MUTATIONSEVERITY;
	/**
	 * defines how many representations that are not elite create a mutation of
	 * a random elite-neighbor
	 */
	public int PERCENTMUTATEELITE;
	/**
	 * defines how many representations that are not elite create an offspring
	 * with a random elite-neighbor
	 */
	public int PERCENTXOVERELITE;

	private StatKeeper bfitness;
	private StatKeeper numSimulations;

	private Population pop;
	
	private double minfitness;
	
	private boolean iniOK = false;

	Display gridFrame;
	JGridMap fitnessgrid;

	/** Constructs a new SSEA2D object */
	public SSEA2D(NESRandom random) {
		super(random);
	}

	private void initialize(ProblemXMLData problemData, ComponentXMLData representation) {
		// Get properties
		XMLFieldEntry popsize = getProperties().get("populationsize");
		POPULATIONSIZE = Integer.parseInt(popsize.getValue());
	
		XMLFieldEntry neighborhoodmode = getProperties().get(
				"neighbourhoodmode");
		NEIGHBOURHOODMODE = Integer.parseInt(neighborhoodmode.getValue());
	
		XMLFieldEntry generations = getProperties().get("generations");
		GENERATIONS = Integer.parseInt(generations.getValue());
	
		XMLFieldEntry saveint = getProperties().get("saveinterval");
		SAVEINTERVAL = Integer.parseInt(saveint.getValue());
	
		XMLFieldEntry percentelite = getProperties().get("percentelite");
		PERCENTELITE = Integer.parseInt(percentelite.getValue());
	
		XMLFieldEntry mutationseverity = getProperties()
				.get("mutationseverity");
		MUTATIONSEVERITY = Integer.parseInt(mutationseverity.getValue());
	
		XMLFieldEntry percentmutateelite = getProperties().get(
				"percentmutateelite");
		PERCENTMUTATEELITE = Integer.parseInt(percentmutateelite.getValue());
	
		XMLFieldEntry percentxoverelite = getProperties().get(
				"percentxoverelite");
		PERCENTXOVERELITE = Integer.parseInt(percentxoverelite.getValue());
	
		// Start from scratch, no populations to load
		POPULATIONFIELDSIZE = (int) FastMath
				.rint(FastMath.sqrt(POPULATIONSIZE));
	
		// check population size
		if (POPULATIONSIZE != POPULATIONFIELDSIZE * POPULATIONFIELDSIZE) {
			if (FrevoMain.isFrevoWithGraphics())
				JOptionPane.showMessageDialog(null,
						"Populationsize has been changed to "
								+ (POPULATIONFIELDSIZE * POPULATIONFIELDSIZE));
			else {
				System.err.println("Populationsize has been changed to "
						+ (POPULATIONFIELDSIZE * POPULATIONFIELDSIZE));
			}
		}
	
		pop = new Population(representation, this, problemData.getRequiredNumberOfInputs(), problemData.getRequiredNumberOfOutputs());
	
		bfitness = new StatKeeper(true, "Best Fitness ("
				+ FrevoMain.getCurrentRun()+")", "Generations", true);
		
		numSimulations = new StatKeeper(true, "numSimulations"
				+ FrevoMain.getCurrentRun(), "Generations", false);
	
		// show fitness grid if in GUI mode
		if (FrevoMain.isFrevoWithGraphics()) {
			// initialize fitness grid
			if (gridFrame == null) {
				gridFrame = new Display(300, 300, "Spatial Fitness");
				gridFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				gridFrame.setLocation(0, 0);
			}
			if (fitnessgrid == null) {
				fitnessgrid = new JGridMap(200, 250, POPULATIONFIELDSIZE,
						POPULATIONFIELDSIZE, 1);
				// initialize color scale
				// 0....red
				// 50...yellow
				// 100..green
				for (int i = 0; i < 100; i++) {
					int r = 0;
					int g = 0;
					if (i < 50) {
						r = 255;
						g = i * 255 / 50;
					} else {
						r = 255 - (i - 50) * 255 / 50;
						g = 255;
					}
					int color = r * 65536 + g * 256;
					fitnessgrid.addColorToScale(i, new Color(color));
				}
			}
			gridFrame.setLayout(new GridLayout(1, 1));
			gridFrame.add(fitnessgrid);
			gridFrame.pack();
			gridFrame.setVisible(true);
		}
	}

	@Override
	public void runOptimization(ProblemXMLData problemData,
			ComponentXMLData representationData, ComponentXMLData rankingData,
			Hashtable<String, XMLFieldEntry> properties) {
		
		// initialize evolution
		initialize(problemData,representationData);
	
		//FrevoMain.addStatistics(index);
	
		// Collect best fitness
		FrevoMain.addStatistics(bfitness);
	
		FrevoMain.addStatistics(numSimulations);
	
		// iterate through all generations.
		for (int generation = 0; generation < GENERATIONS; generation++) {
			System.out.println("Proceeding to generation " + generation);
	
			// set progress
			setProgress((float) generation / (float) GENERATIONS);
	
			if (handlePause()) {
				// closes the window which holds the fitnessgrid
				if (gridFrame != null)
					gridFrame.dispose();
				fitnessgrid = null;
				gridFrame = null;
				return;
			}
	
			AbstractRanking ranking;
			try {
				ranking = rankingData.getNewRankingInstance();
				
				// evaluates all members and calculates the best fitness
				ArrayList<AbstractRepresentation> memberrepresentations = pop
						.getMembers();
				
				int numSims = ranking.sortCandidates(memberrepresentations, problemData,
						getRandom());
				
				bfitness.add(memberrepresentations.get(0).getFitness());
				
				numSimulations.add(numSims);
				
				if (FrevoMain.isFrevoWithGraphics()) {
					// shows the fitness of the whole population as a grid of
					// colors, where red means bad fitness and green means good
					// fitness
					updatefitnessgrid();
				}
			} catch (InstantiationException e) {
				e.printStackTrace();
			}
	
			boolean doSave = false;
			
			// save periodically
			if ((SAVEINTERVAL != 0) && (generation % SAVEINTERVAL == 0)) {
				doSave = true;
			}
			
			// save last generation
			if (generation == GENERATIONS-1) {
				doSave = true;
			}
			
			if (doSave) {
				DecimalFormat fm = new DecimalFormat("000");
				FrevoMain.saveResult(
						problemData.getName() + "_g" + fm.format(generation),
						saveResults(generation),this.seed);
			}
			
			if (handlePause()) {
				// closes the window which holds the fitnessgrid
				if (gridFrame != null)
					gridFrame.dispose();
				fitnessgrid = null;
				gridFrame = null;
				return;
			}
				
			// mutates all members of the population according to the
			// specified mutation rules (only if it's not the last
			// generation)
			if (generation != GENERATIONS - 1) {
				pop.evolve();
			}
		}
	
		// indicate final progress
		setProgress(100);
		
		// closes the window which holds the fitness grid
		if (FrevoMain.isFrevoWithGraphics()) {
			gridFrame.dispose();
			fitnessgrid = null;
			gridFrame = null;
		}
	}

	private static ArrayList<AbstractRepresentation> createList(Node nd) {
		ArrayList<AbstractRepresentation> result = new ArrayList<AbstractRepresentation>();
		
		ComponentXMLData representation = FrevoMain
				.getSelectedComponent(ComponentType.FREVO_REPRESENTATION);

		try {
			List<?> npops = nd.selectNodes("./*");
			Iterator<?> it = npops.iterator();
			int size = npops.size();
			int currentIndex = 0;
			while (it.hasNext()) {
				// set loading progress
				FrevoMain.setLoadingProgress((float)currentIndex / size);
				
				Node net = (Node) it.next();
				size--;
				if (size % 10 == 0)
					size = size + (2 * 2 - 4);
				AbstractRepresentation member = representation
						.getNewRepresentationInstance(0, 0, null);
				member.loadFromXML(net);
				result.add(member);
				
				currentIndex++;
			}
		} catch (InstantiationException e) {
			e.printStackTrace();
		}

		return result;
	}

	/** Saves all population data to a new XML element and returns it.*/
	public Element saveResults(int generation) {
		Element dpopulations = DocumentFactory.getInstance().createElement(
				"populations");
		
		dpopulations.addAttribute("count", String.valueOf(1));
		dpopulations.addAttribute("generation", String.valueOf(generation));
		dpopulations.addAttribute("randomseed", String.valueOf(this.getSeed()));

		Element dpop = dpopulations.addElement("population");
		pop.getMembers();

		// sort candidates with decreasing fitness
		Collections.sort(pop.getMembers(), Collections.reverseOrder());

		for (AbstractRepresentation n : pop.getMembers()) {
			n.exportToXmlElement(dpop);
		}
		
		return dpopulations;
	}

	@Override
	public ArrayList<ArrayList<AbstractRepresentation>> loadFromXML(Document doc) {
		// final list to be returned
		ArrayList<ArrayList<AbstractRepresentation>> populations = new ArrayList<ArrayList<AbstractRepresentation>>();
		
		// get population root node
		Node dpopulations = doc.selectSingleNode("/frevo/populations");
		
		// get population size
		List<?> npops = dpopulations.selectNodes(".//population");
		Iterator<?> it = npops.iterator();
		while (it.hasNext()) {
			Node pop = (Node) it.next();
			ArrayList<AbstractRepresentation> pops = createList(pop);
			populations.add(pops);
		}
		return populations;
	}

	/**
	 * displays the fitness of the actual population in a Grid
	 */
	private void updatefitnessgrid() {
		// determine maximum and minimum fitness
		ArrayList<AbstractRepresentation> rep = pop.getMembers();
		double maxfitness = rep.get(0).getFitness();
		if (!iniOK) {
			minfitness = rep.get(0).getFitness();
		}
		for (AbstractRepresentation r : rep) {
			if (r.isEvaluated()) {
				if (r.getFitness() > maxfitness) {
					maxfitness = r.getFitness();
				} else if (r.getFitness() < minfitness) {
					minfitness = r.getFitness();
				}
			}
		}
		// normalize fitness between 0 and 100
		double k = 100.0 / (maxfitness - minfitness);
		double d = -(minfitness * k);
		int[][] fitnessarray = new int[POPULATIONFIELDSIZE][POPULATIONFIELDSIZE];
		for (int x = 0; x < POPULATIONFIELDSIZE; x++) {
			for (int y = 0; y < POPULATIONFIELDSIZE; y++) {
				if (rep.get(x * POPULATIONFIELDSIZE + y).isEvaluated()) {
					int normfitness = (int) (rep.get(
							x * POPULATIONFIELDSIZE + y).getFitness()
							* k + d);
					fitnessarray[x][y] = normfitness;
				} else {
					fitnessarray[x][y] = 0;
				}
			}
		}
		// show normalized fitness in fitness grid
		fitnessgrid.setData(fitnessarray);
		fitnessgrid.repaint();
		iniOK = true;
	}
}
