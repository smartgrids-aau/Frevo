package SSEA2D;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import core.AbstractRepresentation;
import core.ComponentXMLData;

import main.FrevoMain;
import odk.lang.FastMath;
import utils.NESRandom;

/**
 * The class population represents the whole population for the evolutionary
 * algorithm SSEA2D. It contains all the representations and the function to
 * evolve a new generation.
 * 
 * @author Thomas Dittrich
 * 
 */
public class Population {

	Member[] members;
	int fieldlength;
	float mutationseveritycurve;
	int mutationseverity;
	int minimumlifetime;
	float percentelite;
	int percentmutateelite;
	int percentxoverelite;
	NESRandom rand;

	/**
	 * 
	 * @param representation
	 *            ComponentXMLdata which is used to create the Members. If this
	 *            constructor is called in a subclass of AbstractRepresentation the
	 *            variable representation should be handed over
	 * @param tde
	 *            Instance of TwoDimensionalEvolution which holds the properties
	 *            for each member. If this constructor is called in a subclass
	 *            of AbstractRepresentation the value this should be handed over
	 */
	public Population(ComponentXMLData representation, SSEA2D tde, int inputnumber, int outputnumber) {
		fieldlength = tde.POPULATIONFIELDSIZE;
		percentelite = tde.PERCENTELITE;
		mutationseverity = tde.MUTATIONSEVERITY;
		percentmutateelite = tde.PERCENTMUTATEELITE;
		percentxoverelite = tde.PERCENTXOVERELITE;
		members = new Member[fieldlength * fieldlength];

		for (int i = 0; i < members.length; i++) {
			members[i] = new Member(representation, tde, inputnumber, outputnumber);
		}

		if (tde.NEIGHBOURHOODMODE == 1) {
			SetGridneighborhood();
		} else if (tde.NEIGHBOURHOODMODE == 2) {
			SetRandomneighborhood(8);
		} else {
			SetGridneighborhood();
		}
		rand = new NESRandom(FrevoMain.getSeed());
	}

	/**
	 * Returns an ArrayList of IRepresentations which contains all the
	 * IRepresentations of the Members
	 * 
	 * @return ArrayList of IRepresentation
	 */
	public ArrayList<AbstractRepresentation> getMembers() {
		ArrayList<AbstractRepresentation> m = new ArrayList<AbstractRepresentation>();

		for (Member me : members) {
			m.add(me.rep);
		}

		return m;
	}

	/**
	 * Evolves the IRepresentation of every member according to the
	 * evolution-rules
	 */
	public void evolve() {
		// get diff to all neighbors
		for (int i = 0; i < members.length; i++) {
			members[i].diff = 0;
			int j = 0;
			double diff = 0.0;
			for (Member n : members[i].neighbors) {
				if (n.rep.getFitness() >= members[i].rep.getFitness()) {
					diff += members[i].rep.diffTo(n.rep);
					j++;
				}
			}
			members[i].diff = j>0 ? diff / j : 0.0;
		}

		AbstractRepresentation[] newmembers = new AbstractRepresentation[members.length];
		for (int i = 0; i < members.length; i++) {
			// ranks all the members in the neighborhood of member[i] according
			// to their fitness. The second condition for the ranking is the
			// difference to the neighbors (a member with a high difference to
			// all his neighbors is more likely to find a good solution for the
			// problem). The third condition is an ID that is unique.
			int fitnessrankneighborhood = 1;
			for (Member n : members[i].neighbors) {
				double f = members[i].rep.getFitness();
				double fn = n.rep.getFitness();
				long id = members[i].id;
				long idn = n.id;
				double d = members[i].diff;
				double dn = n.diff;
				if (fn > f) {
					fitnessrankneighborhood++;
				} else if (f == fn && dn > d) {
					fitnessrankneighborhood++;
				} else if (f == fn && dn == d && id > idn) {
					fitnessrankneighborhood++;
				}
			}

			if (fitnessrankneighborhood != 1) {
				float re = percentelite / 100.0f;
				// the highest rank that is still elite
				int rankelite = (int) FastMath
						.rint(((members[i].neighbors.size() + 1) * re));
				if (fitnessrankneighborhood > rankelite) { // not elite
					int geneticoperationrand = rand.nextInt(100);
					// create a mutation of one of the elite-neighbors
					if (geneticoperationrand < percentmutateelite) {
						ArrayList<AbstractRepresentation> elite = new ArrayList<AbstractRepresentation>();
						for (Member m : members[i].neighbors) {
							elite.add(m.rep);
						}
						Collections.sort(elite, Collections.reverseOrder());
						while (elite.size() > rankelite) {
							elite.remove(rankelite);
						}
						int elitemutate = rankelite > 1 ? rand
								.nextInt(rankelite - 1) : 0;
						newmembers[i] = elite.get(elitemutate).clone();
						newmembers[i].mutate(mutationseverity, 100, 1);
					} else
					// create an offspring with one of the elite neighbors
					if (geneticoperationrand < percentxoverelite
							+ percentmutateelite) {
						ArrayList<AbstractRepresentation> elite = new ArrayList<AbstractRepresentation>();
						for (Member m : members[i].neighbors) {
							elite.add(m.rep);
						}
						Collections.sort(elite, Collections.reverseOrder());
						while (elite.size() > rankelite) {
							elite.remove(rankelite);
						}
						int xoverpartner = rankelite > 1 ? rand
								.nextInt(rankelite - 1) : 0;
						newmembers[i] = members[i].rep.clone();
						newmembers[i].xOverWith(elite.get(xoverpartner), 1);
					} else { // create a new member
						newmembers[i] = members[i].rep.clone();
						newmembers[i].mutate(100, 100, 1);
					}
				} else { // do nothing
					newmembers[i] = members[i].rep;
				}
			} else { // do nothing
				newmembers[i] = members[i].rep;
			}
		}
		// copy the new members into the population
		for (int i = 0; i < members.length; i++) {
			members[i].rep = newmembers[i];
		}
	}

	/**
	 * Sets the neighbors for every member. The Neighbors of a member are those
	 * which are adjacent in the grid
	 */
	private void SetGridneighborhood() {
		for (int x0 = 0; x0 < fieldlength; x0++) {
			for (int y0 = 0; y0 < fieldlength; y0++) {
				for (int x1 = -1; x1 <= 1; x1++) {
					for (int y1 = -1; y1 <= 1; y1++) {
						if (x1 != 0 || y1 != 0) {
							int x = (x0 + x1 + fieldlength) % fieldlength;
							int y = (y0 + y1 + fieldlength) % fieldlength;
							members[x0 * fieldlength + y0].neighbors
									.add(members[x * fieldlength + y]);
						}
					}
				}
			}
		}
	}

	/**
	 * Sets the neighbors for every member. The Neighbors of a member are
	 * selected by random
	 */
	private void SetRandomneighborhood(int numberofneighbors) {
		Random r = new Random(0);
		for (int x0 = 0; x0 < fieldlength; x0++) {
			for (int y0 = 0; y0 < fieldlength; y0++) {
				for (int i = 0; i < numberofneighbors; i++) {

					int rand = r.nextInt(members.length);
					members[x0 * fieldlength + y0].neighbors.add(members[rand]);

				}
			}
		}
	}
}
