package nnga;

/*
 * Copyright (C) 2009 Istvan Fehervari, Wilfried Elmenreich
 * Original project page: http://www.frevotool.tk
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License Version 3 as published
 * by the Free Software Foundation http://www.gnu.org/licenses/gpl-3.0.txt
 *
 * There is no warranty for this free software. The GPL requires that 
 * modified versions be marked as changed, so that their problems will
 * not be attributed erroneously to authors of previous versions.
 */

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import main.FrevoMain;

import org.dom4j.Document;
import org.dom4j.DocumentFactory;
import org.dom4j.Element;
import org.dom4j.Node;

import utils.NESRandom;
import utils.StatKeeper;
import core.AbstractMethod;
import core.AbstractRanking;
import core.AbstractRepresentation;
import core.ComponentType;
import core.ComponentXMLData;
import core.ProblemXMLData;
import core.XMLFieldEntry;

/**
 * A genetic algorithm designed to evolve any kind of representation. Supports
 * multiple populations and several ranking systems.
 * 
 * @author Istvan Fehervari, Andreas Pfandler
 */
public class NNGA extends AbstractMethod {

	// Evolution parameters

	/** Number of parallel populations */
	private int POPULATIONNUMBER;
	/** Size of each population */
	private int POPULATIONSIZE;
	/** Number of generations to calculate */
	private int GENERATIONS;
	/** Severity of the mutations that occur */
	private float MUTATIONSEVERITY;
	/** Percentage of elite candidates in the whole population */
	private float P_ELITE;
	/** Number of elite candidates */
	private int N_ELITE;
	/** Percentage of randomly selected candidates in the next population */
	private float P_RANDOM;
	/** Number of randomly selected candidates in the next population */
	private int N_RANDOM;
	/** Number of mutated candidates in the next population */
	private int N_MUTATE;
	/** Percentage of mutated candidates in the next population */
	private float P_MUTATE;
	/** Number of randomly generated candidates in the next population */
	private int N_RENEW;
	/** Percentage of randomly generated candidates in the next population */
	private float P_RENEW;
	/**
	 * Percentage of new candidates created by recombination in the next
	 * population
	 */
	private float P_XOVER;
	/** Number of new candidates created by recombination in the next population */
	private int N_XOVER;
	/** Number of generations till an inter-population crossover happens */
	private int N_INTERXOVER_FREQ;
	/** The index of the mutation method to be used */
	private int MUTATIONMETHOD;
	/** The index of the recombination method to be used */
	private int XOVERMETHOD;
	/** Indicates after how many generations should a saving occur */
	private int SAVEINTERVAL;

	/** Indicates if improvements should be saved */
	private boolean SAVEIMPROVEMENTS = false;

	/** List of lists containing the candidates sorted in populations */
	private LinkedList<SimplePopulation> pops = new LinkedList<SimplePopulation>();

	/** Entries contain the best fitness over all populations */
	private StatKeeper bestFitnessStats;

	/** Constructs a new NNGA class */
	public NNGA(NESRandom random) {
		super(random);
	}

	/** Initializes the method by loading all parameters */
	private void initialize() {
		// Load the number of populations
		XMLFieldEntry popnum = getProperties().get("populationnumber");
		POPULATIONNUMBER = Integer.parseInt(popnum.getValue());

		// Load population size
		XMLFieldEntry popsize = getProperties().get("populationsize");
		POPULATIONSIZE = Integer.parseInt(popsize.getValue());

		// Load the number of generations
		XMLFieldEntry gensize = getProperties().get("generations");
		GENERATIONS = Integer.parseInt(gensize.getValue());

		// Load save interval
		XMLFieldEntry saveint = getProperties().get("saveinterval");
		SAVEINTERVAL = Integer.parseInt(saveint.getValue());

		// Load improvement saving flag
		XMLFieldEntry saveimp = getProperties().get("saveImprovements");
		SAVEIMPROVEMENTS = Boolean.parseBoolean(saveimp.getValue());

		// Load elite percentage
		XMLFieldEntry p_elite = getProperties().get("percentage_elite");
		P_ELITE = Float.parseFloat(p_elite.getValue());

		// Load random percentage
		XMLFieldEntry p_random = getProperties().get("percentage_random");
		P_RANDOM = Float.parseFloat(p_random.getValue());

		// Load the percentage of mutated copies
		XMLFieldEntry p_mutate = getProperties().get("percentage_mutate");
		P_MUTATE = Float.parseFloat(p_mutate.getValue());

		// Load the percentage of newly rolled offsprings
		XMLFieldEntry p_renew = getProperties().get("percentage_renew");
		P_RENEW = Float.parseFloat(p_renew.getValue());

		// Load the percentage of recombined offsprings
		XMLFieldEntry p_xover = getProperties().get("percentage_xover");
		P_XOVER = Float.parseFloat(p_xover.getValue());

		// Load the frequency of inter-population crossover
		XMLFieldEntry n_inter = getProperties().get("interXover_frequency");
		N_INTERXOVER_FREQ = Integer.parseInt(n_inter.getValue());

		// Load the default mutation method
		XMLFieldEntry mm = getProperties().get("mutationMethod");
		MUTATIONMETHOD = Integer.parseInt(mm.getValue());

		// Load the default recombination method
		XMLFieldEntry xm = getProperties().get("xoverMethod");
		XOVERMETHOD = Integer.parseInt(xm.getValue());

		// Load mutation severity
		XMLFieldEntry ms = getProperties().get("mutationseverity");
		MUTATIONSEVERITY = Float.parseFloat(ms.getValue());

		// calculate numbers based on percentages
		N_ELITE = (int) (POPULATIONSIZE * P_ELITE);
		N_RANDOM = (int) (POPULATIONSIZE * P_RANDOM);
		N_MUTATE = (int) (POPULATIONSIZE * P_MUTATE);
		N_RENEW = (int) (POPULATIONSIZE * P_RENEW);
		N_XOVER = (int) (POPULATIONSIZE * P_XOVER);

		// fix rounding errors
		int roundingError = POPULATIONSIZE - N_ELITE - N_RANDOM - N_MUTATE
				- N_RENEW - N_XOVER;

		N_ELITE += roundingError;
	}

	@Override
	public void runOptimization(ProblemXMLData problemData,
			ComponentXMLData representationData, ComponentXMLData rankingData,
			Hashtable<String, XMLFieldEntry> properties) {
		// load and calculate parameters
		initialize();

		// obtain problem requirements
		int inputnumber = problemData.getRequiredNumberOfInputs();
		int outputnumber = problemData.getRequiredNumberOfOutputs();

		// generate initial population(s)
		for (int i = 0; i < POPULATIONNUMBER; i++) {
			pops.add(new SimplePopulation(POPULATIONSIZE, representationData,
					getRandom(), inputnumber, outputnumber));
		}

		// create statistics
		bestFitnessStats = new StatKeeper(true, "Best Fitness ("
				+ FrevoMain.getCurrentRun() + ")", "Generations", true);

		// register statistics
		FrevoMain.addStatistics(bestFitnessStats);

		// record the best fitness over the evolution
		double best_fitness = Double.MIN_VALUE;

		// Iterate through generations
		for (int generation = 0; generation < GENERATIONS; generation++) {
			System.out.println("Proceeding to generation " + generation);

			// check for pause flag
			if (handlePause())
				return;

			// sets our current progress
			setProgress((float) generation / (float) GENERATIONS);

			// indicates if we have to save this generation
			boolean saveThisGeneration = false;

			// Rank each population using the provided ranking
			AbstractRanking ranking;
			try {
				ranking = rankingData.getNewRankingInstance();

				// record the best fitness over all populations
				double best_fitness_pop = Double.MIN_VALUE;

				for (SimplePopulation pop : pops) {

					// check for pause flag
					if (handlePause())
						return;

					// sort population
					ranking.sortCandidates(pop.getMembers(), problemData,
							getRandom());

					if (pop.getBestCandidate().getFitness() > best_fitness_pop)
						best_fitness_pop = pop.getBestCandidate().getFitness();
				}

				// add the best fitness of this generation to statistics
				bestFitnessStats.add(best_fitness_pop);

				// note, if there was an improvement (includes 0th generation)
				if (best_fitness_pop > best_fitness) {
					best_fitness = best_fitness_pop;
					// indicate saving
					if (SAVEIMPROVEMENTS)
						saveThisGeneration = true;
				}
			} catch (InstantiationException e) {
				e.printStackTrace();
			}

			// check periodic save
			if ((SAVEINTERVAL != 0) && (generation % SAVEINTERVAL == 0)) {
				saveThisGeneration = true;
			}

			// check last generation
			if (generation == GENERATIONS - 1) {
				saveThisGeneration = true;
			}

			// save generation
			if (saveThisGeneration) {
				DecimalFormat fm = new DecimalFormat("000");
				FrevoMain.saveResult(
						problemData.getName() + "_g" + fm.format(generation),
						saveResults(generation),this.seed);
			}

			// Mutate all populations except when this is the last generation
			if (generation != GENERATIONS - 1) {
				for (int j = 0; j < POPULATIONNUMBER; j++) {
					evolvePopulation(pops.get(j), generation);
				}
			}

		}

		// finalize progress
		setProgress(100f);
	}

	/** Initiates offspring creation on the provided populations */
	private void evolvePopulation(SimplePopulation pop, int generation) {
		// track current position in the new array
		int position = 0;

		// temporary copy array for new candidates
		AbstractRepresentation[] nets = pop.getNetArray();

		// keep elite
		for (int i = position; i < N_ELITE; i++) {
			// Best Logging, (legacy code)
			// nets[i].getGAHistory().setEntry(generation,GAHistory.ELITE,nets[i].getRank(),nets[i].getScore());
		}
		position = N_ELITE;

		// select randomly, probability should be higher for better-ranked
		// individuals
		for (int i = position; i < position + N_RANDOM; i++) {
			int randrange;
			int startind;

			// number of nets that are considered based on maximum diversity to
			// individuals already considered so far 
			
			// HINT: set this value to one to turn off this feature
			int diffsearch = 5;
			
			// TODO: calculation of startind bugged!
			// create a triangle distribution by adding two independent
			// randoms
			randrange = POPULATIONSIZE - 1 - (i + diffsearch - 1);
			startind = rndIndex(randrange) + rndIndex(randrange - 1)
					- (randrange - 1);

			if (startind < 0)
				startind = -startind;

			startind += i;

			double bestdiff = -1;
			int srcind = startind;

			for (int j = startind; j < startind + diffsearch; j++) {
				double diff = 1;
				// calculate product of diffs of all nets selected so far (0
				// to i-1)
				for (int k = 0; k < i; k++)
					diff *= nets[j].diffTo(nets[k]);
				if (diff > bestdiff) {
					bestdiff = diff;
					srcind = j;
				}
			}

			AbstractRepresentation temp = nets[i];
			nets[i] = nets[srcind];
			nets[srcind] = temp;
			// //History log
			// nets[i].getGAHistory().setEntry(generation,GAHistory.LUCKY,nets[i].getRank(),nets[i].getScore());
		}
		position += N_RANDOM;

		int survivors = position;

		// create mutated copies of selected nets
		for (int i = position; i < position + N_MUTATE; i++) {
			int srcind = rndIndex(survivors);
			nets[i] = nets[srcind].clone();
			nets[i].mutate(MUTATIONSEVERITY, 0.1f, MUTATIONMETHOD);
			// //History log
			// nets[i].getGAHistory().setEntry(generation,GAHistory.MUT,nets[i].getRank(),nets[i].getScore());

			// nets[i].setScore(0);
			// //log.println("diff after mutation "+nets[i].diffTo(nets[srcind]));
		}
		position += N_MUTATE;

		int trials = 100; // used to avoid endless loops
		int ii;
		// create offsprings between two individuals
		for (ii = position; ii < position + N_XOVER; ii++) {
			AbstractRepresentation mother, father;
			SimplePopulation fatherpop;
			int motherindex, fatherindex;// + type

			motherindex = rndIndex(N_ELITE + N_RANDOM);
			mother = nets[motherindex];

			if (pops.size() > 1 && generation % N_INTERXOVER_FREQ == 0) {
				// Xover between different Populations
				fatherpop = pops.get(rndIndex(POPULATIONNUMBER));
				// type = GAHistory.POPXOVER;
			} else {
				// Xover within the same Population
				fatherpop = pop;
				// type = GAHistory.XOVER;
			}

			// search for partner with highest diversity
			int candindex;
			double bestDiff, candDiff;
			AbstractRepresentation cand;

			fatherindex = rndIndex(N_ELITE + N_RANDOM);
			father = fatherpop.getNetArray()[fatherindex];
			bestDiff = mother.diffTo(father);

			for (int j = 0; j < 10; j++) {
				candindex = rndIndex(N_ELITE + N_RANDOM);
				cand = fatherpop.getNetArray()[candindex];
				candDiff = mother.diffTo(cand);

				if (candDiff > bestDiff) {
					fatherindex = candindex;
					father = cand;
					bestDiff = candDiff;
				}
			}

			nets[ii] = mother.clone();

			// calculate Xover area in chromosom
			/*
			 * int noninodes = config.getIntValue("nn.nodes")-config.getIntValue
			 * ("nn.inputnodes"); int nncount = rndIndex(noninodes-1)+1;
			 * //minimum 1, maximum all but 1 int startcpy =
			 * config.getIntValue("nn.inputnodes") + rndIndex(noninodes);
			 */

			// create offsprings
			boolean isNew = true;
			nets[ii].xOverWith(father, XOVERMETHOD);
			// check if this net exist already in the pool
			for (int j = 0; j < ii; j++) {
				if (nets[ii].diffTo(nets[j]) == 0) {
					isNew = false;
					// log.println("gen:"+generation+": we found a double");
					break;
				}
			}
			if (isNew == false) {
				if (trials-- == 0)
					break;
				ii--; // redo this net
			} else {
				// nets[i].getGAHistory().setEntry(generation,type,nets[i].getRank(),nets[i].getScore(),father.getRank());
				// nets[i].setScore(0);
			}

		}
		position = ii;
		// position += N_XOVER;

		// for the remaining slots create some new individuals with random
		// parameters
		if (position + N_RENEW != nets.length)
			System.err.println("Warning! Filling "
					+ (nets.length - (position + N_RENEW))
					+ " positions with random candidates.");
		for (int i = position; i < nets.length; i++) {
			// GAHistory h = nets[i].getGAHistory();
			try {
				nets[i] = pop.genNewNetwork();
			} catch (InstantiationException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			}

			// nets[i].setGAHistory(h);
			// History log
			// nets[i].getGAHistory().setEntry(generation,GAHistory.RENEW,i,0);

			// nets[i].setScore(0);
		}
		position += N_RENEW;

		// System.out.println("\nposition is now "+position);
		pop.readNetArray(nets); // write back netarray to population

	}

	/** Saves all population data to a new XML element and returns it.*/
	public Element saveResults(int generation) {
		Element dpopulations = DocumentFactory.getInstance().createElement(
				"populations");
		
		dpopulations.addAttribute("count", String.valueOf(POPULATIONNUMBER));
		dpopulations.addAttribute("generation", String.valueOf(generation));
		dpopulations.addAttribute("randomseed", String.valueOf(this.getSeed()));
		
		for (SimplePopulation pop : pops) {
			pop.exportXml(dpopulations);
		}
		
		return dpopulations;
	}

	/** Returns a random index within the given range */
	private int rndIndex(int range) {
		if (range < 1)
			return 0;

		return generator.nextInt(Integer.MAX_VALUE) % range;
	}

	@Override
	public ArrayList<ArrayList<AbstractRepresentation>> loadFromXML(Document doc) {
		// final list to be returned
		ArrayList<ArrayList<AbstractRepresentation>> populations = new ArrayList<ArrayList<AbstractRepresentation>>();

		// get population root node
		Node dpopulations = doc.selectSingleNode("/frevo/populations");
		
		// get number of populations
		int populationCount = Integer
				.parseInt(dpopulations.valueOf("./@count"));

		// get population size
		@SuppressWarnings("unchecked")
		List<? extends Node> populationsNode = dpopulations
				.selectNodes(".//population");
		int populationSize = populationsNode.get(0).selectNodes("*").size();

		// calculate total representations
		int totalRepresentations = populationCount * populationSize;
		int currentPopulation = 0;
		int currentRepresentation = 0;

		// Iterate through the population nodes
		Iterator<?> populationIterator = populationsNode.iterator();
		while (populationIterator.hasNext()) {
			Node populationNode = (Node) populationIterator.next();
			
			// create list of candidate representations for this population
			ArrayList<AbstractRepresentation> result = new ArrayList<AbstractRepresentation>();
			
			// track current progress
			currentRepresentation = 0;
			try {
				// Obtain an iterator over the representations
				List<?> representations = populationNode.selectNodes("./*");
				Iterator<?> representationsIterator = representations
						.iterator();
				
				while (representationsIterator.hasNext()) {
					// calculate current position for progress reporting
					int currentItem = currentPopulation * populationSize
							+ currentRepresentation + 1;
					
					// report loading state
					FrevoMain.setLoadingProgress((float) currentItem
							/ totalRepresentations);
					
					// step to next node
					Node net = (Node) representationsIterator.next();

					// construct representation based on loaded representation data
					ComponentXMLData representation = FrevoMain
							.getSelectedComponent(ComponentType.FREVO_REPRESENTATION);
					AbstractRepresentation member = representation
							.getNewRepresentationInstance(0, 0, null);
					
					// load representation data from the XML into the instance
					member.loadFromXML(net);
					
					// add data to current population list
					result.add(member);
					
					// increment tracker
					currentRepresentation++;
				}
			} catch (InstantiationException e) {
				e.printStackTrace();
			}

			populations.add(result);

			currentPopulation++;
		}
		return populations;
	}
}
