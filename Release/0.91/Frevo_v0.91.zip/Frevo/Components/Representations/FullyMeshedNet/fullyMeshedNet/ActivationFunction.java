package fullyMeshedNet;

public enum ActivationFunction {
	LINEAR,
	SIGMOID
}
