package fsm;

public enum DistanceCalc {
	HAMMING_DISTANCE,
	MAX_EQUAL_PREFIX
}
