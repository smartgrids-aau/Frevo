package fsm;

import fsm.ThresholdedIntegerInput.MutationType;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import org.dom4j.Element;
import org.dom4j.Node;

import core.XMLFieldEntry;

import utils.NESRandom;


public class InputMapper {
	
	enum Defaults{
		DEFAULT_MIN(0),
		DEFAULT_MAX(100),
		DEFAULT_NUNIT(100);
		
		int value;
		Defaults(int value){
			this.value = value;
		}
		
		public int getValue(){
			return value;
		}
	}
	
	private NESRandom generator;
	private int nInput;		
	private int maxInputValues; // limit from where threshold is applied
	private int[] thresholdIds;
	private IntegerInput[] inputs;
	private Hashtable<String, XMLFieldEntry> properties;
	
	private static boolean showLoadError = true; 
	
	public InputMapper(Hashtable<String, XMLFieldEntry> properties, NESRandom generator, int nInput, int maxInputValues){
		this.nInput    = nInput;
		this.maxInputValues = maxInputValues;
		this.inputs     = new IntegerInput[nInput];
		this.generator  = generator;
		this.properties = properties;
		
		try{
			loadProperties();
		} catch (Exception ex){
			if (showLoadError)
				System.err.println ("Couldn't load input related properties, using defaults (all input thresholded)!");
			loadDefaultProperties();
		}
	}
	
	private InputMapper(NESRandom generator, int nInput, int maxInputValues){
		this.nInput    = nInput;
		this.maxInputValues = maxInputValues;
		this.generator = generator;
		this.inputs     = new IntegerInput[nInput];
		
		loadDefaultProperties();
	}
	private InputMapper(){}


	public InputMapper clone(){
		InputMapper clone = new InputMapper(this.generator, this.nInput, this.maxInputValues);
		
		clone.inputs       = new IntegerInput[this.inputs.length];
		clone.thresholdIds = new int[this.thresholdIds.length];
		
		// copy input informations
		for (int i = 0; i < this.inputs.length; i++ ){
			clone.inputs[i] = this.inputs[i].clone();
		}
		// copy thresholds
		for (int i = 0; i < this.thresholdIds.length; i++ ){
			clone.thresholdIds[i] = this.thresholdIds[i];
		}
		
		return clone;
	}
	
	public int getNumberOfInputs(){
		return nInput;
	}
	public int getNumberOfThresholds(){
		return thresholdIds.length;
	}
	
	public IntegerInput[] getInputs(){
		return inputs;
	}

	public Element exportXml(Element element) {
		
		Element mapper = element.addElement("input_mapper");
		mapper.addAttribute("num_of_thresholds",String.valueOf(this.thresholdIds.length));
		mapper.addAttribute("num_of_inputs",String.valueOf(this.nInput));
		mapper.addAttribute("max_input_values",String.valueOf(this.maxInputValues));
		
		Element thresholds = mapper.addElement("inputs");
		
		for (int i = 0; i < inputs.length; i++) {
			Element node = thresholds.addElement("input");;

			node.addAttribute("min", Integer.toString(inputs[i].min));
			node.addAttribute("max", Integer.toString(inputs[i].max));
			node.addAttribute("nunit", Integer.toString(inputs[i].nUnit));
			
			if (inputs[i] instanceof ThresholdedIntegerInput) {				
				node.addAttribute(
						"threshold",
						Integer.toString(((ThresholdedIntegerInput) inputs[i]).threshold));
			}
			else
			{
				node.addAttribute("threshold", "null");
			}
		}		
		return mapper;
	}
	
	public ArrayList<Integer> getThresholds(){
		ArrayList<Integer> thresholds = new ArrayList<Integer>();
		for(int i = 0; i < nInput; i++){
			if (inputs[i] instanceof ThresholdedIntegerInput) 			
				thresholds.add(((ThresholdedIntegerInput)inputs[i]).threshold);		
			}		 
			
		return thresholds;
	}
	
	/**
	 * Set a thresholds value.
	 * @param index 
	 * @param value
	 */
	public void setThreshold(int index, Integer value){
		if (doesArrayContainElement(thresholdIds, index)){
			((ThresholdedIntegerInput)inputs[index]).setThreshold(value);
		}
		else
			// TODO: maybe also raise an exception...
			System.err.println("Cannot modify threshold. No input with this id to threshold.");
	}
	
	private static boolean doesArrayContainElement(int[] ids, int id){
		boolean isElement = false;
		
		search:
		for (int i = 0; i < ids.length; i++) {
			if (id == ids[i])
			{
				isElement = true;
				break search;
			}
		}
		
		return isElement;
	}
	
	public int getSumOfThresholds(){
		int sum = 0;
		for(int i = 0; i < nInput; i++){
		if (inputs[i] instanceof ThresholdedIntegerInput) 			
			sum += ((ThresholdedIntegerInput)inputs[i]).threshold;		
		}
		return sum;
	}
	
	public int getThreshold(int i){
		return ((ThresholdedIntegerInput) getInput(i)).getThreshold();
	}
	
	public int getThresholdId(int i){
		return thresholdIds[i];
	}
	
	public void setThresholdId(int i, int value){
		if (doesArrayContainElement(thresholdIds, i)){
			((ThresholdedIntegerInput)inputs[i]).setThreshold(value);
		}
	}
	
	public static InputMapper loadFromXML(Node n) {		
		InputMapper inputMapper = new InputMapper();
		
		try {		
			Node nd = n.selectSingleNode("./input_mapper");

			int nThreshold = Integer.parseInt(nd.valueOf("./@num_of_thresholds"));
			inputMapper.thresholdIds = new int[nThreshold];
			inputMapper.nInput = Integer.parseInt(nd.valueOf("./@num_of_inputs"));
			inputMapper.maxInputValues = Integer.parseInt(nd.valueOf("./@max_input_values"));
						
			Node inodes = nd.selectSingleNode("./inputs");
			@SuppressWarnings("unchecked")
			List<Node> nodeList = inodes.selectNodes("./input");
			
			inputMapper.inputs = new IntegerInput[inputMapper.nInput];

			int i = 0;
			for (Node node:nodeList) {
				int min = Integer.parseInt(node.valueOf("./@min"));
				int max = Integer.parseInt(node.valueOf("./@max"));
				int nunit = Integer.parseInt(node.valueOf("./@nunit"));
				
				String threshold = node.valueOf("./@threshold");
				
				if(threshold.equals("null") || threshold.equals("no threshold")){
					// add integer input
					inputMapper.inputs[i] = new IntegerInput(min, max, nunit);
				}
				else{
					//add thresholded input
					inputMapper.inputs[i] = new ThresholdedIntegerInput(min, max, nunit, Integer.parseInt(threshold));
				}
				i++;
			}

		}
		catch (NumberFormatException e)
		{
			throw new IllegalArgumentException("MealyFSM: NumberFormatException! Check XML File");
		}
		
		return inputMapper;
	}
	
	public static String getIntegerArrayListAsString(ArrayList<Integer> list){
		String str = "";
		if (list == null)
			return "null";
		Iterator<Integer> it = list.iterator();
		for (; it.hasNext();){
			str += it.next().toString() + "";
			if (it.hasNext())
				str += ",";
			
		}
		return str;		
	}


	public void mutateThreshold(int id, MutationType mutationType){
		int index = thresholdIds[id];
		ThresholdedIntegerInput input = (ThresholdedIntegerInput)inputs[index];
		input.mutate(mutationType);
	}
	
	
	/** Converts the inputs to their position between min and max.
	 * Min beeing 0.*/
	public ArrayList<Integer> getEncodedInputValues(ArrayList<Float> sensorInputs){
		ArrayList<Integer> currValues = new ArrayList<Integer>();
		for(int i = 0; i < sensorInputs.size(); i++){		
			currValues.add(inputs[i].getPosition((int) ((float)sensorInputs.get(i))));
		}		
		return currValues;
	}
	
	public int getPositionInSortedInputList(ArrayList<Float> sensorInputs){
		int count = 1;
		for(int i = 0; i < nInput; i++){
			count = count * (inputs[i].getPosition((int) ((float)sensorInputs.get(i))) + 1);
		}
		
		return count - 1; // -1 needed to get a 0 base
	}
	
	public int getInputValueCombinations(){
		int count = 1;
		for(int i = 0; i < nInput; i++){
			count = count * (inputs[i].getPosition(inputs[i].max) + 1);
		}
		return count;
	}
	
	/**
	 * Loads default settings: each input is thresholded.
	 */
	public void loadDefaultProperties(){
		int min   = Defaults.DEFAULT_MIN  .getValue();
		int max   = Defaults.DEFAULT_MAX  .getValue();
		int nUnit = Defaults.DEFAULT_NUNIT.getValue();
		
		thresholdIds = new int[nInput];
		for (int i = 0; i < nInput; i++) {
			thresholdIds[i] = i;
			inputs[i] = new ThresholdedIntegerInput(min, max, nUnit, generator);
		}
	}
	
	public void printInfos(){
		System.out.println("Min\t| Max\t| Units\t| Thresholded");		
		System.out.println("======================================");
		for (int i = 0; i < nInput; i++){
			System.out.print("" + inputs[i].min +"\t| " +
					inputs[i].max + "\t| " + 
					inputs[i].nUnit + "\t| ");
			if (inputs[i] instanceof ThresholdedIntegerInput)
				System.out.println("yes (" + ((ThresholdedIntegerInput)inputs[i]).threshold + ")");
			else
				System.out.println("no ");
		}
		System.out.println("Possible input combinations: " + getInputValueCombinations());
		System.out.println("Number of thresholded values: " + getNumberOfThresholds());
		System.out.println();
	}
	
	private void loadProperties() throws IncorrectPropertiesException {
		// read infos about input values (min, max and how many units are betweens min..max)
		ArrayList<Integer> minInputValues  = getIntArrayProperty(properties, "min_input_values");
		ArrayList<Integer> maxInputValues  = getIntArrayProperty(properties, "max_input_values");
		ArrayList<Integer> unitInputValues = getIntArrayProperty(properties, "unit_input_values");
		// check first two arrays to have the same size
		if (minInputValues.size() != nInput  ||
				maxInputValues.size() !=  nInput ||
				unitInputValues.size() != nInput) {
			if (showLoadError) {
				System.err
					.println("Size of min_input_values, max_input_values and unit_input_values " +
							"must be equal to " + nInput + " (number of inputs)!" +
							"If there are 3 input values expected, set three comma separated values for min, max and unit (e.g. min_input_values: 0,0,0)!");
				showLoadError = false;
			}
			throw (new IncorrectPropertiesException());
		}

		int min = 0;
		int max = 0;
		int nUnit = 0;

		// First check if inputs fits in 1 bit, than check if fits in two bits, than if bigger, apply threshold
		int nThresholds = 0;
		for (int i = 0; i < nInput; i++) {
			min = minInputValues.get(i);
			max = maxInputValues.get(i);
			nUnit = unitInputValues.get(i);
			
			if ( nUnit >= 1 && nUnit < this.maxInputValues){
				inputs[i] = new IntegerInput(min, max, nUnit);
				}
			else{
			if (nUnit >= this.maxInputValues){
				nThresholds++;
				inputs[i] = new ThresholdedIntegerInput(min, max, nUnit, generator);
			}
			}
		}
		
		// init threshold ids
		thresholdIds = new int[nThresholds];
		int j = 0;
		for (int i = 0; i < nInput; i++) {
			if (inputs[i] instanceof ThresholdedIntegerInput)
			{
				thresholdIds[j] = i;
				j++;
			}				
		}
	}
	
	public IntegerInput getInput(int index){
		return inputs[index];
	}

	/**
	 * Transform string parameter into an array of integers
	 * @param property
	 */
	private static ArrayList<Integer> getIntArrayProperty(Hashtable<String, XMLFieldEntry> properties, String property){
		ArrayList<Integer> list =  new ArrayList<Integer>();
		XMLFieldEntry entry = properties.get(property);
		if (isNotEmpty(entry.getValue())){
			StringTokenizer tokenizer = new StringTokenizer(entry.getValue(), ",");
            while (tokenizer.hasMoreTokens()) {
                list.add(Integer.parseInt(tokenizer.nextToken()));
            }
		}
		return list;
	}
	
	public static boolean isNotEmpty(String source) {
        return (source != null && !("").equals(source));
	}

	class IncorrectPropertiesException extends Exception {
		private static final long serialVersionUID = 310411032648720780L;

		public IncorrectPropertiesException(){ }

		  public IncorrectPropertiesException(String msg) {
		    super(msg);
		  }
		}
	
	
	
	
}
