package fsm;

import utils.NESRandom;

public class ThresholdedIntegerInput extends IntegerInput{
	public enum MutationType {SmallIncrement, SmallDecrement, Random;}

	int threshold;
	NESRandom generator;
	
	public ThresholdedIntegerInput(int min, int max, int nUnit, NESRandom generator) {
		super(min, max, nUnit);
		this.generator = generator;
		// generate a random number between min and max
		if(generator == null)
			// this is when fsm is loaded from xml..
			this.threshold = 0; 
		else 
			this.threshold = min + (((max - min) / nUnit) * generator.nextInt(nUnit));
	}
	
	public ThresholdedIntegerInput(int min, int max, int nUnit, int threshold) {
		super(min, max, nUnit);
		this.generator = null;
		// generate a random number
		this.threshold = threshold;
	}
	
	public ThresholdedIntegerInput clone(){
		ThresholdedIntegerInput clone = new ThresholdedIntegerInput(this.min, this.max, this.nUnit, this.threshold);
		clone.generator = this.generator;
		return clone;
	}

	@Override
	public int getNumberOfInputValues(){
		return 2;
	}
	
	@Override
	public int getPosition(int value){
		if (value >= threshold)
			return 1;

		return 0;
	}
	
	public int getThreshold(){
		return this.threshold;
	}
	
	public void setThreshold(int value){
		this.threshold = value;
	}

	
	public void mutate(MutationType type){
		switch(type){
		case SmallDecrement: decValue(); break;
		case SmallIncrement: incValue(); break;
		case Random: setRandomValue(generator); break;
		}
	}
	
	/**
	 * Increment threshold value by one unit.
	 */
	private void incValue(){
		threshold = Math.min(++threshold, super.nUnit);
	}
	
	
	/**
	 * Decrement threshold value by one unit.
	 */
	private void decValue(){
		threshold = Math.max(--threshold, 0);
	}
	
	/**
	 * Sets a random value between 0 and number of units (excluding 
	 * limits) for the threshold. Generated value will be different 
	 * from current value.
	 * @param generator Random number generator
	 */
	private void setRandomValue(NESRandom generator){
		int tmp = threshold;
		while (threshold == tmp || threshold == 0){
			threshold = generator.nextInt(super.nUnit);
		}
	}	
}
