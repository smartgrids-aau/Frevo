/*
 * Copyright (C) 2009 Istvan Fehervari, Wilfried Elmenreich
 * Original project page: http://www.frevotool.tk
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License Version 3 as published
 * by the Free Software Foundation http://www.gnu.org/licenses/gpl-3.0.txt
 *
 * There is no warranty for this free software. The GPL requires that 
 * modified versions be marked as changed, so that their problems will
 * not be attributed erroneously to authors of previous versions.
 */
package core;

import graphics.FrevoWindow.SimulationWorkerThread;

import java.io.File;
import java.util.ArrayList;

import javax.swing.SwingWorker;

import main.ComponentXMLdata;
import main.FrevoMain;

import org.dom4j.Document;
import org.dom4j.Element;

import utils.NESRandom;

/** Abstract superclass for Method components. Methods are used to iteratively optimize a given set of {@link AbstractRepresentation}s.
 * They implement the {@link Runnable} interface meaning the algorithm will be executed on a separate thread.
 * 
 * <p>Methods can save obtained results any time by calling the {@link FrevoMain#saveResult(String, AbstractMethod)} static method.
 * @author Istvan Fehervari*/
public abstract class AbstractMethod extends AbstractComponent implements Runnable {
	
	/** A seed used for tracking the random generator object. */
	protected long seed;
	
	/** Holds a reference for the random generator object. */
	protected NESRandom generator;
	
	/** Indicates the progress of this method.*/
	protected int progress = 0;
	
	/** Holds a reference to the corresponding worker thread where the method is executed. */
	protected SimulationWorkerThread sworker;
	
	/** Indicates if an interrupt signal has arrived. */
	protected boolean isInterrupted = false;
	
	/** The source data of the representation component to be used by this method. */
	protected ComponentXMLdata representation;
	
	/** The source data of the problem component to be used by this method. */
	protected ComponentXMLdata problem;
	
	/** The source data of the ranking component to be used by this method.*/
	protected ComponentXMLdata ranking;
	
	/** Sends an interrupt flag to the method. The method should stop executing and return the intermediate results. */
	public void pause() {
		isInterrupted = true;
	}
	
	/** Indicates if this method is currently paused.
	 * @return if this method is currently paused. */
	public boolean isPaused() {
		return isInterrupted;
	}

	/** Sets the used representation type to the given value.
	 * @param representationData The new representation data to be used. */
	final public void setRepresentationData (ComponentXMLdata representationData) {
		this.representation = representationData;
	}
	
	/** Sets the used ranking data to the given value.
	 * @param rankingData The new ranking data to be used.*/
	final public void setRankingData (ComponentXMLdata rankingData) {
		this.ranking = rankingData;
	}

	/** Sets the used problem data to the given value.
	 * @param problemData The new problem data to be used.*/
	final public void setProblemData (ComponentXMLdata problemData) {
		this.problem = problemData;		
	}
	
	/** Sets the {@link SwingWorker} object that used to run this method.
	 * @param swingWorker The new SwingWorker reference to be used.  */
	final public void setSwingWorker(SimulationWorkerThread swingWorker) {
		sworker = swingWorker;
	}
	
	/** Returns the associated {@link SwingWorker} thread of this method.
	 * @return the associated SwingWorker thread that executed this method.*/
	final public SimulationWorkerThread getWorkerThread() {
		return sworker;
	}
	
	/** Returns the current progress of this method mostly for display purposes. 
	 * @return a float value between 0 and 1 */
	public abstract float getProgress();
	
	/** Sets the random generator object to the given value. A corresponding seed will be extracted as well.
	 * @param generator The new random generator object to be used. */
	final public void setRandom (NESRandom generator) {
		this.generator = generator;
		this.seed = generator.getSeed();
	}
	
	/** Sets the random seed for this method.
	 * @param seed The new random seed to be used. */
	final public void setRandom(long seed) {
		this.seed = seed;
		generator = new NESRandom(seed);
	}
	
	/** Returns the assigned random generator object of this method.
	 * @return a reference of the assigned random generator object. */
	final public NESRandom getRandom() {
		if (generator == null) {
			// create new random generator
			NESRandom g = new NESRandom();
			this.seed = g.nextLong();
			generator = new NESRandom(seed);
		}
		return generator;
	}
	
	/** Returns the current random seed associated with the random object of this method.
	 * @return the current random seed of this method.  */
	final public long getSeed() {
		return this.seed;
	}
	
	/**  This function is called by {@link FrevoMain} to perform custom saving operation related to this method.<br>
	 * Basically, this method should use the provided XML Element to place all necessary data structured in some format.
	 * To save the representations directly, call their built-in save method ({@link AbstractRepresentation#exportToXmlElement}).
	 * @param methodElement The root Element used for adding result structure.
	 * @see nnga.NNGA*/
	public abstract void saveResults(Element methodElement);
	
	/** Sets the progress of this method the given value. This value is used by the assigned worker thread mostly for display purposed.
	 * @param p The new progress value to be used. */
	final public void setProgress(float p) {
		if (sworker != null) {
			sworker.setProgressToPublish(p);
		}
	}

	/** Sets the result file used <b>before</b> executing this method.
	 * Generally, this is meant for methods to start with an already loaded set of candidates instead of starting from scratch.
	 * @param resultFile Reference to the file containing the representations to be used.*/
	public abstract void setResults(File resultFile);

	/** Returns a 2D array of representations from the given XML result file. This is mostly used for visual representations.
	 * @param doc The source {@link org.dom4j.Document} to be used for loading the representations.
	 * @return A 2D array of <tt>AbstractRepresentations</tt> loaded from the source document.*/
	public abstract ArrayList<ArrayList<AbstractRepresentation>> loadFromXML(Document doc);
	
	
}
