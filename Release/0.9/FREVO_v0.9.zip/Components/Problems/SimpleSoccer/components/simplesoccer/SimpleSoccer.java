/*
 * Copyright (C) 2009 Istvan Fehervari, Wilfried Elmenreich, Tobias Ibounig, Sebastian Krell
 * Original project page: http://www.frevotool.tk
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License Version 3 as published
 * by the Free Software Foundation http://www.gnu.org/licenses/gpl-3.0.txt
 *
 * There is no warranty for this free software. The GPL requires that 
 * modified versions be marked as changed, so that their problems will
 * not be attributed erroneously to authors of previous versions.
 */
package components.simplesoccer;

import java.awt.AWTException;
import java.awt.geom.Point2D;
import java.io.IOException;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;

import javax.swing.SwingWorker;

import main.FrevoMain;
import utils.ScreenCapture;

import components.simplesoccer.model.Evaluator;
import components.simplesoccer.model.NngaPlayer;
import components.simplesoccer.model.SimPlayer;
import components.simplesoccer.model.infoObject;
import core.AbstractMultiProblem;
import core.AbstractRepresentation;
import core.XMLFieldEntry;

public class SimpleSoccer extends AbstractMultiProblem {

	public AbstractRepresentation[] nets = new AbstractRepresentation[2]; // player
																			// controllers
	public SimpleServer simpleserver;
	/** Players in an array */
	public SimPlayer[][] playersinteams;// = new SimPlayer [2][11];
	public int stepnumber; // number of total steps
	public boolean withmonitor;
	public boolean withpause; // indicates if the game should be paused between steps to allow visibility

	/** Team names */
	public String[] tname = new String[2];

	/** Position scores */
	public int[] scores = new int[2];
	public int[] balldistscores = new int[2];
	public int[][] kicknum = new int[2][11];
	public int[] kicknumsum = new int[2];
	public int[] falsekicks = new int[2];
	public int[] ball_goal_scores = new int[2];

	/** Number of real scores */
	public int[] scorenum = new int[2];

	private infoObject object = new infoObject();
	public long[] finalscores = new long[2];
	public int aktStep;
	private Evaluator evaluator = new Evaluator();
	private SimpleDisplay display;
	protected DisplayWorker sw;
	private boolean saveMovie = false;

	// Stop after no_move_steps steps without action
	private static int no_move_steps = 10;

	// The weights for evaluation
	public static int POSITION_WEIGHT;
	public static int NEAREST_BALL_DISTANCE_WEIGHT;
	public static int KICK_WEIGHT;
	public static int BALL_GOAL_WEIGHT;
	public static int SCORE_WEIGHT;
	public static int PLAYERS_PER_TEAM;
	public static int EVALTIME;
	public static boolean CARTESIANOUTPUT;

	@Override
	public void replayWithVisualization(AbstractRepresentation[] candidates) {
		this.nets[0] = candidates[0];
		this.nets[1] = candidates[1];
		this.simpleserver = new SimpleServer(this);

		display = new SimpleDisplay(this);

		sw = new DisplayWorker();
		withpause = true;
		withmonitor = true;
		sw.execute();

	}

	private class DisplayWorker extends SwingWorker<Void, Integer> {

		@Override
		protected Void doInBackground() throws Exception {
			loadParameters();
			withmonitor = true;
			withpause = true;

			runSimulation();
			return null;
		}

		public void setProgressToPublish(int p) {
			publish(p);
		}

		protected void process(List<Integer> results) {
			display.updateDisplay();
		}

	}

	@Override
	public List<RepresentationWithScore> evaluateFitness(
			AbstractRepresentation[] candidates) {
		loadParameters();
		this.nets[0] = candidates[0];
		this.nets[1] = candidates[1];
		this.simpleserver = new SimpleServer(this);
		withpause = false;
		withmonitor = false;
		return runSimulation();
	}

	private void loadParameters() {
		POSITION_WEIGHT = Integer.parseInt(getProperties().get(
				"position_weight").getValue());
		NEAREST_BALL_DISTANCE_WEIGHT = Integer.parseInt(getProperties().get(
				"ball_distance_weight").getValue());
		KICK_WEIGHT = Integer.parseInt(getProperties().get("kick_weight")
				.getValue());
		BALL_GOAL_WEIGHT = Integer.parseInt(getProperties().get(
				"ball_goal_weight").getValue());
		SCORE_WEIGHT = Integer.parseInt(getProperties().get("score_weight")
				.getValue());
		PLAYERS_PER_TEAM = Integer.parseInt(getProperties().get(
				"playersPerTeam").getValue());
		EVALTIME = Integer.parseInt(getProperties().get("evaluation_time").getValue());
		CARTESIANOUTPUT = Boolean.parseBoolean(getProperties().get("isCartesian_interpretation")
				.getValue());
	}

	public List<RepresentationWithScore> runSimulation() {

		// this.withmonitor = withmonitor;
		createTeamNames();
		createTeams();
		initialize();

		placePlayers();
		placeBall();
		if (withmonitor)
			sw.setProgressToPublish(aktStep);
		/* Simulator is ready */

		calculateStep();

		// Trac positions to stop sim after 10 steps without action
		Point2D.Double[][] prev_pos = new Point2D.Double[2][PLAYERS_PER_TEAM];
		for (int k = 0; k < PLAYERS_PER_TEAM; k++) // initialize positions
		{
			prev_pos[0][k] = playersinteams[0][k].position;
			prev_pos[1][k] = playersinteams[1][k].position;
		}
		int no_movement = 0;
		boolean just_fitness = false;

		if (withpause)
			pause(100); // pause 100 it was
		for (aktStep = 0; aktStep < stepnumber; aktStep++) {
			if (saveMovie)
				saveFrame();

			// If nobody is moving
			if (just_fitness) {
				calcFitness();
				continue;
			}

			// any player moving?
			boolean no_change = true;
			for (int k = 0; k < PLAYERS_PER_TEAM; k++) {
				if (prev_pos[0][k].equals(playersinteams[0][k].position)
						&& prev_pos[1][k].equals(playersinteams[1][k].position))
					continue;

				for (int j = 0; j < PLAYERS_PER_TEAM; j++) {
					// refresh reference-values
					prev_pos[0][j] = playersinteams[0][j].position;
					prev_pos[1][j] = playersinteams[1][j].position;
					no_change = false;
				}
				break;

			}

			if (no_change)
				no_movement++;
			else
				no_movement = 0;

			if (no_movement >= no_move_steps)
				just_fitness = true;

			calculateStep();
			if (withpause)
				pause(100); // pause 100 it was
		}
		// calculate results

		if (kicknumsum[0] > 10)
			kicknumsum[0] = 10; // only the first 10 kicks count
		if (kicknumsum[1] > 10)
			kicknumsum[1] = 10;
		if (withmonitor)
			System.out.println("p. scores: " + scores[0] + "/" + scores[1]
					+ " kicknumsum: " + kicknumsum[0] + "/" + kicknumsum[1]
					+ " falsekicks: " + falsekicks[0] + "/" + falsekicks[1]
					+ " balldist: " + balldistscores[0] + "/"
					+ balldistscores[1] + " ball_goal: " + ball_goal_scores[0]
					+ "/" + ball_goal_scores[1]);
		finalscores[0] = (scores[0] * POSITION_WEIGHT)
				+ (kicknumsum[0] - falsekicks[0] * 2) * KICK_WEIGHT
				+ (scorenum[0] * SCORE_WEIGHT)
				+ (balldistscores[0] * NEAREST_BALL_DISTANCE_WEIGHT)
				+ (ball_goal_scores[0] * BALL_GOAL_WEIGHT);
		finalscores[1] = (scores[1] * POSITION_WEIGHT)
				+ (kicknumsum[1] - falsekicks[1] * 2) * KICK_WEIGHT
				+ (scorenum[1] * SCORE_WEIGHT)
				+ (balldistscores[1] * NEAREST_BALL_DISTANCE_WEIGHT)
				+ (ball_goal_scores[1] * BALL_GOAL_WEIGHT);

		if ((FrevoMain.DEBUGLEVEL & 0x08) > 0)
			System.out.println("POSITION_WEIGHT=" + POSITION_WEIGHT
					+ " KICK_WEIGHT=" + KICK_WEIGHT + " SCORE_WEIGHT="
					+ SCORE_WEIGHT + " NEAREST_BALL_DISTANCE_WEIGHT="
					+ NEAREST_BALL_DISTANCE_WEIGHT + " BALL_GOAL_WEIGHT="
					+ BALL_GOAL_WEIGHT);
		if (withmonitor)
			System.out.println(finalscores[0] + "," + finalscores[1]
					+ ", kicks: " + kicknumsum[0] + " / " + kicknumsum[1]
					+ " bgdist: " + ball_goal_scores[0] + " / "
					+ ball_goal_scores[1] + " score: " + scorenum[0] + " / "
					+ scorenum[1]);

		// we have the results now
		List<RepresentationWithScore> result = new LinkedList<RepresentationWithScore>();

		RepresentationWithScore player1 = new RepresentationWithScore(nets[0],
				1);
		RepresentationWithScore player2 = new RepresentationWithScore(nets[1],
				1);

		if (finalscores[0] > finalscores[1]) {
			player2.setScore(-1);
		} else if (finalscores[0] < finalscores[1]) {
			player1.setScore(-1);
		}

		result.add(player1);
		result.add(player2);
		return result;

	}

	private void createTeamNames() {
		this.tname[0] = "Team A";
		this.tname[1] = "Team B";
	}

	private void createTeams() {
		playersinteams = new SimPlayer[2][PLAYERS_PER_TEAM];
		for (int k = 0; k < 2; k++) {
			for (int i = 0; i < PLAYERS_PER_TEAM; i++) { // team size according
															// to xml settings
				playersinteams[k][i] = new SimPlayer(tname[k], k, i,
						new NngaPlayer(nets[k], this));
			}
		}
	}

	protected synchronized void pause(int ms) {
		try {
			this.wait(ms);
		} catch (InterruptedException ex) {
		}
	}

	/**
	 * Sends sensor data to the agents and collects their intentions
	 */
	private void calculateStep() {
		sendSensordata();
		// get new intentions
		for (int k = 0; k < PLAYERS_PER_TEAM; k++) {
			playersinteams[0][k].getController().postInfo();
			playersinteams[1][k].getController().postInfo();
		}
		// calculate changes

		simpleserver.calculateAll();

		if (withmonitor)
			sw.setProgressToPublish(aktStep);

		calcFitness();
	}

	/** Sends sensor data to the players */
	public void sendSensordata() {
		// set preinfo stage to controller
		for (int k = 0; k < PLAYERS_PER_TEAM; k++) {
			playersinteams[0][k].getController().preInfo();
			playersinteams[1][k].getController().preInfo();
		}
		// Add visual information
		for (int k = 0; k < PLAYERS_PER_TEAM; k++) {
			simpleserver.getVisuals((playersinteams[0][k]),
					(playersinteams[0][k]).position.x,
					(playersinteams[0][k]).position.y);
			simpleserver.getVisuals((playersinteams[1][k]),
					(playersinteams[1][k]).position.x,
					(playersinteams[1][k]).position.y);
		}
	}

	private void calcFitness() {
		// allocation every 5 seconds, ball distance to nearest player every 4
		// seconds, ball to goal every 2 seconds measured
		int aktmsec = aktStep * SimpleServer.STEPLENGTH;

		// Player distribution on the field
		if ((aktmsec % 5000) == 0) {

			object.setBall(simpleserver.ball.position.x,
					simpleserver.ball.position.y); // set ball

			for (int t = 0; t < 2; t++) {
				for (int p = 0; p < PLAYERS_PER_TEAM; p++) {
					object.setPlayer(t, p, playersinteams[t][p].position.x,
							playersinteams[t][p].position.y); // set players
				}
			}

			evaluator.calculate(object);

			if ((FrevoMain.DEBUGLEVEL & 0x08) > 0) {
				System.out.print("fit: " + evaluator.getScore(0) + " : "
						+ evaluator.getScore(1));
			}

			scores[0] += evaluator.getScore(0);
			scores[1] += evaluator.getScore(1);
		}

		// Ball distance to the nearest player
		if ((aktmsec % 4000) == 0) {

			object.setBall(simpleserver.ball.position.x,
					simpleserver.ball.position.y); // set ball

			for (int t = 0; t < 2; t++) {
				for (int p = 0; p < PLAYERS_PER_TEAM; p++) {
					object.setPlayer(t, p, playersinteams[t][p].position.x,
							playersinteams[t][p].position.y); // set players
				}
			}

			evaluator.calculate(object);
			balldistscores[0] += evaluator.getBalldistScore(0);
			balldistscores[1] += evaluator.getBalldistScore(1);
		}

		// Ball distance to opponents goal
		if ((aktmsec % 2000) == 0) {
			double d1 = SimpleServer.getDistance(simpleserver.ball,
					simpleserver.RightGoal);
			double d2 = SimpleServer.getDistance(simpleserver.ball,
					simpleserver.LeftGoal);

			if (d1 < d2)
				ball_goal_scores[0]++;
			else if (d1 > d2)
				ball_goal_scores[1]++;
		}
	}

	private void initialize() {
		for (int s = 0; s < 2; s++) {
			scores[s] = 0;
			balldistscores[s] = 0;
			ball_goal_scores[s] = 0;
			falsekicks[s] = 0;
			scorenum[s] = 0;
		}

		for (int u = 0; u < PLAYERS_PER_TEAM; u++) {
			kicknum[0][u] = 0;
			kicknum[1][u] = 0;
		}

		stepnumber = EVALTIME / SimpleServer.STEPLENGTH;
		object.goals[0] = simpleserver.LeftGoal.position;
		object.goals[1] = simpleserver.RightGoal.position;
	}

	public int teamname2int(String teamname) {
		if (teamname.equals(tname[0]))
			return 0;
		else if (teamname.equals(tname[1]))
			return 1;
		else
			throw new Error("Wrong team name!");
	}

	/**
	 * Places all players to the starting positions
	 */
	public void placePlayers() {
		// place according to team size, maximum 11/ team
		if (PLAYERS_PER_TEAM > 11)
			throw new Error("Teamsize larger than 11 is not implemented!");
		for (int p = 0; p < PLAYERS_PER_TEAM; p++) {
			double x = 0;

			if (p < 3)
				x = 10;
			else if (p < 8)
				x = 20;
			else if (p == 8)
				x = 30;
			else
				x = 40;

			double y = 0;

			if ((p == 0) || (p == 3) || (p == 8))
				y = 0;
			else if ((p == 1) || (p == 4) || (p == 9))
				y = 10;
			else if ((p == 2) || (p == 5) || (p == 10))
				y = -10;
			else if (p == 6)
				y = 20;
			else if (p == 7)
				y = -20;

			playersinteams[0][p].position = new Point2D.Double(-x, y);
			playersinteams[1][p].position = new Point2D.Double(x, y);
		}

		// Turns + nullify speed and acceleration
		for (int i = 0; i < PLAYERS_PER_TEAM; i++) {
			playersinteams[0][i].setBodyDirection(90);
			playersinteams[1][i].setBodyDirection(270);
			playersinteams[0][i].speedVector = new Point2D.Double(0, 0);
			playersinteams[1][i].speedVector = new Point2D.Double(0, 0);
			playersinteams[0][i].accelerationVector = new Point2D.Double(0, 0);
			playersinteams[1][i].accelerationVector = new Point2D.Double(0, 0);
		}
	}

	/**
	 * Places the ball to the starting position
	 */
	public void placeBall() {
		simpleserver.ball.position = new Point2D.Double(0, 0);
		simpleserver.ball.speedVector = new Point2D.Double(0, 0);
		simpleserver.ball.accelerationVector = new Point2D.Double(0, 0);
	}

	@Override
	public Hashtable<String, XMLFieldEntry> adjustRequirements(
			Hashtable<String, XMLFieldEntry> requirements,
			Hashtable<String, XMLFieldEntry> properties) {
		// no modifications
		return requirements;
	}

	private void saveFrame() {
		try {
			ScreenCapture.createImage(display, "./Images/Frame_" + fix(aktStep)
					+ ".bmp");
		} catch (AWTException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	private static String fix(int num) {
		String ret = Integer.toString(num);
		if (num < 10)
			ret = "00" + ret;
		else if (num < 100)
			ret = "0" + ret;
		return ret;
	}

}
