/*
 * Copyright (C) 2009 Istvan Fehervari, Wilfried Elmenreich
 * Original project page: http://www.frevotool.tk
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License Version 3 as published
 * by the Free Software Foundation http://www.gnu.org/licenses/gpl-3.0.txt
 *
 * There is no warranty for this free software. The GPL requires that 
 * modified versions be marked as changed, so that their problems will
 * not be attributed erroneously to authors of previous versions.
 */
package components.simplesoccer.model;


import java.awt.geom.Point2D;
import java.util.ArrayList;

import main.FrevoMain;

import components.simplesoccer.SimpleServer;
import components.simplesoccer.SimpleSoccer;
import core.AbstractRepresentation;

/**
 * The controller of a player, basically this class contains the behavior of the soccer player
 */

public class NngaPlayer implements Controller {


  //private final double FARAWAY = 400.0;
  private Point2D.Double relativeBallPos = new Point2D.Double();
  private Point2D.Double relativeNearestOppPos = new Point2D.Double();
  private Point2D.Double relativeNearestTeamPlayerPos = new Point2D.Double();
  private Point2D.Double relativeOppGoalPos = new Point2D.Double();
  private Point2D.Double relativeOwnGoalPos = new Point2D.Double();
  private double border_top;
  private double border_bottom;
  private double border_left;
  private double border_right;
 
  private SimPlayer skiiplayer;
  private SimpleSoccer master;
  private AbstractRepresentation net;
  private ArrayList<Float> input = new ArrayList<Float>();
  private ArrayList<Float> output = new ArrayList<Float>();
  public int kickCount = 0; 
  
 // static int wilscounter = 0;
  
  public NngaPlayer(AbstractRepresentation net, SimpleSoccer master) {
	this.net = net.clone();   
	this.master = master;
  }
  
  public SimpleSoccer getSession() {
	  return this.master;
  }

  public Player getPlayer (){
    return skiiplayer;
  }
  
  public void setPlayer (Player p){
	  skiiplayer = (SimPlayer) p;
  }
  
  /** Reset the state of the controller. */
  public void preInfo () {
	  //reset values here if necessary  
  }
  
  /** Controls the client by interpreting the state of the controller. */
  public void postInfo () {	  
	  input.clear();
	  output.clear();
	  
	  final boolean useCartesianOutput = /*FrevoMain.CARTESIANS[getPlayer().getSide()];*/SimpleSoccer.CARTESIANOUTPUT;
	  
	  
	  net.reset(); //reset nn

	  //Input neurons for ball
	  double balldist = SimpleServer.getLength(relativeBallPos);
	  addInput(balldist,relativeBallPos);
	  	  
	  //Input neurons for nearest team mate
	  double nearestmatedist = SimpleServer.getLength(relativeNearestTeamPlayerPos);
	  addInput(nearestmatedist,relativeNearestTeamPlayerPos);
	  
	  //Input neurons for nearest opponent
	  double nearestoppdist = SimpleServer.getLength(relativeNearestOppPos);
	  addInput(nearestoppdist,relativeNearestOppPos);
	  
	  //Input neurons for lines
	  //if (getPlayer().getSide() == 0) {

		  input.add((float) (1/(1+border_top))  );
		  input.add((float) (1/(1+border_bottom))  );
		  input.add((float) (1/(1+border_left))  );
		  input.add((float) (1/(1+border_right))  );
	  
	  if (getPlayer().getSide() == 1) {
		  //team is playing from right-to-left side,
		  //input needs to be switched
		  
		  for (int i=0; i<input.size(); i+=2)
		  {
			  float h;
			  h=input.get(i);
			  input.set(i, input.get(i+1));
			  input.set(i+1,h);
			  //input.setElementAt(input.get(i+1), i);
			  //input.setElementAt(h, i+1);
		  }
	  }
	  
//	  //DEBUG generate deterministic inputs
//	  for (int i=0; i<input.size(); i++)
//	  {
//		  input.setElementAt((float)5/(i+1),i);
//	  }
	  
	//  NngaPlayer.wilscounter++;
	  
	  if ((FrevoMain.DEBUGLEVEL & 0x04) > 0) {
	 // if (balldist < 4) {
		  //System.out.print("c:"+NngaPlayer.wilscounter+" ");
		  System.out.println("Team:"+getPlayer().getSide()+"P:"+getPlayer().getNumber()+" dist to ball:"+balldist+"("+relativeBallPos.x+","+relativeBallPos.y+")");
		  for(int i=0; i<input.size(); i++)
			  System.out.print("i"+i+":"+input.get(i)+" ");
		  System.out.println();
	  }
	  
	  //calculate outputs
	  //output.setSize(4);
	  output = net.getOutput(input);

	  if ((FrevoMain.DEBUGLEVEL & 0x04) > 0) {
	  //if (balldist < 4) {
		  for(int i=0; i<output.size(); i++)
			  System.out.print("o"+i+":"+output.get(i)+" ");
		  System.out.println();
	  }
	  
	  if (useCartesianOutput) //output is given in cartesian form
	  {
		  double direction,power;
		  
		  
		  double x[]=new double[4];
		  for (int i=0; i<4; i++) {
			  //scale up values to [-1.0,1.0]
			  x[i] = output.get(i)*2.0-1.0;
			  
			  if (getPlayer().getSide() == 1) {
				  //team is playing from right-to-left side,
				  //input needs to be switched
				  x[i] = -x[i];
			  }
		  }
		  
		  if (balldist < 0.7) { //we can kick the ball
			  direction = Math.atan2(x[2], x[3]) * 180.0 / Math.PI;
			  power = 100*Math.sqrt(x[2]*x[2]+x[3]*x[3]);
			  getPlayer().kick( (int)power, direction); //scale to -1..0..1
		  }
		  else {
			  direction = Math.atan2(x[0], x[1]) * 180.0 / Math.PI;
			  power = 100*Math.sqrt(x[0]*x[0]+x[1]*x[1]);
			  //System.out.println("Team:"+getPlayer().getSide()+"P:"+getPlayer().getNumber()+" power="+power+" direction="+direction);
			  getPlayer().dashto( (int)power , direction);
		  }
	  }
	  else
	  {
		  double direction;
		  //output is given in polar coordinate form
		  //this is more difficult for the NN
		  if (balldist < 0.7) { //we can kick the ball
			  direction = output.get(3)*360;
			  if (getPlayer().getSide() == 1) direction += 180;
			  getPlayer().kick( (int)(output.get(2)*100), direction); //scale to -1..0..1
		  }
		  else {
			  direction = output.get(1)*360;
			  if (getPlayer().getSide() == 1) direction += 180;
			  	  
			  getPlayer().dashto( (int)(output.get(0)*100) , direction);
		  }		  
	  }	    
  }

private void addInput(double distance, Point2D.Double relativepos) {
	if (distance < 0.7) distance=0.7;
	//if (getPlayer().getSide() ==0) { //on the left
		  //top-bottom
		  if (relativepos.y <= 0) {
			  input.add((float)(Math.abs(relativepos.y/Math.pow(distance, 2))    ) ); //top
			  input.add(0f); //bottom
		  }
		  else {
			  input.add(0f); //top
			  input.add((float)(Math.abs(relativepos.y/Math.pow(distance, 2)) )); //bottom
		  }
		  
		  //left-right
		  if (relativepos.x <= 0) {
			  input.add((float)(Math.abs(relativepos.x/Math.pow(distance, 2)) )); //left
			  input.add(0f); //right
		  }
		  else {
			  input.add(0f); //left
			  input.add((float)(Math.abs(relativepos.x/Math.pow(distance, 2))) ); //right
		  }

}

@Override
public void setRelativePosBall(double x, double y) {
	this.relativeBallPos.x=x;
	this.relativeBallPos.y=y;
}

@Override
public void setRelativePosBorders(double top, double bottom, double left,
		double right) {
	
	this.border_top = top;
	this.border_bottom = bottom;
	this.border_left = left;
	this.border_right = right;
}

@Override
public void setRelativePosNearestOpponent(double x, double y) {
	this.relativeNearestOppPos.x = x;
	this.relativeNearestOppPos.y = y;
}

@Override
public void setRelativePosNearestPlayer(double x, double y) {
	this.relativeNearestTeamPlayerPos.x = x;
	this.relativeNearestTeamPlayerPos.y = y;
}

@Override
public void setRelativePosOppGoal(double x, double y) {
	this.relativeOppGoalPos.x=x;
	this.relativeOppGoalPos.y=y;
}

@Override
public void setRelativePosOwnGoal(double x, double y) {
	this.relativeOwnGoalPos.x=x;
	this.relativeOwnGoalPos.y=y;
}

}