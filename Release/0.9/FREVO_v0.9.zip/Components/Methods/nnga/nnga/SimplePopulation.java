package nnga;
/*
 * Copyright (C) 2009 Istvan Fehervari, Wilfried Elmenreich
 * Original project page: http://www.frevotool.tk
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License Version 3 as published
 * by the Free Software Foundation http://www.gnu.org/licenses/gpl-3.0.txt
 *
 * There is no warranty for this free software. The GPL requires that 
 * modified versions be marked as changed, so that their problems will
 * not be attributed erroneously to authors of previous versions.
 */

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import main.ComponentXMLdata;

import org.dom4j.Element;

import core.AbstractRepresentation;


public class SimplePopulation {

	private ArrayList<AbstractRepresentation> members;
	private int popsize;
	private ComponentXMLdata representation;
	private NNGA parent;
	int input_number;
	int output_number;
	
	public SimplePopulation (int populationsize, ComponentXMLdata representationData, NNGA parent, int inputnumber, int outputnumber) {
		this.parent = parent;
		this.popsize = populationsize;
		this.representation = representationData;
		input_number = inputnumber;
		output_number = outputnumber;
		createPop();
		
	}
	
	public SimplePopulation (ArrayList<AbstractRepresentation> candidates, ComponentXMLdata representation, NNGA p) {
		this.parent = p;
		this.representation = representation;
		this.members = candidates;
	}
	
	/** Creates initial population*/
	private void createPop() {
		members = new ArrayList<AbstractRepresentation>();
		for (int i = 0;i<popsize;i++) {
			try {
				AbstractRepresentation member = representation.getNewRepresentationInstance(input_number, output_number, parent.getRandom());
				members.add(member);
			} catch (InstantiationException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	public AbstractRepresentation[] getNetArray()
	{
		AbstractRepresentation[] n = new AbstractRepresentation[popsize];
		return members.toArray(n);
	}
	
	public void rank()
	{
		Collections.sort(members,Collections.reverseOrder());
	}

	public ArrayList<AbstractRepresentation> getMembers() {
		return this.members;
	}

	public AbstractRepresentation genNewNetwork() throws InstantiationException, IllegalAccessException {
		AbstractRepresentation member = representation.getNewRepresentationInstance(input_number,output_number,parent.getRandom());
		return member;
	}

	public void readNetArray(AbstractRepresentation[] nets) {
		this.members = new ArrayList<AbstractRepresentation>(Arrays.asList(nets));
	}

	public Element exportXml(Element element)
	{
		Element dpop = element.addElement("population");
	/*	dpop.addAttribute("populationsize",String.valueOf(this.popsize));
		dpop.addAttribute("best-score", String.valueOf(this.getBestScore()));
		dpop.addAttribute("avg-score", String.valueOf(this.getAvgPopScore()));*/
		for(AbstractRepresentation n: members)
			n.exportToXmlElement(dpop);
		return dpop;
	}
}
