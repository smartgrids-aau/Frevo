package nnga;

/*
 * Copyright (C) 2009 Istvan Fehervari, Wilfried Elmenreich
 * Original project page: http://www.frevotool.tk
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License Version 3 as published
 * by the Free Software Foundation http://www.gnu.org/licenses/gpl-3.0.txt
 *
 * There is no warranty for this free software. The GPL requires that 
 * modified versions be marked as changed, so that their problems will
 * not be attributed erroneously to authors of previous versions.
 */

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import main.FrevoMain;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Node;

import utils.StatKeeper;
import core.AbstractMethod;
import core.AbstractRanking;
import core.AbstractRepresentation;
import core.XMLFieldEntry;

/**
 * A genetic algorithm designed to evolve any kind of representation. Supports
 * multiple populations and several ranking systems.
 * 
 * @author Istvan Fehervari, Andreas Pfandler
 */
public class NNGA extends AbstractMethod {

	/** Number of parallel populations */
	private int POPULATIONNUMBER;
	/** Size of each population */
	private int POPULATIONSIZE;
	/** Number of generations to calculate */
	private int GENERATIONS;
	/** Severity of the mutations that occur */
	private float MUTATIONSEVERITY;
	/** Percentage of elite candidates in the whole population */
	private float P_ELITE;
	/** Number of elite candidates */
	private int N_ELITE;
	/** Percentage of randomly selected candidates in the next population */
	private float P_RANDOM;
	/** Number of randomly selected candidates in the next population */
	private int N_RANDOM;
	/** Number of mutated candidates in the next population */
	private int N_MUTATE;
	/** Percentage of mutated candidates in the next population */
	private float P_MUTATE;
	/** Number of randomly generated candidates in the next population */
	private int N_RENEW;
	/** Percentage of randomly generated candidates in the next population */
	private float P_RENEW;
	/**
	 * Percentage of new candidates created by recombination in the next
	 * population
	 */
	private float P_XOVER;
	/** Number of new candidates created by recombination in the next population */
	private int N_XOVER;
	/** Number of generations till an inter-population crossover happens */
	private int N_INTERXOVER_FREQ;
	/** The index of the mutation method to be used */
	private int MUTATIONMETHOD;
	/** The index of the recombination method to be used */
	private int XOVERMETHOD;
	/** Indicates after how many generations should a saving occur */
	private int SAVEINTERVAL;

	/** List of lists containing the candidates sorted in populations */
	private LinkedList<SimplePopulation> pops = new LinkedList<SimplePopulation>();

	/** Indicates the number of the starting generation */
	private int startgeneration = 0;

	/** Indicates the current generation */
	private int generation;

	/** Best fitness statistics */
	private StatKeeper bfitness;
	/** Index statistics */
	private StatKeeper index;

	/** Initializes the method by loading all parameters */
	private void initialize() {
		// Load NNGA parameters
		XMLFieldEntry popnum = getProperties().get("populationnumber");
		POPULATIONNUMBER = Integer.parseInt(popnum.getValue());
		XMLFieldEntry popsize = getProperties().get("populationsize");
		POPULATIONSIZE = Integer.parseInt(popsize.getValue());
		XMLFieldEntry gensize = getProperties().get("generations");
		GENERATIONS = Integer.parseInt(gensize.getValue());

		XMLFieldEntry p_elite = getProperties().get("percentage_elite");
		P_ELITE = Float.parseFloat(p_elite.getValue());
		XMLFieldEntry p_random = getProperties().get("percentage_random");
		P_RANDOM = Float.parseFloat(p_random.getValue());
		XMLFieldEntry p_mutate = getProperties().get("percentage_mutate");
		P_MUTATE = Float.parseFloat(p_mutate.getValue());
		XMLFieldEntry p_renew = getProperties().get("percentage_renew");
		P_RENEW = Float.parseFloat(p_renew.getValue());
		XMLFieldEntry p_xover = getProperties().get("percentage_xover");
		P_XOVER = Float.parseFloat(p_xover.getValue());
		XMLFieldEntry n_inter = getProperties().get("interXover_frequency");
		N_INTERXOVER_FREQ = Integer.parseInt(n_inter.getValue());
		XMLFieldEntry mm = getProperties().get("mutationMethod");
		MUTATIONMETHOD = Integer.parseInt(mm.getValue());
		XMLFieldEntry xm = getProperties().get("xoverMethod");
		XOVERMETHOD = Integer.parseInt(xm.getValue());
		XMLFieldEntry ms = getProperties().get("mutationseverity");
		MUTATIONSEVERITY = Float.parseFloat(ms.getValue());

		// calculates numbers based on percentages
		N_ELITE = (int)(POPULATIONSIZE * P_ELITE);
		N_RANDOM = (int)(POPULATIONSIZE * P_RANDOM);
		N_MUTATE = (int)(POPULATIONSIZE * P_MUTATE);
		N_RENEW = (int)(POPULATIONSIZE * P_RENEW);
		N_XOVER = (int)(POPULATIONSIZE * P_XOVER);

		int roundingError = POPULATIONSIZE - N_ELITE - N_RANDOM - N_MUTATE
				- N_RENEW - N_XOVER;

		N_ELITE += roundingError;

		XMLFieldEntry saveint = getProperties().get("saveinterval");
		SAVEINTERVAL = Integer.parseInt(saveint.getValue());

	}

	@Override
	public void run() {
		// Get problem's requirements
		Hashtable<String, XMLFieldEntry> req = problem.getRequirements();
		XMLFieldEntry input = req.get("inputnumber");
		int inputnumber = Integer.parseInt(input.getValue());

		XMLFieldEntry output = req.get("outputnumber");
		int outputnumber = Integer.parseInt(output.getValue());

		int lastsaved = -1;
		initialize();

		progress = 0;
		double bestfitness = 0;

		//if (resultfile == null) { // no file to load
			if ((FrevoMain.getResults() != null)
					&& (FrevoMain.getResults().getClass() == ResultObject.class)) { // there
																					// are
																					// results
																					// to
																					// be
																					// loaded
																					// in
																					// the
																					// memory
				ResultObject result = (ResultObject) FrevoMain.getResults();
				// System.out.println
				// ("Intermediate results successfully loaded");
				if (result.remainingGenerations != 0) { // there are still
														// generations left
					pops = result.populations;
					startgeneration = GENERATIONS - result.remainingGenerations;

					// FrevoMain.STATISTICS.clear();
					// index = result.statistics.get(0);
					// bfitness = result.statistics.get(1);
					index = FrevoMain.getStatistics(0);
					bfitness = FrevoMain.getStatistics(1);
				}
			} else { // Start from scratch, no populations to load
				for (int i = 0; i < POPULATIONNUMBER; i++) {
					pops.add(new SimplePopulation(POPULATIONSIZE,
							representation, this,inputnumber,outputnumber));
				}
				// FrevoMain.STATISTICS.clear();
				index = new StatKeeper(true, "Generations", "Generations",
						false);
				bfitness = new StatKeeper(true, "Best Fitness."
						+ FrevoMain.getCurrentRun(), "Generations", true);
			}

		/*} else { // load populations from file - for continuing
			Document doc = SafeSAX.read(resultfile);

			Node dpopulations = doc.selectSingleNode("/frevo/populations");
			startgeneration = Integer.parseInt(dpopulations
					.valueOf("./@generation"));
			this.setRandom(Long.parseLong(dpopulations.valueOf("./@randomseed")));
			List<?> npops = dpopulations.selectNodes(".//population");
			Iterator<?> it = npops.iterator();
			while (it.hasNext()) {
				Node pop = (Node) it.next();

				ArrayList<AbstractRepresentation> population = createList(pop);
				pops.add(new SimplePopulation(population, representation, this));
			}
		}*/

		// if the statistics object has no index column then generate it as well
		if (FrevoMain.getNumberofStatistics() == 0) {
			FrevoMain.addStatistics(index);
		}

		// Collect best fitness
		if (!FrevoMain.isStatKeeperLoaded(bfitness))
			FrevoMain.addStatistics(bfitness);

		bestfitness = bfitness.getMax();
		boolean wasImprovement = false;

		// Iterate through
		for (generation = startgeneration; generation < GENERATIONS; generation++) {
			System.out.println("Proceeding to generation " + generation);

			setProgress((float) generation / (float) GENERATIONS);
			wasImprovement = false;

			if (FrevoMain.isFrevoWithGraphics()) {
				if (isInterrupted) {
					// Publish results in FrevoMain
					ResultObject res = new ResultObject(pops, GENERATIONS
							- generation);
					FrevoMain.publishResults(res);
					return;
				}
			}

			// Rank each population using ranking
			for (int k = 0; k < POPULATIONNUMBER; k++) {
				AbstractRanking r;
				try {
					r = ranking.getNewRankingInstance();
					if (FrevoMain.isFrevoWithGraphics()) {
						if (isInterrupted) {
							// Publish results in FrevoMain
							ResultObject res = new ResultObject(pops,
									GENERATIONS - generation);
							FrevoMain.publishResults(res);
							return;
						}
					}
					r.sortCandidates(pops.get(k).getMembers(), problem,
							getRandom());
					// bfitness.add(r.getBestFitness());
					double bestpopfitness = pops.get(k).getMembers().get(0)
							.getFitness();
					bfitness.add(bestpopfitness);

					if (bestpopfitness > bestfitness) {
						bestfitness = bestpopfitness;
						wasImprovement = true;
					}
					// sort according to score

				} catch (InstantiationException e) {
					e.printStackTrace();
				}
				if (FrevoMain.isFrevoWithGraphics()) {
					if (isInterrupted) {
						// Publish results in FrevoMain
						ResultObject res = new ResultObject(pops, GENERATIONS
								- generation);
						FrevoMain.publishResults(res);
						return;
					}
				}
			}

			// save improvement only
			if ((SAVEINTERVAL == -1) && (wasImprovement)) {
				DecimalFormat fm = new DecimalFormat("000");
				// FrevoMain.saveResult(SAVETO+outputName+"_g"+fm.format(generation)+"_f("+bestfitness+")",
				// this);
				FrevoMain.saveResult(
						problem.getName() + "_g" + fm.format(generation)
								+ "_f(" + bestfitness + ")", this);
				lastsaved = generation;
			}
			// Should save every Nth population
			else if ((SAVEINTERVAL != 0) && (SAVEINTERVAL != -1)) {
				if ((generation % SAVEINTERVAL) == 0) {
					DecimalFormat fm = new DecimalFormat("000");
					FrevoMain.saveResult(
							problem.getName() + "_g" + fm.format(generation),
							this);
					lastsaved = generation;
				}
			}

			// Mutate all populations except when this is the last generation
			if (generation != GENERATIONS - 1) {
				for (int j = 0; j < POPULATIONNUMBER; j++) {
					mutateAll(pops.get(j));
				}
			}

			// Add statistics
			if (index != null)
				index.add(generation);

		}
		setProgress(100);

		// Publish results in FrevoMain
		ResultObject res = new ResultObject(pops, 0);
		FrevoMain.publishResults(res);

		// Save final solution
		System.out.println("Saving...");

		if (lastsaved < generation - 1) {
			DecimalFormat fm = new DecimalFormat("000");
			FrevoMain.saveResult(
					problem.getName() + "_g" + fm.format(generation - 1), this);
		}

		// update saved statistics
		FrevoMain.writeStatisticsToDisk();
	}

	private class ResultObject {
		public LinkedList<SimplePopulation> populations;
		public int remainingGenerations;

		// public ArrayList<StatKeeper> statistics = new
		// ArrayList<StatKeeper>();

		public ResultObject(LinkedList<SimplePopulation> pops,
				int remaininggenerations) {
			populations = pops;
			remainingGenerations = remaininggenerations;
		}
	}

	/*private ArrayList<AbstractRepresentation> createList(Node nd) {
		ArrayList<AbstractRepresentation> result = new ArrayList<AbstractRepresentation>();

		try {
			List<?> npops = nd.selectNodes("./*");
			Iterator<?> it = npops.iterator();
			int size = npops.size();
			while (it.hasNext()) {
				Node net = (Node) it.next();
				size--;
				if (size % 10 == 0)
					size = size + (2 * 2 - 4);
				AbstractRepresentation member = representation
						.getNewRepresentationInstance(0, 0, null);
				member.loadFromXML(net);
				result.add(member);
			}
		} catch (InstantiationException e) {
			e.printStackTrace();
		}

		return result;
	}*/

	private void mutateAll(SimplePopulation simplePopulation) {

		// evolve all populations using the genetic algorithm
		for (SimplePopulation pop : pops) {

			int position = 0; // track current position in the new array
			AbstractRepresentation[] nets = pop.getNetArray(); // temporary
																// array for new
																// candidates

			// keep elite
			for (int i = position; i < N_ELITE; i++) {
				// Best Logging
				// nets[i].getGAHistory().setEntry(generation,GAHistory.ELITE,nets[i].getRank(),nets[i].getScore());
			}
			position = N_ELITE;

			// select randomly, probability should be higher for better-ranked
			// individuals
			for (int i = position; i < position + N_RANDOM; i++) {
				int randrange;
				int startind;

				// number of nets that are considered based on maximum diversity
				// to
				// individuals already considered so far
				// set this value to one to turn off this feature
				int diffsearch = 5;
				// TODO: calculation of startind bugged!
				// create a triangle distribution by adding two independent
				// randoms
				randrange = POPULATIONSIZE - 1 - (i + diffsearch - 1);
				startind = rndIndex(randrange) + rndIndex(randrange - 1)
						- (randrange - 1);

				if (startind < 0)
					startind = -startind;

				startind += i;

				double bestdiff = -1;
				int srcind = startind;

				for (int j = startind; j < startind + diffsearch; j++) {
					double diff = 1;
					// calculate product of diffs of all nets selected so far (0
					// to i-1)
					for (int k = 0; k < i; k++)
						diff *= nets[j].diffTo(nets[k]);
					if (diff > bestdiff) {
						bestdiff = diff;
						srcind = j;
					}
				}

				AbstractRepresentation temp = nets[i];
				nets[i] = nets[srcind];
				nets[srcind] = temp;
				// //History log
				// nets[i].getGAHistory().setEntry(generation,GAHistory.LUCKY,nets[i].getRank(),nets[i].getScore());
			}
			position += N_RANDOM;

			int survivors = position;

			// create mutated copies of selected nets
			for (int i = position; i < position + N_MUTATE; i++) {
				int srcind = rndIndex(survivors);
				nets[i] = nets[srcind].clone();
				nets[i].mutate(MUTATIONSEVERITY, 0.1f, MUTATIONMETHOD);
				// //History log
				// nets[i].getGAHistory().setEntry(generation,GAHistory.MUT,nets[i].getRank(),nets[i].getScore());

				// nets[i].setScore(0);
				// //log.println("diff after mutation "+nets[i].diffTo(nets[srcind]));
			}
			position += N_MUTATE;

			int trials = 100; // used to avoid endless loops
			int ii;
			// create offsprings between two individuals
			for (ii = position; ii < position + N_XOVER; ii++) {
				AbstractRepresentation mother, father;
				SimplePopulation fatherpop;
				int motherindex, fatherindex;// + type

				motherindex = rndIndex(N_ELITE + N_RANDOM);
				mother = nets[motherindex];

				if (pops.size() > 1 && generation % N_INTERXOVER_FREQ == 0) {
					// Xover between different Populations
					fatherpop = pops.get(rndIndex(POPULATIONNUMBER));
					// type = GAHistory.POPXOVER;

					// log.println("Xover between different Populations");
				} else {
					// Xover within the same Population
					fatherpop = pop;
					// type = GAHistory.XOVER;

					// log.println("Xover within the same Population");
				}

				// search for partner with highest diversity
				int candindex;
				double bestDiff, candDiff;
				AbstractRepresentation cand;

				fatherindex = rndIndex(N_ELITE + N_RANDOM);
				father = fatherpop.getNetArray()[fatherindex];
				bestDiff = mother.diffTo(father);

				for (int j = 0; j < 10; j++) {
					candindex = rndIndex(N_ELITE + N_RANDOM);
					cand = fatherpop.getNetArray()[candindex];
					candDiff = mother.diffTo(cand);

					if (candDiff > bestDiff) {
						fatherindex = candindex;
						father = cand;
						bestDiff = candDiff;
					}
				}

				nets[ii] = mother.clone();

				// calculate Xover area in chromosom
				/*
				 * int noninodes =
				 * config.getIntValue("nn.nodes")-config.getIntValue
				 * ("nn.inputnodes"); int nncount = rndIndex(noninodes-1)+1;
				 * //minimum 1, maximum all but 1 int startcpy =
				 * config.getIntValue("nn.inputnodes") + rndIndex(noninodes);
				 */

				// create offsprings
				boolean isNew = true;
				nets[ii].xOverWith(father, XOVERMETHOD);
				// check if this net exist already in the pool
				for (int j = 0; j < ii; j++) {
					if (nets[ii].diffTo(nets[j]) == 0) {
						isNew = false;
						// log.println("gen:"+generation+": we found a double");
						break;
					}
				}
				if (isNew == false) {
					if (trials-- == 0)
						break;
					ii--; // redo this net
				} else {
					// nets[i].getGAHistory().setEntry(generation,type,nets[i].getRank(),nets[i].getScore(),father.getRank());
					// nets[i].setScore(0);
				}

			}
			position = ii;
			// position += N_XOVER;

			// for the remaining slots create some new individuals with random
			// parameters
			if (position + N_RENEW != nets.length)
				System.err.println("Warning! Filling "
						+ (nets.length - (position + N_RENEW))
						+ " positions with random candidates.");
			for (int i = position; i < nets.length; i++) {
				// GAHistory h = nets[i].getGAHistory();
				try {
					nets[i] = pop.genNewNetwork();
				} catch (InstantiationException e) {
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				}

				// nets[i].setGAHistory(h);
				// History log
				// nets[i].getGAHistory().setEntry(generation,GAHistory.RENEW,i,0);

				// nets[i].setScore(0);
			}
			position += N_RENEW;

			// System.out.println("\nposition is now "+position);
			pop.readNetArray(nets); // write back netarray to population
		}

	}

	public void saveResults(Element dfrevo) {
		Element dpopulations = dfrevo.addElement("populations");
		dpopulations.addAttribute("count", String.valueOf(POPULATIONNUMBER));
		dpopulations.addAttribute("generation", String.valueOf(generation));
		dpopulations.addAttribute("randomseed", String.valueOf(this.getSeed()));
		for (SimplePopulation pop : pops) {
			pop.exportXml(dpopulations);
		}
	}

	private int rndIndex(int range) {
		if (range < 1)
			return 0;

		return generator.nextInt(Integer.MAX_VALUE) % range;
	}

	@Override
	public float getProgress() {
		return progress;
	}

	@SuppressWarnings("unchecked")
	@Override
	public ArrayList<ArrayList<AbstractRepresentation>> loadFromXML(Document doc) {
		// final list to be returned
		ArrayList<ArrayList<AbstractRepresentation>> populations = new ArrayList<ArrayList<AbstractRepresentation>>();

		Node dpopulations = doc.selectSingleNode("/frevo/populations");
		// get number of populations
		int populationCount = Integer
				.parseInt(dpopulations.valueOf("./@count"));

		// get population size
		List<? extends Node> populationsNode = dpopulations
				.selectNodes(".//population");
		int populationSize = populationsNode.get(0).selectNodes("*").size();

		int totalRepresentations = populationCount * populationSize;
		int currentPopulation = 0;
		int currentRepresentation = 0;

		Iterator<?> populationIterator = populationsNode.iterator();
		while (populationIterator.hasNext()) {
			Node populationNode = (Node) populationIterator.next();
			ArrayList<AbstractRepresentation> result = new ArrayList<AbstractRepresentation>();
			currentRepresentation = 0;
			try {
				List<?> representations = populationNode.selectNodes("./*");
				Iterator<?> representationsIterator = representations
						.iterator();
				while (representationsIterator.hasNext()) {
					int currentItem = currentPopulation * populationSize
							+ currentRepresentation + 1;
					FrevoMain.setLoadingProgress((float) currentItem
							/ totalRepresentations);
					Node net = (Node) representationsIterator.next();
					AbstractRepresentation member = representation
							.getNewRepresentationInstance(0, 0, null);
					member.loadFromXML(net);
					result.add(member);
					currentRepresentation++;
				}
			} catch (InstantiationException e) {
				e.printStackTrace();
			}

			populations.add(result);

			currentPopulation++;
		}
		return populations;
	}

}
