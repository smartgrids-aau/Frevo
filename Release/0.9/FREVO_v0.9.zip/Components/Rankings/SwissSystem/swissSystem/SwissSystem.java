package swissSystem;

/*
 * Copyright (C) 2009 Istvan Fehervari, Wilfried Elmenreich, Tobias Ibounig
 * Original project page: http://www.frevotool.tk
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License Version 3 as published
 * by the Free Software Foundation http://www.gnu.org/licenses/gpl-3.0.txt
 *
 * There is no warranty for this free software. The GPL requires that 
 * modified versions be marked as changed, so that their problems will
 * not be attributed erroneously to authors of previous versions.
 */

import java.awt.Point;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import main.ComponentXMLdata;
import main.FrevoMain;
import utils.NESRandom;
import core.AbstractComponent;
import core.AbstractMultiProblem;
import core.AbstractMultiProblem.RepresentationWithScore;
import core.AbstractRanking;
import core.AbstractRepresentation;
import core.XMLFieldEntry;

public class SwissSystem extends AbstractRanking {

	private int playerNumber;
	private boolean oddPlayers; // true if there number of players is odd
	private int roundNumber;
	private List<SwissElement> maintable = new ArrayList<SwissElement>();
	/** A list containing the next pairings */
	private List<Point> buffer = new ArrayList<Point>();
	private List<Integer> values = new ArrayList<Integer>();
	private List<SwissElement> unpaired = new ArrayList<SwissElement>();
	private int byePlayer;

	private static int WINPOINT;
	private static int TIEPOINT;
	private static int N_TREADS;

	class EvaluationRunnable implements Runnable {
		private ComponentXMLdata problem;
		private ArrayList<AbstractRepresentation> pop;

		public EvaluationRunnable(ComponentXMLdata problem,
				ArrayList<AbstractRepresentation> pop) {
			this.problem = problem;
			this.pop = pop;
		}

		@Override
		public void run() {
			try {
				Point pair = consumeNextGame();
				// evaluate game
				AbstractMultiProblem p;
				AbstractComponent comp = problem.getNewProblemInstance();
				if (comp instanceof AbstractMultiProblem) {
					p = (AbstractMultiProblem) comp;
				} else {
					throw new Error(
							"Swiss System requires an instance of IMultiProblem");
				}

				AbstractRepresentation p1 = pop.get(pair.x);
				AbstractRepresentation p2 = pop.get(pair.y);
				List<RepresentationWithScore> gameresult = p
						.evaluateFitness(new AbstractRepresentation[] { p1, p2 });

				double point1 = 0;
				double point2 = 0;
				if (gameresult.get(0).getRepresentation() == p1) {
					point1 = gameresult.get(0).getScore();
					point2 = gameresult.get(1).getScore();
				} else if (gameresult.get(1).getRepresentation() == p2) {
					point1 = gameresult.get(1).getScore();
					point2 = gameresult.get(0).getScore();
				} else {
					throw new Error("Passed representations are invalid");
				}

				if (point1 > point2) {
					addResult(pair.x, pair.y, 1);
					addResult(pair.y, pair.x, -1);
				} else if (point1 < point2) {
					addResult(pair.x, pair.y, -1);
					addResult(pair.y, pair.x, 1);
				} else {
					addResult(pair.x, pair.y, 0);
					addResult(pair.y, pair.x, 0);
				}

			} catch (InstantiationException e) {
				e.printStackTrace();
			} catch (Error e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public int sortCandidates(final ArrayList<AbstractRepresentation> pop,
			final ComponentXMLdata problem, NESRandom random) {
		// load from properties
		XMLFieldEntry win = getProperties().get("points_win");
		WINPOINT = Integer.parseInt(win.getValue());
		XMLFieldEntry tie = getProperties().get("points_tie");
		TIEPOINT = Integer.parseInt(tie.getValue());
		XMLFieldEntry nthreads = getProperties().get("parallelthreads");
		N_TREADS = Integer.parseInt(nthreads.getValue());

		int number_of_evaluations = 0;

		this.playerNumber = pop.size();
		if ((playerNumber % 2) != 0) {
			// Temporary, don't allow odd numbers
			throw new Error("Odd numbers are not supported");
			/*
			 * oddPlayers = true; roundNumber = calcRoundNumber(playerNumber-1);
			 */
		}

		roundNumber = calcRoundNumber(playerNumber);

		initialize();

		int gamesPerRound;
		if (oddPlayers)
			gamesPerRound = (playerNumber - 1) / 2;
		else
			gamesPerRound = playerNumber / 2;

		// Iterate through
		for (int s = 0; s < roundNumber; s++) { // take every round
			// System.out.println ("Round "+s);

			// Single Thread
			if (N_TREADS <= 1) {

				for (int i = 0; i < gamesPerRound; i++) { // take every pairing
															// in the round

					try {
						Point pair = consumeNextGame();
						// evaluate game
						AbstractMultiProblem p;
						AbstractComponent comp = problem
								.getNewProblemInstance();
						if (comp instanceof AbstractMultiProblem) {
							p = (AbstractMultiProblem) comp;
						} else {
							throw new Error(
									"Swiss System requires an instance of IMultiProblem");
						}

						AbstractRepresentation p1 = pop.get(pair.x);
						AbstractRepresentation p2 = pop.get(pair.y);
						List<RepresentationWithScore> gameresult = p
								.evaluateFitness(new AbstractRepresentation[] {
										p1, p2 });

						number_of_evaluations++;

						double point1 = 0;
						double point2 = 0;
						if (gameresult.get(0).getRepresentation() == p1) {
							point1 = gameresult.get(0).getScore();
							point2 = gameresult.get(1).getScore();
						} else if (gameresult.get(1).getRepresentation() == p2) {
							point1 = gameresult.get(1).getScore();
							point2 = gameresult.get(0).getScore();
						} else {
							throw new Error(
									"Passed representations are invalid");
						}

						if (point1 > point2) {
							addResult(pair.x, pair.y, 1);
							addResult(pair.y, pair.x, -1);
						} else if (point1 < point2) {
							addResult(pair.x, pair.y, -1);
							addResult(pair.y, pair.x, 1);
						} else {
							addResult(pair.x, pair.y, 0);
							addResult(pair.y, pair.x, 0);
						}
					} catch (InstantiationException e) {
						e.printStackTrace();
					} catch (Error e) {
						e.printStackTrace();
					}

				}

			} else {
				// Multithread
				// evaluate using thread pool
				ExecutorService executor = Executors
						.newFixedThreadPool(N_TREADS);
				for (int i = 0; i < gamesPerRound; i++) {
					Runnable worker = new EvaluationRunnable(problem, pop);
					executor.execute(worker);
					number_of_evaluations++;
				}

				// This will make the executor accept no new threads
				// and finish all existing threads in the queue
				executor.shutdown();
				// Wait until all threads are finish
				while (!executor.isTerminated()) {
					try {
						executor.awaitTermination(300, TimeUnit.MILLISECONDS);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}

			// Add tiepoint to byeplayer
			if (oddPlayers)
				addResult(byePlayer, -1, 0); // -1 is the dummyplayer meaning
												// the bye

			calcnextRound();
		}

		List<Integer> results = new ArrayList<Integer>();
		results = getResults();

		// ArrayList<IRepresentation> respop = new ArrayList<IRepresentation>();
		for (int u = 0; u < pop.size(); u++) {
			if ((FrevoMain.DEBUGLEVEL & 0x02) > 0)
				System.out.println((u + 1) + ". "
						+ pop.get(results.get(u)).getUniqueName());
			pop.get(results.get(u)).setFitness(-u);
		}
		Collections.sort(pop, Collections.reverseOrder());

		// copy result back into pop
		/*
		 * for (int u=0; u<pop.size();u++) { pop.set(u, respop.get(u)); }
		 */
		return number_of_evaluations;
	}

	/**
	 * Returns a list enumerating the players in a descending order starting
	 * with the one having the most points
	 * 
	 * @return
	 */
	public List<Integer> getResults() {
		List<Integer> results = new ArrayList<Integer>();
		Collections.sort(maintable, Collections.reverseOrder());

		for (int i = 0; i < maintable.size(); i++) {
			results.add(maintable.get(i).getId());
		}

		return results;
	}

	/**
	 * Calculates next round and puts it into the buffer. Invoke this only after
	 * consuming all pairings from the buffer using consumeNextGame()
	 */
	private void calcnextRound() {
		if (buffer.size() != 0) {
			System.err
					.println("Warning! Tournament buffer is not empty! There might be problems");
		}

		// TODO should remove bye player in case of odd population size

		// Rank them, first guy is the best in the list
		Collections.sort(maintable, Collections.reverseOrder());
		// Get number of different point-groups
		int pointgroups = numberOfDifferentValues();
		// Get all the players with the most points...
		Collections.sort(values, Collections.reverseOrder());

		boolean abovegroupusedfirstelement = false;

		for (int l = 0; l < pointgroups - 1; l++) {
			List<SwissElement> bestplayers = new ArrayList<SwissElement>();
			int maxpoint = values.get(l); // get next max value

			// collect all the players with this point to the array
			for (int i = 0; i < maintable.size(); i++) {
				if (maintable.get(i).getPoints() == maxpoint) {
					bestplayers.add(maintable.get(i));
				}
			}

			if (abovegroupusedfirstelement) {
				bestplayers.remove(0);
			}

			// add unpaired elements
			if (unpaired.size() != 0) {
				for (int add = 0; add < unpaired.size(); add++) {
					bestplayers.add(unpaired.get(add));
				}
			}
			unpaired.clear();
			// -----------------------------------------------------------
			// if they are even pair them, check for games already played
			if ((bestplayers.size() % 2) == 0) {
				pairPlayers(bestplayers);
				abovegroupusedfirstelement = false;
			} else { // if odd, create list with second less points
				abovegroupusedfirstelement = true;
				List<SwissElement> secplayers = new ArrayList<SwissElement>();
				int secmaxpoint = values.get(l + 1);
				for (int i = 0; i < maintable.size(); i++) {
					if (maintable.get(i).getPoints() == secmaxpoint) {
						secplayers.add(maintable.get(i));
					}
				}
				bestplayers.add(secplayers.get(0)); // need only the best player
													// from this group
				pairPlayers(bestplayers);
			}

		}
		// and the last group
		int maxpoint = values.get(values.size() - 1);
		List<SwissElement> bestplayers = new ArrayList<SwissElement>();
		for (int i = 0; i < maintable.size(); i++) {
			if (maintable.get(i).getPoints() == maxpoint) {
				bestplayers.add(maintable.get(i));
			}
		}

		if (abovegroupusedfirstelement) {
			bestplayers.remove(0);
		}

		if (unpaired.size() != 0) {
			for (int add = 0; add < unpaired.size(); add++) {
				bestplayers.add(unpaired.get(add));
			}
		}
		pairPlayers(bestplayers);

		// if there are still players let them play against each other
		if (unpaired.size() != 0) {
			for (int least = 0; least < (unpaired.size() / 2); least++) {
				buffer.add(new Point(unpaired.get(least).getId(), unpaired.get(
						least + (unpaired.size() / 2)).getId()));
			}
		}
		unpaired.clear();
		// if ((buffer.size()-buf1) != 25) System.err.println
		// ((buffer.size()-buf1)+" games added / "+unpaired.size()+" unpaired remained");
	}

	private void pairPlayers(List<SwissElement> bestplayers) {
		// split into 2 halves
		List<SwissElement> tophalves = new ArrayList<SwissElement>(); // top
																		// half
		List<SwissElement> bottomhalves = new ArrayList<SwissElement>(); // bottom
																			// half
		for (int th = 0; th < (bestplayers.size() / 2); th++) {
			tophalves.add(bestplayers.get(th));
			bottomhalves.add(bestplayers.get(th + (bestplayers.size() / 2)));
		}
		unpaired.clear();
		// Find pairs for the top half
		for (int pr = 0; pr < (tophalves.size()); pr++) {
			SwissElement top = tophalves.get(pr);
			for (int bh = 0; bh < (bottomhalves.size()); bh++) { // go through
																	// bottom
																	// half to
																	// find a
																	// game not
																	// played
																	// before
				if (!top.isAlreadyPlayed(bottomhalves.get(bh).getId())) {
					buffer.add(new Point(top.getId(), bottomhalves.get(bh)
							.getId()));
					bottomhalves.remove(bottomhalves.get(bh));
					break;
				}
				if (bh == bottomhalves.size() - 1) {
					// this element from upperhalf could not be paired -> move
					// to unpaired
					unpaired.add(top);
				}

			}
		}
		if (bottomhalves.size() != 0) {
			for (int btn = 0; btn < bottomhalves.size(); btn++) {
				unpaired.add(bottomhalves.get(btn));
			}
		}
	}

	/**
	 * Creates a list of all the different point standings available and returns
	 * the number of them
	 * 
	 * @return
	 */
	private int numberOfDifferentValues() {
		if (maintable.size() != 0) {
			int number = 1;
			values.clear();
			values = new ArrayList<Integer>();
			values.add(maintable.get(0).getPoints());
			for (int i = 0; i < maintable.size(); i++) {
				int v = maintable.get(i).getPoints();
				if (!values.contains(v)) {
					number++;
					values.add(v);
				}
			}
			return number;
		}

		return 0;
	}

	/**
	 * Adds result to the tournament
	 * 
	 * @param whoId
	 * @param against
	 * @param res
	 *            +1 means a win, -1 a loss, 0 a tie
	 */
	public synchronized void addResult(int whoId, int against, int res) {
		if (((res == 0) || (res == 1)) || (res == -1)) {
			SwissElement se = getElementWithId(whoId);
			se.addResult(against, res);
		} else {
			throw new Error("invalid result added: " + res);
		}
	}

	/**
	 * Returns the next game then removes it from the buffer
	 * 
	 * @return a Point with the next pairing: x versus y
	 */
	public synchronized Point consumeNextGame() {
		if (buffer.size() == 0) {
			throw new Error("No more rounds!");
		}
		Point next = buffer.get(buffer.size() - 1);
		buffer.remove(buffer.size() - 1);
		return next;
	}

	/** Create starting entries in table, create random seed -> buffer */
	private void initialize() {
		for (int i = 0; i < playerNumber; i++) {
			maintable.add(new SwissElement(i, this));
		}

		buffer.clear();
		// Create entries
		int first, second;
		List<Integer> players = new ArrayList<Integer>();
		for (int i = 0; i < playerNumber; i++) {
			players.add(i);
		}

		if (oddPlayers) { // remove one player and grant him a point
			Random generator = new NESRandom();
			byePlayer = generator.nextInt(playerNumber);
			players.remove(byePlayer);

			// Fill buffer with ordered pairing (first with last, etc)
			final int hsize = playerNumber / 2;
			for (int i = 0; i < (hsize); i++) {
				first = players.get(i);
				second = players.get(playerNumber - 1 - i);
				Point newset = new Point(first, second);
				buffer.add(newset);
			}

		} else {
			// Fill buffer with ordered pairing (first with last, etc)
			final int hsize = playerNumber / 2;
			for (int i = 0; i < (hsize); i++) {
				first = players.get(i);
				second = players.get(playerNumber - 1 - i);
				Point newset = new Point(first, second);
				buffer.add(newset);
			}
		}

	}

	/**
	 * Returns the number of rounds required to finish the tournament based on
	 * the number of players. It is the binary logarithm rounded up
	 * 
	 * @param player
	 * @return
	 */
	private static int calcRoundNumber(int player) {
		if ((player % 2) != 0)
			throw new Error("Player number should be an even number here!");
		Double rnumber = java.lang.Math.log10(player) / java.lang.Math.log10(2);
		int rNumberInt = rnumber.intValue();
		if (rnumber.intValue() < rnumber) {
			rNumberInt++;
		}
		return rNumberInt;
	}

	public int getWinPoint() {
		return WINPOINT;
	}

	public int getTiePoint() {
		return TIEPOINT;
	}

	/**
	 * Returns the element with the given id from the maintable
	 * 
	 * @param whoId
	 * @return
	 */
	public SwissElement getElementWithId(int whoId) {
		SwissElement res = new SwissElement(0, this);
		for (int i = 0; i < maintable.size(); i++) {
			if (maintable.get(i).getId() == whoId) {
				res = maintable.get(i);
			}
		}
		if (res != null) {
			return res;
		}
		
		throw new Error("Element wasnt found in the table!");
	}
}
