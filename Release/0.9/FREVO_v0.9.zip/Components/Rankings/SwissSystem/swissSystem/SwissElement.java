package swissSystem;
/*
 * Copyright (C) 2009 Istvan Fehervari, Wilfried Elmenreich
 * Original project page: http://www.frevotool.tk
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License Version 3 as published
 * by the Free Software Foundation http://www.gnu.org/licenses/gpl-3.0.txt
 *
 * There is no warranty for this free software. The GPL requires that 
 * modified versions be marked as changed, so that their problems will
 * not be attributed erroneously to authors of previous versions.
 */
import java.util.ArrayList;
import java.util.List;

import utils.NESRandom;

public class SwissElement implements Comparable<SwissElement> {

    private int id;
    private int points;
    private SwissSystem parent;
    private List<ResultElement> resultList = new ArrayList<ResultElement>();

    public SwissElement(int id, int points, SwissSystem parent) {
        this.id = id;
        this.points = points;
        this.parent = parent;
    }

    public SwissElement(int id, SwissSystem parent) {
        this(id, 0, parent);
    }

    public int getId() {
        return id;
    }

    public void addPoint(int point) {
        this.points = points + point;
    }

    public int getPoints() {
        return this.points;
    }

    /**
     * Adds result to this element
     * @param against
     * @param res
     */
    public void addResult(int against, int res) {
        if (!isAlreadyPlayed(against)) {
            resultList.add(new ResultElement(against, res));
        } else {
            int ressize = resultList.size();
            //System.err.println ("Warning! This game is already played...");
            resultList.add(new ResultElement(against, res, (new NESRandom()).nextInt(1000)));
            if (ressize != (resultList.size() - 1)) {
                System.err.println("Result has not been added");
            }
        }
        //if this was a win or tie then increase its points
        if (res == 1) {
            addPoint(parent.getWinPoint());
        } else if (res == 0) {
            addPoint(parent.getTiePoint());
        }
    }

    /**
     * Returns true if there is already a registered game result with this opponent
     * @param against
     * @return
     */
    public boolean isAlreadyPlayed(int against) {
        boolean is = false;
        for (int i = 0; i < this.resultList.size(); i++) {
            int a = resultList.get(i).getId();
            if (a == against) {
                is = true;
            }
        }
        return is;
    }

    @Override
    /**
     *  1. positive -> this object is greater than o1 greater means has more points
     *  2. zero -> this object equals to o1
     *  3. negative -> this object is less than o1
     */
    public int compareTo(SwissElement o1) {
        if (this.points > o1.points) {
            return +1;
        } else if (this.points < o1.points) {
            return -1;
        } else if (this.points == o1.points) {
            //compare enemies points
            int oppPoints1 = 0;
            int oppPoints2 = 0;
            for (int i = 0; i < this.resultList.size(); i++) { // Buchholz
                oppPoints1 = oppPoints1 + parent.getElementWithId(this.resultList.get(i).getId()).points;
            }
            for (int i = 0; i < o1.resultList.size(); i++) { // Buchholz
                oppPoints2 = oppPoints2 + parent.getElementWithId(o1.resultList.get(i).getId()).points;
            }
            if (oppPoints1 > oppPoints2) {
                return +1;
            } else if (oppPoints1 < oppPoints2) {
                return -1;
            } else {
                for (int i = 0; i < this.resultList.size(); i++) { //Sonneborn-Berger
                    if (this.resultList.get(0).getResult() == 1) {
                        oppPoints1 = oppPoints1 + 2 * (parent.getElementWithId(this.resultList.get(i).getId()).points);
                    } else if (this.resultList.get(0).getResult() == 0) {
                        oppPoints1 = oppPoints1 + parent.getElementWithId(this.resultList.get(i).getId()).points;
                    }
                }

                for (int i = 0; i < o1.resultList.size(); i++) { //Sonneborn-Berger
                    if (o1.resultList.get(0).getResult() == 1) {
                        oppPoints2 = oppPoints2 + 2 * (parent.getElementWithId(o1.resultList.get(i).getId()).points);
                    } else if (o1.resultList.get(0).getResult() == 0) {
                        oppPoints2 = oppPoints2 + parent.getElementWithId(o1.resultList.get(i).getId()).points;
                    }
                }


                if (oppPoints1 > oppPoints2) {
                    return +1;
                } else if (oppPoints1 < oppPoints2) {
                    return -1;
                } else {
                    return 0;
                }
            }
        } else {
            throw new Error("problem with sorting");
        }
    }
}
